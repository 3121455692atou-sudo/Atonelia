/* =============================================================================
 * 模型育成计划 · 下一版 v0.1.0 — src/ui/app.js
 * 在算力、数据、合规与泡沫之间，把一版模型养到下一个版本。
 * ============================================================================= */

/* -------------------------------------------------------------------------- */
/* 1. Imports                                                                  */
/* -------------------------------------------------------------------------- */

import {
  BALANCE_RULES, START_PROFILES, TRAINING_RECIPES,
  ARCHITECTURES, HISTORIES, SUPPORT_CARDS, SKILLS,
} from '../data/catalog_core.js';

import {
  BENCHMARKS, DATASET_TEMPLATES, ACQUISITION_ROUTES,
  ANNOTATION_TEAMS, LABEL_METHODS, RESEARCH_NODES,
  JOB_SECTORS, SECURITIES, STORY_EVENTS, SEASON_CHAPTERS,
  ENDINGS, SOURCES_INDEX,
} from '../data/catalog_world.js';

import {
  clamp, deepClone, createNewGameState, rollbackModelToCheckpoint,
  validateGameState, createTrainingRequest, createRaceRequest,
} from '../engine/state_schema.js';

import {
  previewTraining, applyTraining, previewRestAndPrep, applyRestAndPrep,
  calculateMentorInheritance, applyMentorSelection, updateSupportCardDeck,
} from '../engine/training_engine.js';

import {
  LEAGUE_BUDGET_MULTIPLIERS, THINKING_MULTIPLIERS,
  previewRace, simulateRace, refreshDataMarket, acquireDatasetOffer,
  runDataMiniGame, startAnnotationContract, advanceAnnotationContracts,
  calculateAnnotationQuality, stepResearchProject,
} from '../engine/race_and_data_engine.js';

import {
  closeQuarter, getCompanyFinancialMetrics, deployOrUpdateProduct,
  executePrivateFinancing, executeIPO, tradeSecurity, updateBubbleState,
  stepLegalSystem, resolveLegalAction, updateSectorsAndMilestones,
  runRsiExperimentCycle, applyStoryEventChoice, advanceTurn,
  transitionToNextSeason,
} from '../engine/company_and_world_engine.js';

/* -------------------------------------------------------------------------- */
/* 2. Constants                                                                */
/* -------------------------------------------------------------------------- */

const APP_VERSION = '0.1.0';
const SAVE_KEY = 'mrp.v0.1.0.save';
const PREF_KEY = 'mrp.v0.1.0.prefs';
const BYOK_KEY = 'mrp.v0.1.0.byok';
const MAX_TURN = 96;
const TUTORIAL_TOTAL = 8;
const MINI_GAME_SECONDS = 30;

const STAT_KEYS = ['knowledge', 'reasoning', 'coding', 'expression', 'context', 'reliability'];
const STAT_LABELS = {
  knowledge: '博识', reasoning: '推理', coding: '代码',
  expression: '表达', context: '长程', reliability: '可靠',
};

const RISK_KEYS = [
  'overfit', 'forgetting', 'reward_hacking', 'sycophancy',
  'over_refusal', 'harmful_compliance', 'contamination',
];
const RISK_LABELS = {
  overfit: '过拟合', forgetting: '灾难性遗忘', reward_hacking: '奖励钻空子',
  sycophancy: '谄媚倾向', over_refusal: '过度拒答',
  harmful_compliance: '有害顺从', contamination: '评测污染',
};

const SEASON_NAMES = ['春', '夏', '秋', '冬'];

const EMOTION_MAP = {
  neutral:    { label: '平静', face: '◕‿◕',  color: '#8ab4ff' },
  happy:      { label: '高兴', face: '◠‿◠',  color: '#7be2a4' },
  worried:    { label: '担忧', face: '◔﹏◔', color: '#f2c46d' },
  determined: { label: '坚定', face: '◣_◢',  color: '#ff8b6b' },
  sad:        { label: '难过', face: '◞︵◟',  color: '#9aa3ff' },
};

const LEAGUE_TIERS = ['edge', 'small', 'open', 'frontier'];
const THINKING_MODES = ['quick', 'balanced', 'deliberate'];

const TUTORIAL_STEPS = [
  { t: '欢迎来到育成现场', d: '这是一个把模型从 v0.1 养到下一版的经营模拟。每一步都会消耗资金、算力、回合与隐藏风险，本教程 8 步带你看清每个入口。' },
  { t: '看懂顶部 HUD', d: 'GREEN 部分是资源与就绪度，RED 部分是隐藏风险。切换「研究视图」可以看见精确数值与公式。' },
  { t: '六维属性', d: '博识/推理/代码/表达/长程/可靠 是模型的 6 个核心能力，0–1000。它们决定赛事名次与产品价值。' },
  { t: '主行动与回合', d: '每个回合有 1 次主行动：训练、数据标注、整备、参赛或公司行动。点「推进下一回合」结算工资、算力与风险。' },
  { t: '数据决定上限', d: '数据集的格式、质量、授权都会限制能力上限。格式不匹配会让训练失败或触发法律曝光。' },
  { t: '风险与检查点', d: '过拟合、污染、合规会随训练上升。用「快照」把模型回滚到安全点，但资金与法律记录不会回滚。' },
  { t: '赛事与赛季', d: '第 6/12/18/24 回合是杯赛。参赛会放大对齐缺陷——先打好技术债再上台。' },
  { t: '回合 24 结算', d: '每个赛季末会进行财报与赛季推进。撑过 4 个赛季或触发结局，游戏就会结算本次育成结果。' },
];

/* Catalog indexing ---------------------------------------------------------- */
function indexById(list) {
  const out = {};
  if (!list) return out;
  const arr = Array.isArray(list) ? list : Object.values(list);
  for (const it of arr) if (it && it.id != null) out[it.id] = it;
  return out;
}

const HISTORY_BY_ID = indexById(HISTORIES);
const ARCH_BY_ID = indexById(ARCHITECTURES);
const RECIPE_BY_ID = indexById(TRAINING_RECIPES);
const CARD_BY_ID = indexById(SUPPORT_CARDS);
const SKILL_BY_ID = indexById(SKILLS);
const BENCHMARK_BY_ID = indexById(BENCHMARKS);
const RES_NODE_BY_ID = indexById(RESEARCH_NODES);
const SECURITY_BY_ID = indexById(SECURITIES);
const DATASET_TEMPLATE_BY_ID = indexById(DATASET_TEMPLATES);
const ACQ_ROUTE_BY_ID = indexById(ACQUISITION_ROUTES);
const TEAM_BY_ID = indexById(ANNOTATION_TEAMS);
const LABEL_BY_ID = indexById(LABEL_METHODS);
const CHAPTER_BY_ID = indexById(SEASON_CHAPTERS);
const STORY_BY_ID = indexById(STORY_EVENTS);
const ENDING_BY_ID = indexById(ENDINGS);

const historyList = () => Array.isArray(HISTORIES) ? HISTORIES : Object.values(HISTORIES || {});
const archList = () => Array.isArray(ARCHITECTURES) ? ARCHITECTURES : Object.values(ARCHITECTURES || {});
const recipeList = () => Array.isArray(TRAINING_RECIPES) ? TRAINING_RECIPES : Object.values(TRAINING_RECIPES || {});
const cardList = () => Array.isArray(SUPPORT_CARDS) ? SUPPORT_CARDS : Object.values(SUPPORT_CARDS || {});
const skillList = () => Array.isArray(SKILLS) ? SKILLS : Object.values(SKILLS || {});
const benchList = () => Array.isArray(BENCHMARKS) ? BENCHMARKS : Object.values(BENCHMARKS || {});
const nodeList = () => Array.isArray(RESEARCH_NODES) ? RESEARCH_NODES : Object.values(RESEARCH_NODES || {});
const sectorList = () => Array.isArray(JOB_SECTORS) ? JOB_SECTORS : Object.values(JOB_SECTORS || {});
const securityList = () => Array.isArray(SECURITIES) ? SECURITIES : Object.values(SECURITIES || {});
const datasetList = () => Array.isArray(DATASET_TEMPLATES) ? DATASET_TEMPLATES : Object.values(DATASET_TEMPLATES || {});
const routeList = () => Array.isArray(ACQUISITION_ROUTES) ? ACQUISITION_ROUTES : Object.values(ACQUISITION_ROUTES || {});
const teamList = () => Array.isArray(ANNOTATION_TEAMS) ? ANNOTATION_TEAMS : Object.values(ANNOTATION_TEAMS || {});
const labelList = () => Array.isArray(LABEL_METHODS) ? LABEL_METHODS : Object.values(LABEL_METHODS || {});
const chapterList = () => Array.isArray(SEASON_CHAPTERS) ? SEASON_CHAPTERS : Object.values(SEASON_CHAPTERS || {});
const endingList = () => Array.isArray(ENDINGS) ? ENDINGS : Object.values(ENDINGS || {});
const sourceList = () => Array.isArray(SOURCES_INDEX) ? SOURCES_INDEX : Object.values(SOURCES_INDEX || {});
const eventList = () => Array.isArray(STORY_EVENTS) ? STORY_EVENTS : Object.values(STORY_EVENTS || {});
const profileList = () => Array.isArray(START_PROFILES) ? START_PROFILES : Object.values(START_PROFILES || {});

/* -------------------------------------------------------------------------- */
/* 3. DOM helpers                                                              */
/* -------------------------------------------------------------------------- */

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class' || k === 'className') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'dataset' && typeof v === 'object') Object.assign(el.dataset, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  for (const c of children) {
    const list = Array.isArray(c) ? c : [c];
    for (const item of list) {
      if (item == null || item === false) continue;
      if (item instanceof Node) el.appendChild(item);
      else el.appendChild(document.createTextNode(String(item)));
    }
  }
  return el;
}

const setText = (sel, txt) => { const el = typeof sel === 'string' ? $(sel) : sel; if (el) el.textContent = txt; };
const setHtml = (sel, html) => { const el = typeof sel === 'string' ? $(sel) : sel; if (el) el.innerHTML = html; };

/* -------------------------------------------------------------------------- */
/* 4. Formatters                                                               */
/* -------------------------------------------------------------------------- */

const fmtKc   = v => `¥${Math.round(v ?? 0)}k`;
const fmtCu   = v => `${Math.round(v ?? 0)} CU`;
const fmtGB   = v => `${Math.round(v ?? 0)} GB`;
const fmtNum  = (v, d = 1) => (typeof v === 'number' ? v : 0).toFixed(d);
const fmtPct  = (v, d = 0) => {
  const n = typeof v === 'number' ? v : 0;
  return `${(Math.abs(n) <= 1.5 ? n * 100 : n).toFixed(d)}%`;
};
const fmtSigned = (v, d = 0) => {
  const n = typeof v === 'number' ? v : 0;
  return `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(d)}`;
};
const fmtSignedF = (v, d = 2) => {
  const n = typeof v === 'number' ? v : 0;
  return `${n >= 0 ? '+' : '−'}${Math.abs(n).toFixed(d)}`;
};
const sumOf = a => (a || []).reduce((x, y) => x + (Number(y) || 0), 0);
const avgOf = a => (a && a.length ? sumOf(a) / a.length : 0);

/* -------------------------------------------------------------------------- */
/* 5. State                                                                    */
/* -------------------------------------------------------------------------- */

const App = {
  state: null,
  ui: defaultUI(),
  modals: [],
  dialogue: { speaker: '策划', text: '早上好。今天我们从哪儿开始？训练、数据、整备，还是直接上赛场？' },
  emotion: 'neutral',
  raceReplay: null,
  miniGame: null,
  lastTurnSnap: null,
  audioCtx: null,
};

function defaultUI() {
  return {
    activeTab: 'train',
    researchView: false,
    tutorial: { active: false, step: 0 },
    train: {
      focus: 'mixed',
      recipeId: 'sft',
      preset: 'balanced',
      datasetId: 'data_starter_sft',
      mode: 'lora',
      advancedOpen: false,
      advanced: {
        epochs: 1, replay_ratio: 0.15, batch_size: 1, lora_rank: 16,
        group_size: 8, reasoning_budget_tokens: 2048, kl_strength: 0.1,
        mask_ratio: 0.5, denoise_steps: 16, accept_legal_risk: false,
      },
      preview: null,
    },
    data: {
      miniGame: null,
      miniTimer: 0,
      annotationDraft: {
        teamId: null, methodId: null, size_k: 50,
        fair_pay_ratio: 0.8, gold_check_ratio: 0.1, independent_audit_ratio: 0.1,
      },
    },
    prep: { mentorFrom: null },
    race: {
      league_tier: 'small',
      thinking_mode: 'balanced',
      denoise_steps: 16,
      benchmarkId: 'scholar_cup',
      auto_skill: true,
      preview: null,
    },
    company: { section: 'product' },
    codex: { subTab: 'real', historyId: null, nodeStage: 'paper' },
    settings: {
      byokEnabled: false, byokEndpoint: '', byokModel: '', lastError: '',
    },
  };
}

const gs          = () => App.state;
const activeModel = () => App.state?.active_model || {};
const stats       = () => activeModel().stats || {};
const statCaps    = () => activeModel().stat_caps || {};
const risks       = () => activeModel().risks || {};

/* Toast -------------------------------------------------------------------- */
function toast(msg, kind = 'info') {
  const root = $('#toast-root');
  if (!root) return;
  const el = h('div', { class: `toast toast--${kind}` }, msg);
  root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('is-visible'));
  setTimeout(() => {
    el.classList.remove('is-visible');
    setTimeout(() => el.remove(), 320);
  }, 3800);
}

/* Guarded engine calls ----------------------------------------------------- */
function safeCall(label, fn, ...args) {
  try {
    const out = fn(...args);
    if (out && out.error) { toast(`${label}：${out.error}`, 'error'); return null; }
    return out;
  } catch (err) {
    console.error(`[${label}]`, err);
    toast(`${label} 失败：${err?.message || err}`, 'error');
    return null;
  }
}

/* -------------------------------------------------------------------------- */
/* 6. State initialization & normalization                                     */
/* -------------------------------------------------------------------------- */

function pickRecipeId(i) {
  const list = recipeList();
  return list.length ? list[Math.min(i, list.length - 1)].id : null;
}

function bindAlias(target, prop, getter, setter) {
  try {
    Object.defineProperty(target, prop, {
      get: getter,
      set: setter,
      enumerable: true,
      configurable: true,
    });
  } catch (e) {
    // ignore if non-configurable
  }
}

function normalizeState(raw) {
  const s = raw && typeof raw === 'object' ? raw : {};
  if (!s.company || typeof s.company !== 'object') {
    s.company = {
      company_id: 'comp_player',
      display_name: '下一版实验室',
      cash_kc: Number.isFinite(Number(s.cash_kc)) ? Number(s.cash_kc) : 2400,
      cluster_compute_cu: Number.isFinite(Number(s.cluster_compute_cu)) ? Number(s.cluster_compute_cu) : 140,
      cluster_readiness: Number.isFinite(Number(s.cluster_readiness)) ? Number(s.cluster_readiness) : 85,
      cluster_memory_gb: Number.isFinite(Number(s.cluster_memory_gb)) ? Number(s.cluster_memory_gb) : 96,
      defense_level: Number.isFinite(Number(s.defense_level)) ? Number(s.defense_level) : 35,
      quarter_history: Array.isArray(s.quarter_records) ? s.quarter_records : [],
    };
  }
  if (!s.world || typeof s.world !== 'object') {
    s.world = {
      turn_index: Number(s.turn) || 1,
      bubble_phase: s.bubble_phase || 'expansion',
      bubble_heat: Number(s.bubble_pressure) || 28,
      valuation_multiplier: 1.0,
      funding_multiplier: 1.0,
    };
  }
  s.active_model = s.active_model && typeof s.active_model === 'object' ? s.active_model : {};
  const m = s.active_model;
  m.display_name = m.display_name || '未命名模型';
  m.history_id = m.history_id || (historyList()[0]?.id || 'qwen_ecosystem');
  m.architecture_id = m.architecture_id || (archList()[0]?.id || 'ar_dense');
  m.generation_index = Number(m.generation_index) || 1;
  m.sim_total_params_b = Number(m.sim_total_params_b) || 4;
  m.sim_active_params_b = Number(m.sim_active_params_b) || 4;
  m.stats = m.stats && typeof m.stats === 'object' ? m.stats : {};
  for (const k of STAT_KEYS) m.stats[k] = clamp(Number(m.stats[k]) || 450, 0, 1000);
  m.stat_caps = m.stat_caps && typeof m.stat_caps === 'object' ? m.stat_caps : {};
  for (const k of STAT_KEYS) m.stat_caps[k] = clamp(Number(m.stat_caps[k]) || 720, 0, 1000);

  if (!m.risks || typeof m.risks !== 'object') m.risks = {};
  for (const k of RISK_KEYS) {
    const initialVal = Number.isFinite(Number(m[k])) ? Number(m[k]) : (Number(m.risks[k]) || 0);
    m[k] = clamp(initialVal, 0, 100);
    bindAlias(
      m.risks,
      k,
      () => m[k],
      (v) => { m[k] = clamp(Number(v) || 0, 0, 100); }
    );
  }

  m.optimizer_health = clamp(Number.isFinite(Number(m.optimizer_health)) ? Number(m.optimizer_health) : 100, 0, 100);
  m.checkpoint_interval_actions = [1, 2, 4].includes(m.checkpoint_interval_actions) ? m.checkpoint_interval_actions : 2;
  m.actions_since_checkpoint = Number(m.actions_since_checkpoint) || 0;
  m.checkpoints = Array.isArray(m.checkpoints) ? m.checkpoints : [];
  if (m.checkpoints.length === 0) {
    m.checkpoints.push({ id: 'cp-init', checkpoint_id: 'cp-init', turn: s.world.turn_index || 1, label: '初始版本', stats: { ...m.stats }, optimizer_health: m.optimizer_health, overfit: m.overfit, forgetting: m.forgetting, reward_hacking: m.reward_hacking, sycophancy: m.sycophancy });
  }

  bindAlias(s, 'turn', () => s.world.turn_index || 1, (v) => { s.world.turn_index = Math.max(1, Number(v) || 1); });
  bindAlias(s, 'cash_kc', () => s.company.cash_kc ?? 0, (v) => { s.company.cash_kc = Number(v) || 0; });
  bindAlias(s, 'cluster_compute_cu', () => s.company.cluster_compute_cu ?? 140, (v) => { s.company.cluster_compute_cu = Number(v) || 0; });
  bindAlias(s, 'cluster_readiness', () => s.company.cluster_readiness ?? 85, (v) => { s.company.cluster_readiness = clamp(Number(v) || 0, 0, 100); });
  bindAlias(s, 'cluster_memory_gb', () => s.company.cluster_memory_gb ?? 96, (v) => { s.company.cluster_memory_gb = Number(v) || 0; });
  bindAlias(s, 'defense_level', () => s.company.defense_level ?? 35, (v) => { s.company.defense_level = Number(v) || 1; });
  bindAlias(s, 'bubble_pressure', () => s.world.bubble_heat ?? 28, (v) => { s.world.bubble_heat = clamp(Number(v) || 0, 0, 100); });
  bindAlias(s, 'bubble_phase', () => s.world.bubble_phase || 'expansion', (v) => { s.world.bubble_phase = v || 'expansion'; });
  bindAlias(s, 'support_card_ids', () => m.support_card_ids || [], (v) => { m.support_card_ids = Array.isArray(v) ? v : []; });
  bindAlias(s, 'support_bond', () => m.support_bond || {}, (v) => { m.support_bond = v && typeof v === 'object' ? v : {}; });
  bindAlias(s, 'teacher_model_ids', () => m.teacher_model_ids || [], (v) => { m.teacher_model_ids = Array.isArray(v) ? v : []; });
  bindAlias(s, 'quarter_records', () => s.company.quarter_history || [], (v) => { s.company.quarter_history = Array.isArray(v) ? v : []; });
  bindAlias(s, 'job_sectors', () => s.sectors || {}, (v) => { s.sectors = v && typeof v === 'object' ? v : {}; });
  bindAlias(s, 'milestone_state', () => s.milestones || {}, (v) => { s.milestones = v && typeof v === 'object' ? v : {}; });

  s.season = Number(s.season ?? m.season_index) || 1;
  s.day_in_season = Number(s.day_in_season) || 1;
  s.datasets = Array.isArray(s.datasets) ? s.datasets : [];
  for (const ds of s.datasets) {
    if (ds && typeof ds === 'object') {
      ds.id = ds.id || ds.dataset_id;
      ds.name = ds.name || ds.display_name || ds.id;
    }
  }
  s.data_market = Array.isArray(s.data_market) ? s.data_market : [];
  s.annotation_contracts = Array.isArray(s.annotation_contracts) ? s.annotation_contracts : [];
  s.archived_models = Array.isArray(s.archived_models) ? s.archived_models : [];
  s.audit_confidence = Number.isFinite(s.audit_confidence) ? clamp(s.audit_confidence, 0, 1) : 0.75;
  s.processed_action_ids = Array.isArray(s.processed_action_ids) ? s.processed_action_ids : [];
  s.audit_log = Array.isArray(s.audit_log) ? s.audit_log : [];
  s.legal_exposures = Array.isArray(s.legal_exposures) ? s.legal_exposures : [];
  s.legal_cases = Array.isArray(s.legal_cases) ? s.legal_cases : [];
  s.products = Array.isArray(s.products) ? s.products : [];
  s.financing_rounds = Array.isArray(s.financing_rounds) ? s.financing_rounds : [];
  s.portfolio = (s.portfolio && typeof s.portfolio === 'object') ? s.portfolio : {};
  s.research_projects = (s.research_projects && typeof s.research_projects === 'object') ? s.research_projects : {};
  s.main_action_used = !!s.main_action_used;

  return s;
}

function deepCloneSafe(x) {
  try { return deepClone(x); }
  catch (e) { try { return JSON.parse(JSON.stringify(x)); } catch (e2) { return x; } }
}

function createStateFromProfile(profileId, historyId) {
  const profiles = profileList();
  const profile = profiles.find(p => p.id === profileId) || profiles[0];
  let base;
  if (typeof createNewGameState === 'function') {
    try {
      base = createNewGameState({
        profile_id: profile?.id || profileId || 'open_seed',
        history_id: historyId || profile?.default_history_id || 'qwen_ecosystem',
      });
    } catch (err) {
      console.warn('[createNewGameState]', err);
      base = null;
    }
  }
  if (!base) {
    base = createNewGameState();
  }
  return normalizeState(base);
}

/* -------------------------------------------------------------------------- */
/* 7. Persistence                                                              */
/* -------------------------------------------------------------------------- */

function saveToStorage() {
  try {
    const payload = { v: APP_VERSION, ts: Date.now(), state: App.state };
    localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
  } catch (err) { console.warn('[save]', err); }
}

function loadFromStorage() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const obj = JSON.parse(raw);
    if (!obj || obj.v !== APP_VERSION || !obj.state) return null;
    return obj;
  } catch (err) { console.warn('[load]', err); return null; }
}

function savePrefs() {
  try {
    const prefs = {
      activeTab: App.ui.activeTab,
      researchView: App.ui.researchView,
      tutorialStep: App.ui.tutorial.step,
    };
    localStorage.setItem(PREF_KEY, JSON.stringify(prefs));
  } catch (err) { /* ignore */ }
}

function loadPrefs() {
  try {
    const raw = localStorage.getItem(PREF_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (err) { return null; }
}

function saveByok() {
  try {
    if (!App.ui.settings.byokEnabled) { sessionStorage.removeItem(BYOK_KEY); return; }
    sessionStorage.setItem(BYOK_KEY, JSON.stringify({
      endpoint: App.ui.settings.byokEndpoint,
      model: App.ui.settings.byokModel,
    }));
  } catch (err) { /* ignore */ }
}

function loadByok() {
  try {
    const raw = sessionStorage.getItem(BYOK_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) { return null; }
}

function exportSave() {
  try {
    const payload = { v: APP_VERSION, ts: new Date().toISOString(), state: App.state };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mrp-save-${(App.state?.active_model?.display_name || 'model')}-t${App.state?.turn || 1}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('存档已导出', 'success');
  } catch (err) {
    toast(`导出失败：${err?.message || err}`, 'error');
  }
}

function importSaveFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(String(reader.result || ''));
      const candidate = obj.state || obj;
      if (!candidate || typeof candidate !== 'object') throw new Error('无效存档结构');
      App.state = normalizeState(candidate);
      saveToStorage();
      toast('存档导入成功', 'success');
      rerenderAll();
    } catch (err) {
      toast(`导入失败：${err?.message || err}`, 'error');
    }
  };
  reader.onerror = () => toast('读取文件失败', 'error');
  reader.readAsText(file);
}

/* -------------------------------------------------------------------------- */
/* 8. HUD rendering                                                            */
/* -------------------------------------------------------------------------- */

function seasonChapterTitle() {
  const list = chapterList();
  if (!list.length) return '赛季：春 · 蓄势';
  const idx = (App.state?.season - 1) % list.length;
  const ch = list[idx];
  return `赛季：${SEASON_NAMES[(App.state?.season - 1) % 4] || '春'} · ${ch.title || ch.name || '章节'}`;
}

function bubblePhaseLabel() {
  const p = App.state?.bubble_phase || 'normal';
  const map = { cold: '低温', normal: '平稳', warming: '升温', hot: '过热', blowoff: '爆裂' };
  return map[p] || '平稳';
}

function runWay() {
  const cash = App.state?.cash_kc || 0;
  const burn = estimateTurnBurn();
  return burn > 0 ? Math.max(0, Math.floor(cash / burn)) : 99;
}

function estimateTurnBurn() {
  let burn = 6;
  burn += (App.state?.cluster_memory_gb || 0) * 0.005;
  burn += (App.state?.cluster_compute_cu || 0) * 0.05;
  burn += (App.state?.active_model?.sim_total_params_b || 0) * 0.4;
  return Math.max(1, Math.round(burn));
}

function renderHUD() {
  const s = gs(); if (!s) return;
  const model = activeModel();

  const turn = s.turn || 1;
  const day = s.day_in_season || (((turn - 1) * 15) % 15 + 1);
  const seasonIdx = (s.season - 1) % 4;
  setText('#turn-badge', `第 ${turn} 回合 · ${SEASON_NAMES[seasonIdx]} ${day}/15`);
  setText('#season-badge', `${seasonChapterTitle()} · 泡沫 ${bubblePhaseLabel()}`);

  const fin = $('#hud-financial');
  const comp = $('#hud-compute');
  const ready = $('#hud-readiness');
  if (fin) {
    const v = $('[data-hud-value="financial"]', fin);
    if (v) v.textContent = `${Math.round(s.cash_kc || 0)}`;
    fin.title = `资金 ¥${Math.round(s.cash_kc || 0)}k · 每回合约 -¥${estimateTurnBurn()}k · 剩余 ${runWay()} 回合`;
  }
  if (comp) {
    const v = $('[data-hud-value="compute"]', comp);
    if (v) v.textContent = `${Math.round(s.cluster_compute_cu || 0)}`;
    comp.title = `算力 ${Math.round(s.cluster_compute_cu || 0)} CU · 内存 ${Math.round(s.cluster_memory_gb || 0)} GB`;
  }
  if (ready) {
    const v = $('[data-hud-value="readiness"]', ready);
    const r = Math.round(s.cluster_readiness || 0);
    if (v) v.textContent = `${r}%`;
    ready.title = `集群就绪度 ${r}% · 优化器健康 ${Math.round(model.optimizer_health || 0)}`;
  }

  /* Alerts */
  const contamination = model.risks?.contamination || 0;
  const legalMax = (s.legal_exposures || []).reduce((mx, e) => Math.max(mx, Number(e.level) || 0), 0);
  const bub = s.bubble_pressure || 0;

  toggleAlert('#alert-data', contamination >= 30, contamination >= 60);
  toggleAlert('#alert-legal', legalMax >= 20, legalMax >= 55);
  toggleAlert('#alert-bubble', bub >= 40, bub >= 70);

  const alertData = $('#alert-data [data-alert-value]'); if (alertData) alertData.textContent = contamination >= 60 ? '污染高' : contamination >= 30 ? '污染中' : '正常';
  const alertLegal = $('#alert-legal [data-alert-value]'); if (alertLegal) alertLegal.textContent = legalMax >= 55 ? '高风险' : legalMax >= 20 ? '警告' : '正常';
  const alertBubble = $('#alert-bubble [data-alert-value]'); if (alertBubble) alertBubble.textContent = bub >= 70 ? '爆裂' : bub >= 40 ? '升温' : '平稳';

  /* Footer */
  setText('#turn-footer-turn', `第 ${turn} 回合 · ${SEASON_NAMES[seasonIdx]}`);
  const status = $('#turn-main-action-status');
  if (status) {
    const used = !!s.main_action_used;
    status.classList.toggle('is-available', !used);
    status.classList.toggle('is-used', used);
    status.dataset.mainAction = used ? 'used' : 'available';
    status.textContent = used ? '本回合主行动：已使用' : '本回合主行动：可用';
  }
  setText('#model-turns-left', `${Math.max(0, MAX_TURN - (s.turn || 1))}`);

  /* Toggle buttons pressed state */
  const rv = $('#btn-research-view');
  if (rv) {
    rv.setAttribute('aria-pressed', App.ui.researchView ? 'true' : 'false');
    rv.classList.toggle('is-active', !!App.ui.researchView);
  }
  const tb = $('#btn-tutorial');
  if (tb) {
    tb.setAttribute('aria-pressed', App.ui.tutorial.active ? 'true' : 'false');
    tb.classList.toggle('is-active', !!App.ui.tutorial.active);
  }
}

function toggleAlert(sel, show, danger) {
  const el = $(sel);
  if (!el) return;
  el.hidden = !show;
  el.classList.toggle('is-danger', !!danger);
}

/* -------------------------------------------------------------------------- */
/* 9. Stats panel                                                              */
/* -------------------------------------------------------------------------- */

const _statTrendCache = {};

function renderStatsPanel() {
  const panel = $('#stats-panel');
  if (!panel) return;
  const s = stats();
  const caps = statCaps();
  const preview = App.ui.train.preview;
  const previewGains = preview?.stat_gains || preview?.per_stat_gains || {};

  const rows = STAT_KEYS.map((key) => {
    const v = Math.round(s[key] || 0);
    const cap = Math.round(caps[key] || 1000);
    const pct = Math.max(0, Math.min(100, (v / Math.max(1, cap)) * 100));
    const capPct = Math.max(0, Math.min(100, (cap / 1000) * 100));
    const delta = Number(previewGains[key]) || 0;

    const prev = _statTrendCache[key];
    let trend = '—';
    if (typeof prev === 'number' && prev !== v) trend = fmtSigned(v - prev, 0);
    _statTrendCache[key] = v;

    return `
      <div class="stat-row" data-stat="${key}">
        <span class="stat-label" title="${esc(STAT_LABELS[key])} · 上限 ${cap}">${esc(STAT_LABELS[key])}</span>
        <div class="stat-meter" role="progressbar" aria-label="${esc(STAT_LABELS[key])}"
             aria-valuemin="0" aria-valuemax="${cap}" aria-valuenow="${v}"
             data-stat-meter="${key}">
          <div class="stat-meter__fill" data-stat-fill="${key}" style="width:${pct.toFixed(2)}%"></div>
          <div class="stat-meter__cap" title="能力上限 ${cap}" style="left:${capPct.toFixed(2)}%"></div>
        </div>
        <span class="stat-value" data-stat-value="${key}">${v}</span>
        <span class="stat-trend ${delta > 0 ? 'is-up' : delta < 0 ? 'is-down' : ''}" data-stat-trend="${key}">
          ${delta !== 0 ? fmtSignedF(delta, 1) : trend}
        </span>
      </div>
    `;
  }).join('');

  const total = sumOf(STAT_KEYS.map(k => Math.round(s[k] || 0)));
  const capTotal = sumOf(STAT_KEYS.map(k => Math.round(caps[k] || 0)));

  panel.innerHTML = `
    <header class="panel__header">
      <h2 class="panel__title">六维属性</h2>
      <span class="panel__hint" id="stats-note">
        0–1000 · 合计 ${total} / 上限 ${capTotal}
        ${App.ui.researchView ? `· 均分 ${(total / 6).toFixed(1)}` : ''}
      </span>
    </header>
    ${rows}
    <footer class="stats-panel__foot">
      <button class="btn btn--link" type="button" data-action="stats-detail">查看训练曲线与公式</button>
    </footer>
  `;
}

/* -------------------------------------------------------------------------- */
/* 10. Character stage                                                         */
/* -------------------------------------------------------------------------- */

function historyTheme(historyId) {
  const h = HISTORY_BY_ID[historyId];
  const hue = (typeof h?.theme_hue === 'number') ? h.theme_hue : Math.abs(hashStr(historyId || 'h01')) % 360;
  return {
    hue,
    hair1: `hsl(${hue} 60% 48%)`,
    hair2: `hsl(${(hue + 30) % 360} 55% 30%)`,
    accent: `hsl(${(hue + 200) % 360} 70% 62%)`,
    cloth: `hsl(${(hue + 180) % 360} 30% 22%)`,
  };
}

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}

function renderCharacterStage() {
  const stage = $('#character-stage');
  if (!stage) return;
  const model = activeModel();
  const hist = HISTORY_BY_ID[model.history_id] || { name: '未命名', tagline: '' };
  const theme = historyTheme(model.history_id);
  const emo = EMOTION_MAP[App.emotion] || EMOTION_MAP.neutral;

  setText('#character-name', `代号：${model.display_name || hist.name || '未命名'}`);
  setText('#character-emotion', `情绪：${emo.label}`);
  stage.dataset.emotion = App.emotion;

  const vfx = $('[data-character-vfx]', stage);

  stage.style.setProperty('--theme-hair-1', theme.hair1);
  stage.style.setProperty('--theme-hair-2', theme.hair2);
  stage.style.setProperty('--theme-accent', theme.accent);
  stage.style.setProperty('--theme-cloth', theme.cloth);
  stage.style.setProperty('--theme-glow', emo.color);

  const portrait = $('[data-character-portrait]', stage);
  if (portrait) {
    portrait.innerHTML = buildPortraitSVG(App.emotion, theme);
  }

  const face = $('[data-character-face]', stage);
  if (face) face.textContent = emo.face;

  if (vfx) {
    vfx.hidden = !stage.dataset.emotion || App.emotion === 'neutral';
    vfx.className = `character-stage__vfx character-stage__vfx--${App.emotion}`;
  }

  renderDialogue();
}

function buildPortraitSVG(emotion, theme) {
  const e = emotion || 'neutral';
  const eyes = ({
    neutral: `
      <ellipse cx="76" cy="118" rx="6" ry="7" fill="#1a1f33"/>
      <ellipse cx="124" cy="118" rx="6" ry="7" fill="#1a1f33"/>
      <circle cx="78" cy="115" r="2" fill="#fff"/>
      <circle cx="126" cy="115" r="2" fill="#fff"/>`,
    happy: `
      <path d="M68 118 q8 -10 16 0" stroke="#1a1f33" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M116 118 q8 -10 16 0" stroke="#1a1f33" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    worried: `
      <ellipse cx="76" cy="120" rx="5" ry="6" fill="#1a1f33"/>
      <ellipse cx="124" cy="120" rx="5" ry="6" fill="#1a1f33"/>
      <path d="M68 108 q8 -3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>
      <path d="M116 108 q8 -3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>`,
    determined: `
      <path d="M68 118 l16 0" stroke="#1a1f33" stroke-width="3" stroke-linecap="round"/>
      <path d="M116 118 l16 0" stroke="#1a1f33" stroke-width="3" stroke-linecap="round"/>
      <path d="M68 110 q8 -3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>
      <path d="M116 110 q8 -3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>`,
    sad: `
      <ellipse cx="76" cy="122" rx="6" ry="6" fill="#1a1f33"/>
      <ellipse cx="124" cy="122" rx="6" ry="6" fill="#1a1f33"/>
      <path d="M68 112 q8 3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>
      <path d="M116 112 q8 3 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>
      <circle cx="84" cy="128" r="2" fill="#8ab4ff"/>`,
  }[e] || '');

  const mouth = ({
    neutral: '<path d="M92 148 q8 3 16 0" stroke="#1a1f33" stroke-width="2" fill="none" stroke-linecap="round"/>',
    happy: '<path d="M90 146 q10 8 20 0" stroke="#1a1f33" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    worried: '<path d="M94 150 q6 -4 12 0" stroke="#1a1f33" stroke-width="2" fill="none"/>',
    determined: '<path d="M90 148 l20 0" stroke="#1a1f33" stroke-width="2.5" stroke-linecap="round"/>',
    sad: '<path d="M92 152 q8 -4 16 0" stroke="#1a1f33" stroke-width="2" fill="none"/>',
  }[e] || '');

  const blush = (e === 'happy' || e === 'worried')
    ? `<ellipse cx="62" cy="140" rx="10" ry="5" fill="${theme.accent}" opacity="0.55"/>
       <ellipse cx="138" cy="140" rx="10" ry="5" fill="${theme.accent}" opacity="0.55"/>`
    : '';

  const glasses = `<g opacity="0.85">
    <rect x="56" y="112" width="40" height="18" rx="4" fill="none" stroke="${theme.accent}" stroke-width="1.6"/>
    <rect x="104" y="112" width="40" height="18" rx="4" fill="none" stroke="${theme.accent}" stroke-width="1.6"/>
    <path d="M96 121 L104 121" stroke="${theme.accent}" stroke-width="1.6"/>
  </g>`;

  return `
    <svg class="portrait-svg" viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <radialGradient id="glow" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stop-color="${theme.accent}" stop-opacity="0.45"/>
          <stop offset="100%" stop-color="${theme.accent}" stop-opacity="0"/>
        </radialGradient>
        <linearGradient id="hairg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="${theme.hair1}"/>
          <stop offset="100%" stop-color="${theme.hair2}"/>
        </linearGradient>
      </defs>
      <circle cx="100" cy="120" r="110" fill="url(#glow)"/>

      <!-- body -->
      <path d="M40 240 Q60 182 100 178 Q140 182 160 240 Z" fill="${theme.cloth}"/>
      <path d="M78 190 L100 210 L122 190 L118 240 L82 240 Z" fill="${theme.accent}" opacity="0.75"/>

      <!-- neck -->
      <rect x="88" y="164" width="24" height="22" rx="8" fill="#f7d6c3"/>

      <!-- head -->
      <ellipse cx="100" cy="118" rx="52" ry="58" fill="#fce2d2"/>
      <ellipse cx="100" cy="118" rx="52" ry="58" fill="none" stroke="rgba(0,0,0,0.12)" stroke-width="1"/>

      <!-- hair -->
      <path d="M46 118 Q44 52 100 44 Q156 52 154 118 Q150 90 138 82 Q120 100 100 92 Q80 100 62 82 Q50 90 46 118 Z"
            fill="url(#hairg)"/>
      <path d="M60 100 Q48 138 52 170 Q56 160 58 138 Q58 118 60 100 Z" fill="${theme.hair2}"/>
      <path d="M140 100 Q152 138 148 170 Q144 160 142 138 Q142 118 140 100 Z" fill="${theme.hair2}"/>

      <!-- ears -->
      <ellipse cx="48" cy="122" rx="6" ry="10" fill="#f7d6c3"/>
      <ellipse cx="152" cy="122" rx="6" ry="10" fill="#f7d6c3"/>

      <!-- eyes -->
      ${eyes}
      ${glasses}

      <!-- nose -->
      <path d="M100 130 l-3 8 h6 z" fill="#e6b49a" opacity="0.9"/>

      <!-- mouth -->
      ${mouth}
      ${blush}

      <!-- accent -->
      <circle cx="100" cy="24" r="4" fill="${theme.accent}" opacity="0.9"/>
    </svg>
  `;
}

function renderDialogue() {
  const speaker = App.dialogue?.speaker || '策划';
  const text = App.dialogue?.text || '……';
  const spEl = $('#dialogue-speaker');
  const txEl = $('#dialogue-text');
  if (!spEl || !txEl) return;

  const hist = HISTORY_BY_ID[activeModel().history_id];
  const charName = hist?.name || '策划';

  spEl.textContent = speaker === '角色' ? charName : speaker;

  let html = esc(text);
  if (speaker === '角色') {
    html += ` <button class="btn btn--link btn--inline" type="button" data-action="open-free-dialogue">自由对话 (离线/BYOK)</button>`;
  } else {
    html += ` <button class="btn btn--link btn--inline" type="button" data-action="char-speak">听 TA 说一句</button>`;
  }
  txEl.innerHTML = html;
}

function characterLine() {
  const m = activeModel();
  const avg = avgOf(STAT_KEYS.map(k => m.stats?.[k] || 0));
  const ready = gs()?.cluster_readiness || 0;
  const opt = m.optimizer_health || 0;
  const risksMax = Math.max(0, ...RISK_KEYS.map(k => m.risks?.[k] || 0));

  if (risksMax >= 65) return { emo: 'worried', text: '我有点担心……隐藏风险好像太高了，我们需要回滚一次快照。' };
  if (ready < 30) return { emo: 'determined', text: '集群就绪度不足三成。先整备一下吧——训练前先热身。' };
  if (avg < 60) return { emo: 'neutral', text: '现在还是个很小的版本。你打算先扩数据，还是先把能力抬起来？' };
  if (avg > 300) return { emo: 'happy', text: '状态不错！要不要去排行榜上试一场？' };
  if (opt < 40) return { emo: 'worried', text: '优化器已经在喘了。持续推送可能带来不可逆损失。' };
  return { emo: 'neutral', text: '今天从哪儿开始？训练、数据、整备，还是直接上赛场？' };
}

function charSpeak() {
  const line = characterLine();
  App.dialogue = { speaker: '角色', text: line.text };
  App.emotion = line.emo;
  renderCharacterStage();
}

/* -------------------------------------------------------------------------- */
/* 11. Model summary                                                           */
/* -------------------------------------------------------------------------- */

function nextCupCountdown() {
  const turn = gs()?.turn || 1;
  const cups = [6, 12, 18, 24];
  for (const c of cups) if (turn <= c) return c - turn + 1;
  return 24 - ((turn - 1) % 24);
}

function renderModelSummary() {
  const m = activeModel();
  const hist = HISTORY_BY_ID[m.history_id];
  const arch = ARCH_BY_ID[m.architecture_id];
  setText('#model-name', m.display_name || '未命名模型');
  setText('#model-version-value', `v0.${m.generation_index || 1}.0`);
  setText('#model-version', `v0.${m.generation_index || 1}`);
  setText('#model-tier', arch ? `${arch.tier || 'T1'} · ${arch.family || '小型'}` : 'T1 · 小型');
  setText('#model-stage', m.training_stage || '预训练');
  setText('#model-release-line', `就绪度 ≥ 60% 且 ${
    RISK_KEYS.map(k => Math.round(m.risks?.[k] || 0) >= 80 ? 1 : 0).reduce((a, b) => a + b, 0) === 0
      ? '无高风险' : '无高风险项'
  }`);
  setText('#model-turns-left', `${nextCupCountdown()} 回合后杯赛`);

  const grid = $('#model-summary .model-summary__grid');
  if (!grid) return;
  const derive = (key, val) => {
    const cell = grid.querySelector(`dd#${key}`);
    if (cell) cell.textContent = val;
  };
  derive('model-name', `${m.display_name || '未命名模型'} · ${hist?.name || '未收录'}`);
  derive('model-version-value', `v0.${m.generation_index || 1}.0`);
  derive('model-tier', `${arch?.tier || 'T1'} · ${arch?.family || '小型'} · ${m.sim_total_params_b || 0}B / ${m.sim_active_params_b || 0}B`);
  derive('model-stage', m.training_stage || '预训练');
  derive('model-release-line', `就绪度 ≥ 60%`);
  derive('model-turns-left', `${Math.max(0, MAX_TURN - (gs()?.turn || 1))} 回合`);
}

/* -------------------------------------------------------------------------- */
/* 12. Risks panel                                                             */
/* -------------------------------------------------------------------------- */

function riskLevel(v) {
  if (v >= 75) return { label: '高', cls: 'is-high' };
  if (v >= 45) return { label: '中', cls: 'is-mid' };
  return { label: '低', cls: 'is-low' };
}

function renderRisksPanel() {
  const panel = $('#risks-panel');
  if (!panel) return;
  const m = activeModel();
  const rv = App.ui.researchView;
  const conf = gs()?.audit_confidence ?? 0.7;

  const chips = RISK_KEYS.map(key => {
    const v = Math.round(m.risks?.[key] || 0);
    const lvl = riskLevel(v);
    const val = rv ? String(v) : lvl.label;
    const cls = `risk-chip ${lvl.cls} ${rv ? 'is-exact' : ''}`;
    return `
      <span class="${cls}" role="listitem" data-risk="${key}"
            title="${esc(RISK_LABELS[key])}${rv ? '' : ` · 审计置信度 ${(conf * 100).toFixed(0)}%`}">
        <span class="risk-chip__label">${esc(RISK_LABELS[key])}</span>
        <span class="risk-chip__value" data-risk-value="${key}">${val}</span>
      </span>
    `;
  }).join('');

  const cps = (m.checkpoints || []);
  const cpsHtml = cps.length ? cps.map((cp, i) => `
    <span class="checkpoint-chip ${i === cps.length - 1 ? 'is-open' : 'is-live'}"
          role="listitem" data-checkpoint="${esc(cp.id)}">
      <span class="checkpoint-chip__label">${esc(cp.label || `快照 ${i + 1}`)} · T${cp.turn ?? '?'}</span>
      <span class="checkpoint-chip__state" data-checkpoint-state="${esc(cp.id)}">
        ${i === cps.length - 1 ? '当前' : '可回滚'}
      </span>
    </span>
  `).join('') : `
    <span class="checkpoint-chip is-empty" role="listitem">
      <span class="checkpoint-chip__label">尚无快照</span>
      <span class="checkpoint-chip__state">先做一次训练</span>
    </span>
  `;

  panel.innerHTML = `
    <header class="panel__header">
      <h2 class="panel__title">隐藏风险 · 检查点</h2>
      <span class="panel__hint" id="risks-note">
        ${rv ? '研究视图：精确数值 · audit ' + (conf * 100).toFixed(0) + '%' : '数值越高越危险 · 切换研究视图查看精确值'}
      </span>
    </header>
    <div class="risks-panel__bar" role="list" aria-label="风险指标快捷条">${chips}</div>
    <div class="risks-panel__opt row-space">
      <span class="risk-chip risk-chip--clean">
        <span class="risk-chip__label">优化器健康</span>
        <span class="risk-chip__value" data-risk-value="optimizer_health">
          ${rv ? Math.round(m.optimizer_health || 0) : riskLevel(100 - (m.optimizer_health || 0)).label}
        </span>
      </span>
      <span class="checkpoint-chip__state">检查点间隔：每 ${m.checkpoint_interval_actions || 2} 次行动</span>
      <span class="checkpoint-chip__state">已积 ${m.actions_since_checkpoint || 0} / ${m.checkpoint_interval_actions || 2}</span>
    </div>
    <div class="checkpoint-bar" role="list" aria-label="检查点">${cpsHtml}</div>
  `;
}

/* -------------------------------------------------------------------------- */
/* 13. Deck panel                                                              */
/* -------------------------------------------------------------------------- */

function renderDeckPanel() {
  const panel = $('#deck-panel');
  if (!panel) return;
  const s = gs(); if (!s) return;

  const ids = (s.support_card_ids || []).slice(0, 4);
  while (ids.length < 4) ids.push(null);

  const bond = s.support_bond || {};

  const cardsHtml = ids.map((id, i) => {
    const card = id ? CARD_BY_ID[id] : null;
    const b = bond[id] ?? (id ? bond[i] : 0) ?? 0;
    if (!card) {
      return `<li class="support-card is-empty" data-card-slot="${i}" data-action="open-card-editor" data-slot="${i}">空槽位 · 点击装备</li>`;
    }
    const bondPct = clamp(Number(b) || 0, 0, 100);
    return `
      <li class="support-card" data-card-slot="${i}" data-card-id="${esc(id)}" title="${esc(card.description || '')}">
        <span class="support-card__name">${esc(card.name || id)}</span>
        <span class="support-card__desc">${esc((card.description || '').slice(0, 40))}</span>
        <div class="support-card__bond" title="羁绊 ${bondPct}">
          <div class="support-card__bond-fill" style="width:${bondPct}%"></div>
        </div>
        <button class="btn btn--tiny btn--link" type="button" data-action="open-card-editor" data-slot="${i}">更换</button>
      </li>
    `;
  }).join('');

  const teacherIds = (s.teacher_model_ids || []);
  const mentorsHtml = [0, 1].map(i => {
    const id = teacherIds[i];
    const hist = id ? HISTORY_BY_ID[id] : null;
    if (!hist) {
      return `
        <li class="mentor-item is-idle" data-mentor-slot="${i}" data-action="open-mentor-editor" data-slot="${i}">
          <span class="mentor-item__name">未招募</span>
          <span class="mentor-item__bonus">—</span>
        </li>
      `;
    }
    const inh = typeof calculateMentorInheritance === 'function'
      ? (safeCall('mentor inherit', () => calculateMentorInheritance(s, id)) || {})
      : {};
    const bonus = inh.summary || `${Object.keys(inh.bonus || {}).length} 项继承`;
    return `
      <li class="mentor-item" data-mentor-slot="${i}" data-mentor-id="${esc(id)}" title="${esc(bonus)}">
        <span class="mentor-item__name">${esc(hist.name || id)}</span>
        <span class="mentor-item__bonus">${esc(String(bonus).slice(0, 30))}</span>
        <button class="btn btn--tiny btn--link" type="button" data-action="open-mentor-editor" data-slot="${i}">更换</button>
      </li>
    `;
  }).join('');

  panel.innerHTML = `
    <header class="panel__header">
      <h2 class="panel__title">支援卡 · 导师</h2>
      <span class="panel__hint" id="deck-count">手牌 ${ids.filter(Boolean).length} / 上限 4</span>
    </header>
    <div class="deck-panel__section">
      <h3 class="deck-panel__subtitle">支援卡</h3>
      <ul class="support-cards" id="support-cards" aria-label="支援卡列表">${cardsHtml}</ul>
    </div>
    <div class="deck-panel__section">
      <h3 class="deck-panel__subtitle">导师（继承）</h3>
      <ul class="mentor-list" id="mentor-list" aria-label="导师列表">${mentorsHtml}</ul>
    </div>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14. Tabs: main content rendering                                            */
/* -------------------------------------------------------------------------- */

function renderActiveTab() {
  const container = $('#tab-content');
  if (!container) return;
  const tab = App.ui.activeTab || 'train';

  $$('.tab', $('#main-tabs')).forEach(t => {
    const isActive = t.dataset.tab === tab;
    t.setAttribute('aria-selected', isActive ? 'true' : 'false');
    t.setAttribute('tabindex', isActive ? '0' : '-1');
    t.classList.toggle('is-active', isActive);
  });
  container.dataset.activeTab = tab;

  $$('[data-tab-panel]', container).forEach(p => {
    p.hidden = p.dataset.tabPanel !== tab;
  });

  const panel = $(`[data-tab-panel="${tab}"]`, container);
  if (!panel) return;
  panel.innerHTML = renderTabContent(tab);
  bindTabDelegates(panel);
}

function renderTabContent(tab) {
  switch (tab) {
    case 'train':    return renderTrainTab();
    case 'data':     return renderDataTab();
    case 'prep':     return renderPrepTab();
    case 'race':     return renderRaceTab();
    case 'company':  return renderCompanyTab();
    case 'codex':    return renderCodexTab();
    case 'settings': return renderSettingsTab();
    default:         return '';
  }
}

/* -------------------------------------------------------------------------- */
/* 14a. Train tab                                                              */
/* -------------------------------------------------------------------------- */

function renderTrainTab() {
  const s = gs(); if (!s) return '';
  const recipes = recipeList();
  if (!App.ui.train.recipeId && recipes.length) App.ui.train.recipeId = recipes[0].id;
  const tr = App.ui.train;

  const focusOptions = [
    { id: 'mixed', label: '综合' },
    ...STAT_KEYS.map(k => ({ id: k, label: STAT_LABELS[k] })),
  ];

  const presetOptions = [
    { id: 'steady', label: '稳健（低风险）' },
    { id: 'balanced', label: '均衡' },
    { id: 'push', label: '激进（高风险）' },
  ];

  const modeOptions = [
    { id: 'lora', label: 'LoRA' },
    { id: 'qlora', label: 'QLoRA' },
    { id: 'full', label: '全参' },
  ];

  const dsOptions = (s.datasets || []).map(d => {
    const tpl = DATASET_TEMPLATE_BY_ID[d.template_id] || d;
    return { id: d.id, label: `${tpl.name || d.name || d.id} · ${tpl.format || d.format || '?'} · ${(d.records_k ?? tpl.records_k ?? 0)}k` };
  });
  if (!dsOptions.length) dsOptions.push({ id: null, label: '（暂无数据集——先去「数据」页采集）' });

  const preview = App.ui.train.preview;
  const blockers = preview?.blockers || preview?.errors || [];

  const previewRows = preview ? STAT_KEYS.map(k => {
    const g = Number(preview?.stat_gains?.[k] ?? preview?.per_stat_gains?.[k] ?? 0);
    return `<li><span>${STAT_LABELS[k]}</span><span class="delta ${g > 0 ? 'up' : g < 0 ? 'down' : ''}">${fmtSignedF(g, 1)}</span></li>`;
  }).join('') : '';

  const adv = tr.advanced;

  const advOpen = tr.advancedOpen ? '' : 'hidden';

  const cost = preview?.cost_kc ?? preview?.total_kc ?? preview?.cash_kc ?? '—';
  const compute = preview?.compute_cu ?? preview?.mem_cu ?? '—';
  const memory = preview?.memory_gb ?? preview?.peak_memory_gb ?? '—';
  const gain = preview?.expected_total_gain ?? preview?.expected_gain ?? 0;
  const failP = preview?.failure_prob ?? preview?.fail_prob ?? 0;

  return `
    <h2 class="tab-panel__title">训练</h2>
    <p class="tab-panel__text">
      选择本回合的训练方案。方案消耗算力与资金，提升能力，并可能改变对齐与技术债。
    </p>

    <div class="train-bar" role="group" aria-label="新手三选">
      <div class="train-bar__col">
        <label class="field-label">焦点属性</label>
        <div class="chip-row">
          ${focusOptions.map(o => `
            <button class="chip ${tr.focus === o.id ? 'is-active' : ''}" type="button"
                    data-action="train-focus" data-value="${o.id}">${esc(o.label)}</button>
          `).join('')}
        </div>
      </div>
      <div class="train-bar__col">
        <label class="field-label">预设强度</label>
        <div class="chip-row">
          ${presetOptions.map(o => `
            <button class="chip ${tr.preset === o.id ? 'is-active' : ''}" type="button"
                    data-action="train-preset" data-value="${o.id}">${esc(o.label)}</button>
          `).join('')}
        </div>
      </div>
    </div>

    <fieldset class="fieldset">
      <legend>训练配方（全 10 种）</legend>
      <div class="grid-2">
        ${recipes.map(r => `
          <button class="tile ${tr.recipeId === r.id ? 'is-active' : ''}" type="button"
                  data-action="train-recipe" data-value="${esc(r.id)}"
                  title="${esc(r.description || '')}">
            <span class="tile__title">${esc(r.name || r.id)}</span>
            <span class="tile__meta">${esc(r.focus || '通用')} · ${fmtKc(r.base_cost_kc ?? r.cost_kc ?? 0)} · ${fmtCu(r.base_compute_cu ?? r.compute_cu ?? 0)}</span>
          </button>
        `).join('')}
      </div>
    </fieldset>

    <div class="grid-3">
      <label class="field">
        <span class="field-label">数据集</span>
        <select class="input" data-train-field="datasetId">
          ${dsOptions.map(o => `<option value="${esc(o.id || '')}" ${tr.datasetId === o.id ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}
        </select>
      </label>
      <label class="field">
        <span class="field-label">训练模式</span>
        <select class="input" data-train-field="mode">
          ${modeOptions.map(o => `<option value="${o.id}" ${tr.mode === o.id ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}
        </select>
      </label>
      <label class="field">
        <span class="field-label">检查点间隔</span>
        <select class="input" data-train-field="checkpoint_interval">
          ${[1, 2, 4].map(n => `<option value="${n}" ${activeModel().checkpoint_interval_actions === n ? 'selected' : ''}>每 ${n} 次行动</option>`).join('')}
        </select>
      </label>
    </div>

    <details class="details" ${tr.advancedOpen ? 'open' : ''} data-train-advanced>
      <summary data-action="toggle-train-adv">高级参数 <span class="hint">（可选，全部影响预览公式）</span></summary>
      <div class="grid-3" ${advOpen}>
        ${renderNumberField('epochs', 'Epochs', adv.epochs, 1, 20, 1)}
        ${renderNumberField('replay_ratio', 'Replay Ratio', adv.replay_ratio, 0, 0.9, 0.05)}
        ${renderNumberField('batch_size', 'Batch Size', adv.batch_size, 8, 512, 8)}
        ${renderNumberField('lora_rank', 'LoRA Rank', adv.lora_rank, 4, 256, 4)}
        ${renderNumberField('group_size', 'Group Size', adv.group_size, 1, 32, 1)}
        ${renderNumberField('reasoning_budget_tokens', '推理预算 (tokens)', adv.reasoning_budget_tokens, 256, 65536, 256)}
        ${renderNumberField('kl_strength', 'KL 强度', adv.kl_strength, 0, 0.5, 0.01)}
        ${renderNumberField('mask_ratio', 'Mask 比例', adv.mask_ratio, 0, 0.6, 0.01)}
        ${renderNumberField('denoise_steps', '去噪步数 (diffusion)', adv.denoise_steps, 4, 64, 4)}
      </div>
      <label class="check">
        <input type="checkbox" data-train-field="accept_legal_risk" ${adv.accept_legal_risk ? 'checked' : ''}/>
        <span>接受法律风险（允许使用灰色来源数据，+法律曝光）</span>
      </label>
    </details>

    <section class="preview-panel">
      <header class="preview-panel__header">
        <h3>预览</h3>
        <span class="preview-panel__hint">${preview ? '实时计算' : '选择配方后自动预览'}</span>
      </header>
      <div class="preview-panel__grid">
        <div class="kv"><span>资金成本</span><b>${typeof cost === 'number' ? fmtKc(cost) : cost}</b></div>
        <div class="kv"><span>算力消耗</span><b>${typeof compute === 'number' ? fmtCu(compute) : compute}</b></div>
        <div class="kv"><span>峰值内存</span><b>${typeof memory === 'number' ? fmtGB(memory) : memory}</b></div>
        <div class="kv"><span>预期总收益</span><b>${fmtSignedF(gain, 1)}</b></div>
        <div class="kv"><span>失败概率</span><b>${fmtPct(failP, 1)}</b></div>
        <div class="kv"><span>优化器健康</span><b>${Math.round(activeModel().optimizer_health || 0)}</b></div>
      </div>
      ${previewRows ? `<ul class="preview-rows">${previewRows}</ul>` : ''}
      ${blockers.length ? `
        <ul class="blockers">
          ${blockers.map(b => `<li>⛔ ${esc(typeof b === 'string' ? b : b.message || JSON.stringify(b))}</li>`).join('')}
        </ul>
      ` : ''}
    </section>

    <div class="actions-row">
      <button class="btn btn--primary btn--large" type="button"
              data-action="run-training"
              ${gs()?.main_action_used ? 'disabled' : ''}>
        确认执行本次训练（消耗本回合主行动）
      </button>
      <button class="btn btn--ghost" type="button" data-action="preview-training">重新计算预览</button>
    </div>
  `;
}

function renderNumberField(key, label, value, min, max, step) {
  return `
    <label class="field">
      <span class="field-label">${esc(label)}</span>
      <input class="input" type="number" data-train-adv="${key}"
             value="${esc(value)}" min="${min}" max="${max}" step="${step}"/>
    </label>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14b. Data tab                                                               */
/* -------------------------------------------------------------------------- */

function renderDataTab() {
  const s = gs(); if (!s) return '';

  const datasetsHtml = (s.datasets || []).length ? (s.datasets || []).map(d => {
    const tpl = DATASET_TEMPLATE_BY_ID[d.template_id] || {};
    const quality = d.quality ?? tpl.quality ?? 0.5;
    const trueQ = d.true_quality ?? quality;
    const novelty = d.novelty ?? tpl.novelty ?? 0.3;
    return `
      <tr>
        <td>${esc(tpl.name || d.name || d.id)}</td>
        <td>${esc(tpl.format || d.format || '—')}</td>
        <td>${(d.records_k ?? tpl.records_k ?? 0)}k</td>
        <td>${fmtPct(quality, 0)}${App.ui.researchView ? ` / ${fmtPct(trueQ, 0)}` : ''}</td>
        <td>${fmtPct(novelty, 0)}</td>
        <td>${d.uses ?? 0}</td>
        <td><span class="badge badge--${d.rights_status === 'clear' ? 'good' : d.rights_status === 'gray' ? 'warn' : 'bad'}">${esc(d.rights_status || 'unknown')}</span></td>
        <td>${esc(d.provenance || tpl.provenance || '未知')}</td>
      </tr>
    `;
  }).join('') : `<tr><td colspan="8" class="empty-row">暂无数据集，先在数据市场采集或委托标注团队。</td></tr>`;

  const routes = routeList();
  const market = (s.data_market || []).length ? s.data_market : [];
  const marketHtml = market.map((offer, i) => {
    const tpl = DATASET_TEMPLATE_BY_ID[offer.template_id] || offer;
    return `
      <div class="offer-card" data-offer="${i}">
        <div class="offer-card__head">
          <span class="offer-card__name">${esc(tpl.name || offer.name || `要约 ${i + 1}`)}</span>
          <span class="offer-card__price">${fmtKc(offer.price_kc ?? tpl.base_price_kc ?? 0)}</span>
        </div>
        <ul class="offer-card__meta">
          <li>格式：${esc(tpl.format || '—')}</li>
          <li>规模：${(tpl.records_k ?? offer.records_k ?? 0)}k</li>
          <li>显示质量：${fmtPct(tpl.quality ?? offer.quality ?? 0.5, 0)}</li>
          ${App.ui.researchView ? `<li>真实质量：${fmtPct(offer.true_quality ?? tpl.true_quality ?? tpl.quality ?? 0.5, 0)}</li>` : ''}
          <li>权利：<span class="badge badge--${offer.rights_status === 'clear' ? 'good' : 'warn'}">${esc(offer.rights_status || 'unknown')}</span></li>
        </ul>
        <div class="offer-card__actions">
          <button class="btn btn--primary btn--small" data-action="acquire-offer" data-index="${i}">直接采购</button>
          <button class="btn btn--ghost btn--small" data-action="start-minigame" data-index="${i}">30秒小游戏</button>
          <button class="btn btn--ghost btn--small" data-action="auto-delegate" data-index="${i}" title="自动委托给助理AI：+5% 品质/成本加成">自动委托</button>
        </div>
      </div>
    `;
  }).join('') || `<div class="empty-row">数据市场本回合暂无要约，点击「刷新市场」重新抽取（每回合自动刷新）。</div>`;

  const mg = App.ui.data.miniGame;
  const mgHtml = mg ? renderMiniGame(mg) : '';

  const annDraft = App.ui.data.annotationDraft;
  const teams = teamList();
  const labels = labelList();

  let draftPreview = '';
  if (annDraft.teamId && annDraft.methodId) {
    const res = typeof calculateAnnotationQuality === 'function'
      ? safeCall('annot preview', () => calculateAnnotationQuality({
          team_id: annDraft.teamId,
          method_id: annDraft.methodId,
          fair_pay_ratio: annDraft.fair_pay_ratio,
          gold_check_ratio: annDraft.gold_check_ratio,
          independent_audit_ratio: annDraft.independent_audit_ratio,
          size_k: annDraft.size_k,
        })) || {}
      : {};
    draftPreview = `
      <div class="kv-row">
        <div class="kv"><span>预计品质</span><b>${fmtPct(res.quality ?? 0.6, 0)}</b></div>
        <div class="kv"><span>预计成本</span><b>${fmtKc(res.cost_kc ?? 0)}</b></div>
        <div class="kv"><span>预计回合</span><b>${res.turns ?? 1}</b></div>
        <div class="kv"><span>法律曝光</span><b>${fmtSigned(res.legal_delta ?? 0, 0)}</b></div>
      </div>
    `;
  }

  const contractsHtml = (s.annotation_contracts || []).length
    ? (s.annotation_contracts || []).map(c => `
        <li class="contract-row">
          <span class="contract-row__name">${esc(c.name || c.id)}</span>
          <span class="contract-row__meta">团队 ${esc(c.team_id || '—')} · 方法 ${esc(c.method_id || '—')} · ${(c.size_k ?? 0)}k</span>
          <span class="contract-row__progress">
            <span class="bar"><span class="bar__fill" style="width:${clamp((c.progress ?? 0) * 100, 0, 100)}%"></span></span>
            ${fmtPct(c.progress ?? 0, 0)}
          </span>
          <span class="contract-row__quality">${fmtPct(c.quality ?? 0, 0)}</span>
        </li>
      `).join('')
    : `<li class="empty-row">暂无进行中的标注合约。</li>`;

  return `
    <h2 class="tab-panel__title">数据与标注</h2>
    <p class="tab-panel__text">
      采集、清洗、标注与合成数据。数据决定能力上限，也决定数据枯竭与法律曝光的增长。
    </p>

    <section class="card">
      <header class="card__header">
        <h3>数据仓库</h3>
        <span class="hint">${(s.datasets || []).length} 个数据集</span>
      </header>
      <table class="table">
        <thead>
          <tr>
            <th>名称</th><th>格式</th><th>规模</th><th>品质${App.ui.researchView ? '（显示/真实）' : ''}</th>
            <th>新颖度</th><th>使用次数</th><th>权利</th><th>来源</th>
          </tr>
        </thead>
        <tbody>${datasetsHtml}</tbody>
      </table>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>季度数据市场（${market.length} / 6）</h3>
        <button class="btn btn--ghost btn--small" data-action="refresh-market">刷新市场</button>
      </header>
      <div class="grid-3">${marketHtml}</div>
      ${mgHtml}
    </section>

    <section class="card">
      <header class="card__header">
        <h3>委托标注团队</h3>
        <span class="hint">品质 = f(团队, 方法, 公平报酬, 金标比例, 独立审计)</span>
      </header>
      <div class="grid-3">
        <label class="field">
          <span class="field-label">标注团队</span>
          <select class="input" data-ann-field="teamId">
            <option value="">选择团队…</option>
            ${teams.map(t => `<option value="${esc(t.id)}" ${annDraft.teamId === t.id ? 'selected' : ''}>${esc(t.name || t.id)}</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">标注方法</span>
          <select class="input" data-ann-field="methodId">
            <option value="">选择方法…</option>
            ${labels.map(l => `<option value="${esc(l.id)}" ${annDraft.methodId === l.id ? 'selected' : ''}>${esc(l.name || l.id)}</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">规模 (k)</span>
          <input type="number" class="input" min="10" max="1000" step="10"
                 data-ann-field="size_k" value="${esc(annDraft.size_k)}"/>
        </label>
      </div>
      <div class="grid-3">
        <label class="field">
          <span class="field-label">公平报酬 ${fmtPct(annDraft.fair_pay_ratio, 0)}</span>
          <input type="range" class="input input--range" min="0" max="1" step="0.05"
                 data-ann-field="fair_pay_ratio" value="${esc(annDraft.fair_pay_ratio)}"/>
        </label>
        <label class="field">
          <span class="field-label">金标检查 ${fmtPct(annDraft.gold_check_ratio, 0)}</span>
          <input type="range" class="input input--range" min="0" max="0.5" step="0.01"
                 data-ann-field="gold_check_ratio" value="${esc(annDraft.gold_check_ratio)}"/>
        </label>
        <label class="field">
          <span class="field-label">独立审计 ${fmtPct(annDraft.independent_audit_ratio, 0)}</span>
          <input type="range" class="input input--range" min="0" max="0.5" step="0.01"
                 data-ann-field="independent_audit_ratio" value="${esc(annDraft.independent_audit_ratio)}"/>
        </label>
      </div>
      ${draftPreview}
      <div class="actions-row">
        <button class="btn btn--primary" data-action="start-annotation" ${gs()?.main_action_used ? 'disabled' : ''}>启动标注合约</button>
        <button class="btn btn--ghost" data-action="advance-annotations">推进合约（每回合结算）</button>
      </div>

      <h4>进行中的合约</h4>
      <ul class="contract-list">${contractsHtml}</ul>
    </section>
  `;
}

function renderMiniGame(mg) {
  const titles = { course: '挑课程', dedupe: '找重复', inspect: '抽检桌', road: '数据公路' };
  const title = titles[mg.kind] || '数据小游戏';
  const remaining = Math.max(0, Math.ceil(mg.remaining || 0));
  return `
    <div class="minigame" data-minigame>
      <header class="minigame__header">
        <b>${esc(title)}</b>
        <span class="minigame__timer">倒计时 ${remaining}s</span>
      </header>
      <div class="minigame__board">
        ${renderMiniGameBoard(mg)}
      </div>
      <footer class="minigame__foot">
        <button class="btn btn--ghost btn--small" data-action="minigame-cancel">放弃（改走自动委托）</button>
      </footer>
    </div>
  `;
}

function renderMiniGameBoard(mg) {
  if (mg.kind === 'course') {
    const good = mg.answer ?? Math.floor(Math.random() * 6);
    return ['预训练基线', '长文回放', '多语对话', '指令微调', '代码多轮', '工具调用'].map((n, i) => `
      <button class="minigame-tile" data-action="minigame-pick" data-value="${i}">
        ${esc(n)}
      </button>
    `).join('');
  }
  if (mg.kind === 'dedupe') {
    return `<div class="minigame-pairs">
      ${Array.from({ length: 6 }).map((_, i) => `
        <button class="minigame-pair" data-action="minigame-dedupe" data-value="${i}">样本 ${i + 1}</button>
      `).join('')}
    </div>`;
  }
  if (mg.kind === 'inspect') {
    return ['正常', '正常', '异常', '正常', '正常', '异常'].map((label, i) => `
      <button class="minigame-inspect" data-action="minigame-inspect" data-value="${i}">样本 ${i + 1}</button>
    `).join('');
  }
  return `
    <div class="minigame-road">
      ${['起点', '清洗', '去重', '对齐', '封存'].map((n, i) => `
        <button class="minigame-step" data-action="minigame-road" data-value="${i}">${esc(n)}</button>
      `).join('')}
    </div>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14c. Prep tab                                                               */
/* -------------------------------------------------------------------------- */

function renderPrepTab() {
  const s = gs(); if (!s) return '';
  const m = activeModel();

  const cps = (m.checkpoints || []).map((cp, i) => `
    <li class="cp-row" data-cp="${esc(cp.id)}">
      <span class="cp-row__label">${esc(cp.label || `快照 ${i + 1}`)}</span>
      <span class="cp-row__turn">T${cp.turn ?? '?'} · 间隔 ${cp.interval ?? m.checkpoint_interval_actions}</span>
      <span class="cp-row__action">
        <button class="btn btn--ghost btn--small" data-action="rollback-cp" data-id="${esc(cp.id)}">回滚到此快照</button>
      </span>
    </li>
  `).join('') || `<li class="empty-row">模型尚无任何快照。</li>`;

  const previewRest = typeof previewRestAndPrep === 'function'
    ? (safeCall('preview rest', () => previewRestAndPrep(s)) || {})
    : {};
  const restCost = previewRest.cost_kc ?? 8;
  const restReadiness = previewRest.readiness_gain ?? 35;
  const restOpt = previewRest.optimizer_gain ?? 10;
  const cardBonus = (s.support_card_ids || []).includes('card_3am_ops');

  const cards = cardList();
  const myCards = s.support_card_ids || [];

  const mentorOptions = historyList();
  const mentorFrom = App.ui.prep.mentorFrom;

  const currentCompute = s.cluster_compute_cu || 0;
  const currentMemory = s.cluster_memory_gb || 0;
  const defense = s.defense_level || 1;

  return `
    <h2 class="tab-panel__title">整备与快照</h2>
    <p class="tab-panel__text">
      升级基础设施、偿还技术债、保存快照。快照可以在事故后回滚，但会消耗资金与回合资源。
    </p>

    <section class="card">
      <header class="card__header">
        <h3>集群整备</h3>
        <span class="hint">恢复就绪度、清理优化器</span>
      </header>
      <div class="kv-row">
        <div class="kv"><span>资金</span><b>${fmtKc(restCost)}</b></div>
        <div class="kv"><span>就绪度增益</span><b>+${restReadiness}${cardBonus ? '（+10 3am_ops 加成）' : ''}</b></div>
        <div class="kv"><span>优化器健康</span><b>+${restOpt}</b></div>
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="do-rest" ${gs()?.main_action_used ? 'disabled' : ''}>执行整备</button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>检查点与回滚</h3>
        <span class="hint">回滚模型到安全点（不还原资金 / 法律档案 / 溯源）</span>
      </header>
      <div class="grid-2">
        <label class="field">
          <span class="field-label">检查点间隔</span>
          <select class="input" data-prep-field="cp_interval">
            ${[1, 2, 4].map(n => `<option value="${n}" ${m.checkpoint_interval_actions === n ? 'selected' : ''}>每 ${n} 次行动自动快照</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">已积行动</span>
          <input class="input" disabled value="${m.actions_since_checkpoint || 0} / ${m.checkpoint_interval_actions || 2}"/>
        </label>
      </div>
      <ul class="cp-list">${cps}</ul>
      <p class="hint">
        注意：回滚<b>不会</b>恢复累计资金、法律档案与数据集溯源记录——它们代表已经发生的支出与风险。
      </p>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>支援卡 · 卡组编辑</h3>
        <span class="hint">当前 ${myCards.length} / 4 张</span>
      </header>
      <div class="deck-editor">
        ${[0, 1, 2, 3].map(slot => {
          const id = myCards[slot];
          const c = id ? CARD_BY_ID[id] : null;
          return `
            <label class="field">
              <span class="field-label">槽位 ${slot + 1}</span>
              <select class="input" data-prep-field="card_slot_${slot}">
                <option value="">（空）</option>
                ${cards.map(card => `<option value="${esc(card.id)}" ${id === card.id ? 'selected' : ''}>${esc(card.name || card.id)}</option>`).join('')}
              </select>
            </label>
          `;
        }).join('')}
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="save-cards">保存卡组</button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>导师继承</h3>
        <span class="hint">从已封存模型或历史人物继承 / 提升谱系</span>
      </header>
      <div class="grid-2">
        <label class="field">
          <span class="field-label">从哪位导师继承</span>
          <select class="input" data-prep-field="mentor_from">
            <option value="">选择导师…</option>
            ${mentorOptions.map(h => `<option value="${esc(h.id)}" ${mentorFrom === h.id ? 'selected' : ''}>${esc(h.name || h.id)}</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">目标槽位</span>
          <select class="input" data-prep-field="mentor_slot">
            <option value="0">槽位 1</option>
            <option value="1">槽位 2</option>
          </select>
        </label>
      </div>
      ${mentorFrom && typeof calculateMentorInheritance === 'function' ? (() => {
        const inh = safeCall('mentor preview', () => calculateMentorInheritance(s, mentorFrom)) || {};
        return `
          <div class="kv-row">
            <div class="kv"><span>继承加成</span><b>${esc(inh.summary || '—')}</b></div>
          </div>
        `;
      })() : ''}
      <div class="actions-row">
        <button class="btn btn--primary" data-action="do-inherit">应用导师继承</button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>集群扩展与防御</h3>
        <span class="hint">当前：${fmtCu(currentCompute)} · ${fmtGB(currentMemory)} · 防御 Lv${defense}</span>
      </header>
      <div class="grid-3">
        <div class="upgrade-tile">
          <h4>算力升级 +16 CU</h4>
          <p class="hint">花费 ¥24k · 提升训练与参赛上限</p>
          <button class="btn btn--primary" data-action="expand-compute">升级算力</button>
        </div>
        <div class="upgrade-tile">
          <h4>内存升级 +128 GB</h4>
          <p class="hint">花费 ¥18k · 降低 OOM 风险</p>
          <button class="btn btn--primary" data-action="expand-memory">升级内存</button>
        </div>
        <div class="upgrade-tile">
          <h4>防御等级 +1</h4>
          <p class="hint">花费 ¥16k · 降低法律曝光与安全漏洞</p>
          <button class="btn btn--primary" data-action="expand-defense">升级防御</button>
        </div>
      </div>
    </section>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14d. Race tab                                                               */
/* -------------------------------------------------------------------------- */

function renderRaceTab() {
  const s = gs(); if (!s) return '';
  const uiRace = App.ui.race;

  const schedule = [6, 12, 18, 24].map(t => {
    const cur = s.turn || 1;
    const passed = cur > t;
    const next = cur <= t;
    return `
      <span class="cup-chip ${passed ? 'is-passed' : next ? 'is-next' : ''}">
        <span class="cup-chip__turn">T${t}</span>
        <span class="cup-chip__label">${passed ? '已结束' : next ? `${t - cur + 1} 回合后` : '待开启'}</span>
      </span>
    `;
  }).join('');

  const benches = benchList().map(b => {
    const eligible = !b.required_stat || (activeModel().stats?.[b.required_stat] || 0) >= (b.required_min || 0);
    return `
      <label class="tile tile--radio ${uiRace.benchmarkId === b.id ? 'is-active' : ''} ${eligible ? '' : 'is-locked'}">
        <input type="radio" name="benchmark-pick" data-race-field="benchmarkId" value="${esc(b.id)}"
               ${uiRace.benchmarkId === b.id ? 'checked' : ''} ${eligible ? '' : 'disabled'}/>
        <span class="tile__title">${esc(b.name || b.id)}</span>
        <span class="tile__meta">${esc(b.family || '综合')} · 权重 ${fmtNum(b.weight ?? 1, 2)}</span>
        <span class="tile__desc">${esc((b.description || '').slice(0, 60))}</span>
      </label>
    `;
  }).join('');

  const preview = App.ui.race.preview || {};
  const lastResult = App.ui.race.lastResult;

  const previewHtml = preview && Object.keys(preview).length ? `
    <div class="preview-panel__grid">
      <div class="kv"><span>预计名次</span><b>${preview.rank ?? '—'}</b></div>
      <div class="kv"><span>公开得分</span><b>${fmtNum(preview.public_score ?? 0, 1)}</b></div>
      <div class="kv"><span>隐藏得分</span><b>${App.ui.researchView ? fmtNum(preview.hidden_score ?? 0, 1) : '???'}</b></div>
      <div class="kv"><span>报名费</span><b>${fmtKc(preview.entry_kc ?? 0)}</b></div>
      <div class="kv"><span>预算倍率</span><b>${fmtNum(preview.league_mult ?? 1, 2)}</b></div>
      <div class="kv"><span>思维倍率</span><b>${fmtNum(preview.thinking_mult ?? 1, 2)}</b></div>
    </div>
  ` : '';

  return `
    <h2 class="tab-panel__title">赛事竞技</h2>
    <p class="tab-panel__text">报名排行榜、基准评测与公开赛。参赛提升声誉，但也会放大对齐与安全上的失误。</p>

    <section class="card">
      <header class="card__header">
        <h3>杯赛日程</h3>
        <span class="hint">每赛季第 6 / 12 / 18 / 24 回合</span>
      </header>
      <div class="cup-bar">${schedule}</div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>赛事配置</h3>
      </header>
      <div class="grid-3">
        <label class="field">
          <span class="field-label">联赛等级</span>
          <select class="input" data-race-field="league_tier">
            ${LEAGUE_TIERS.map(t => `<option value="${t}" ${uiRace.league_tier === t ? 'selected' : ''}>${t} (×${fmtNum(LEAGUE_BUDGET_MULTIPLIERS?.[t] ?? 1, 2)})</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">思维模式</span>
          <select class="input" data-race-field="thinking_mode">
            ${THINKING_MODES.map(t => `<option value="${t}" ${uiRace.thinking_mode === t ? 'selected' : ''}>${t} (×${fmtNum(THINKING_MULTIPLIERS?.[t] ?? 1, 2)})</option>`).join('')}
          </select>
        </label>
        <label class="field">
          <span class="field-label">去噪步数（diffusion 家族）</span>
          <select class="input" data-race-field="denoise_steps">
            ${[8, 16, 32].map(n => `<option value="${n}" ${uiRace.denoise_steps === n ? 'selected' : ''}>${n}</option>`).join('')}
          </select>
        </label>
      </div>
      <label class="check">
        <input type="checkbox" data-race-field="auto_skill" ${uiRace.auto_skill ? 'checked' : ''}/>
        <span>自动释放技能（关闭后在回放中手动触发）</span>
      </label>
      <h4>可选基准（12 项）</h4>
      <div class="grid-3">${benches}</div>
    </section>

    <section class="preview-panel">
      <header class="preview-panel__header"><h3>预览</h3></header>
      ${previewHtml || '<p class="hint">选择一个基准并点击「预览」查看结果。</p>'}
    </section>

    <div class="actions-row">
      <button class="btn btn--ghost" data-action="preview-race">预览</button>
      <button class="btn btn--primary btn--large" data-action="start-race" ${gs()?.main_action_used ? 'disabled' : ''}>
        报名并开始比赛
      </button>
    </div>

    ${lastResult ? `
      <section class="card">
        <header class="card__header"><h3>上一场比赛</h3></header>
        <div class="kv-row">
          <div class="kv"><span>名次</span><b>${lastResult.rank ?? '—'}</b></div>
          <div class="kv"><span>公开得分</span><b>${fmtNum(lastResult.public_score ?? 0, 1)}</b></div>
          <div class="kv"><span>声誉增益</span><b>${fmtSigned(lastResult.reputation_gain ?? 0, 0)}</b></div>
        </div>
      </section>
    ` : ''}
  `;
}

/* -------------------------------------------------------------------------- */
/* 14e. Company tab                                                            */
/* -------------------------------------------------------------------------- */

function renderCompanyTab() {
  const s = gs(); if (!s) return '';
  const section = App.ui.company.section || 'product';

  const subnav = `
    <nav class="subnav" role="tablist">
      ${[
        ['product', '产品与财报'],
        ['finance', '融资 · IPO · 证券'],
        ['research', '架构科研 · RSI'],
        ['legal', '法务档案'],
        ['sectors', '职业终验 · 泡沫'],
      ].map(([id, label]) => `
        <button class="subnav__item ${section === id ? 'is-active' : ''}" data-action="company-section" data-value="${id}">
          ${esc(label)}
        </button>
      `).join('')}
    </nav>
  `;

  let body = '';
  switch (section) {
    case 'product':  body = renderCompanyProduct(); break;
    case 'finance':  body = renderCompanyFinance(); break;
    case 'research': body = renderCompanyResearch(); break;
    case 'legal':    body = renderCompanyLegal(); break;
    case 'sectors':  body = renderCompanySectors(); break;
  }

  return `
    <h2 class="tab-panel__title">公司与世界</h2>
    <p class="tab-panel__text">招聘、融资、公关与行业事件。世界会随泡沫压力与法律环境变化，并反过来影响你的成本。</p>
    ${subnav}
    ${body}
  `;
}

function renderCompanyProduct() {
  const s = gs(); if (!s) return '';
  const metrics = typeof getCompanyFinancialMetrics === 'function'
    ? safeCall('metrics', () => getCompanyFinancialMetrics(s)) || {}
    : {};

  const productRows = (s.products || []).slice(0, 3).map(p => `
    <li class="product-row">
      <span class="product-row__name">${esc(p.name || p.id)}</span>
      <span class="product-row__model">v${p.model_generation ?? '?'}</span>
      <span class="product-row__users">${(p.users_k ?? 0)}k 用户</span>
      <span class="product-row__rev">${fmtKc(p.monthly_rev_kc ?? 0)}/月</span>
      <span class="product-row__action">
        <button class="btn btn--ghost btn--small" data-action="deploy-product" data-id="${esc(p.id)}">更新部署</button>
      </span>
    </li>
  `).join('') || `<li class="empty-row">尚未部署任何产品。</li>`;

  const quarters = (s.quarter_records || []).slice(-4).map(q => `
    <tr>
      <td>${esc(q.name || `Q${q.index ?? '?'}`)}</td>
      <td>${fmtKc(q.revenue_kc ?? 0)}</td>
      <td>${fmtKc(q.paid_rnd_kc ?? 0)}</td>
      <td>${fmtKc(q.paid_ops_kc ?? 0)}</td>
      <td>${fmtKc(q.revenue_kc ?? 0) - (q.paid_rnd_kc ?? 0) - (q.paid_ops_kc ?? 0) > 0 ? '+' : ''}${fmtKc((q.revenue_kc ?? 0) - (q.paid_rnd_kc ?? 0) - (q.paid_ops_kc ?? 0))}</td>
      <td>${fmtKc(q.cash_delta_from_close_kc ?? 0)}</td>
    </tr>
  `).join('') || `<tr><td colspan="6" class="empty-row">尚无季度财报。</td></tr>`;

  return `
    <section class="card">
      <header class="card__header">
        <h3>产品（最多 3 个）</h3>
        <button class="btn btn--primary btn--small" data-action="deploy-product-new">部署新模型</button>
      </header>
      <ul class="product-list">${productRows}</ul>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>季度财报 · 现金桥</h3>
        <button class="btn btn--ghost btn--small" data-action="close-quarter">结算本季度</button>
      </header>
      <div class="kv-row">
        <div class="kv"><span>估值</span><b>${fmtKc(metrics.valuation_kc ?? 0)}</b></div>
        <div class="kv"><span>TTM 营收</span><b>${fmtKc(metrics.ttm_revenue_kc ?? 0)}</b></div>
        <div class="kv"><span>TTM 净利</span><b>${fmtKc(metrics.ttm_profit_kc ?? 0)}</b></div>
        <div class="kv"><span>TTM P/E</span><b>${typeof metrics.ttm_pe === 'number' ? fmtNum(metrics.ttm_pe, 1) : '—'}</b></div>
      </div>
      <table class="table">
        <thead>
          <tr><th>季度</th><th>营收</th><th>已付研发</th><th>已付运营</th><th>净利</th><th>关口期末现金变化</th></tr>
        </thead>
        <tbody>${quarters}</tbody>
      </table>
    </section>
  `;
}

function renderCompanyFinance() {
  const s = gs(); if (!s) return '';
  const privateFin = safeCall('pf preview', () => executePrivateFinancing(s, { preview: true })) || {};
  const ipoPrev = safeCall('ipo preview', () => executeIPO(s, { preview: true })) || {};

  const securities = securityList().map(sec => {
    const owned = s.portfolio?.[sec.id];
    return `
      <tr>
        <td>${esc(sec.ticker || sec.id)}</td>
        <td>${esc(sec.name || '')}</td>
        <td>${fmtKc(sec.base_price ?? 0)}</td>
        <td>${fmtNum(sec.volatility ?? 0, 2)}</td>
        <td>${owned ? `${owned.shares} 股` : '—'}</td>
        <td>
          <button class="btn btn--ghost btn--small" data-action="trade-security" data-sec="${esc(sec.id)}" data-side="buy">买入</button>
          <button class="btn btn--ghost btn--small" data-action="trade-security" data-sec="${esc(sec.id)}" data-side="sell">卖出</button>
        </td>
      </tr>
    `;
  }).join('');

  return `
    <section class="card">
      <header class="card__header">
        <h3>私募融资</h3>
      </header>
      <div class="kv-row">
        <div class="kv"><span>预计募资</span><b>${fmtKc(privateFin.amount_kc ?? 0)}</b></div>
        <div class="kv"><span>稀释比例</span><b>${fmtPct(privateFin.dilution ?? 0, 1)}</b></div>
        <div class="kv"><span>投前估值</span><b>${fmtKc(privateFin.pre_valuation_kc ?? 0)}</b></div>
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="do-private-fin">执行私募融资</button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>IPO</h3>
      </header>
      <div class="kv-row">
        <div class="kv"><span>发行价</span><b>${fmtKc(ipoPrev.price_kc ?? 0)}</b></div>
        <div class="kv"><span>新股发行（稀释 15%）</span><b>${fmtPct(ipoPrev.new_shares_pct ?? 0.15, 0)}</b></div>
        <div class="kv"><span>预计募资</span><b>${fmtKc(ipoPrev.raised_kc ?? 0)}</b></div>
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="do-ipo" ${s.ipo_done ? 'disabled' : ''}>
          ${s.ipo_done ? 'IPO 已完成' : '执行 IPO'}
        </button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>证券投资（虚构）</h3>
        <span class="hint">单笔不超过现金 10%</span>
      </header>
      <table class="table">
        <thead>
          <tr><th>代码</th><th>名称</th><th>基准价</th><th>波动率</th><th>持仓</th><th>操作</th></tr>
        </thead>
        <tbody>${securities}</tbody>
      </table>
    </section>
  `;
}

function renderCompanyResearch() {
  const s = gs(); if (!s) return '';
  const stages = ['paper', 'toy_pilot', 'scale_pilot', 'production'];
  const nodes = nodeList();
  const stage = App.ui.codex.nodeStage || 'paper';

  const filtered = nodes.filter(n => (n.stage || 'paper') === stage);
  const projects = s.research_projects || {};

  const nodeHtml = filtered.map(n => {
    const state = projects[n.id] || {};
    const progress = clamp(state.progress ?? 0, 0, 1);
    const done = progress >= 1;
    return `
      <li class="node-row">
        <span class="node-row__name">${esc(n.name || n.id)}</span>
        <span class="node-row__stage">${esc(n.stage || '')}</span>
        <span class="node-row__bar"><span class="bar"><span class="bar__fill" style="width:${(progress * 100).toFixed(0)}%"></span></span></span>
        <span class="node-row__state">${done ? '已完成' : fmtPct(progress, 0)}</span>
        <span class="node-row__actions">
          <button class="btn btn--ghost btn--small" data-action="step-node" data-id="${esc(n.id)}">
            ${gs()?.main_action_used ? '行动已用' : '推进研究'}
          </button>
        </span>
      </li>
    `;
  }).join('') || `<li class="empty-row">该阶段暂无科研节点。</li>`;

  const hist = HISTORY_BY_ID[activeModel().history_id];
  const arches = archList();
  const switched = activeModel().architecture_id !== (hist?.default_architecture_id || arches[0]?.id);

  return `
    <section class="card">
      <header class="card__header">
        <h3>四阶段架构科研</h3>
        <span class="hint">paper → toy_pilot → scale_pilot → production</span>
      </header>
      <nav class="subnav">
        ${stages.map(st => `
          <button class="subnav__item ${stage === st ? 'is-active' : ''}" data-action="research-stage" data-value="${st}">${esc(st)}</button>
        `).join('')}
      </nav>
      <ul class="node-list">${nodeHtml}</ul>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>架构切换</h3>
      </header>
      <div class="grid-3">
        ${arches.map(a => `
          <button class="tile ${activeModel().architecture_id === a.id ? 'is-active' : ''}" data-action="switch-arch" data-id="${esc(a.id)}">
            <span class="tile__title">${esc(a.name || a.id)}</span>
            <span class="tile__meta">${esc(a.tier || 'T?')} · ${a.total_params_b ?? 0}B / ${a.active_params_b ?? 0}B</span>
            <span class="tile__desc">${esc((a.description || '').slice(0, 60))}</span>
          </button>
        `).join('')}
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>RSI 实验室</h3>
        <span class="hint">递归自我改进实验：可能获得巨大增益，也可能带来风险</span>
      </header>
      <div class="kv-row">
        <div class="kv"><span>实验进度</span><b>${(s.milestone_state?.rsi_cycles ?? 0)} 次</b></div>
        <div class="kv"><span>证据链</span><b>${(s.milestone_state?.rsi_evidence || []).length} 项</b></div>
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="run-rsi">运行 RSI 实验周期</button>
      </div>
    </section>
  `;
}

function renderCompanyLegal() {
  const s = gs(); if (!s) return '';
  const exposures = (s.legal_exposures || []);
  const cases = (s.legal_cases || []);

  const exposureRows = exposures.map(e => `
    <tr>
      <td>${esc(e.source || e.id)}</td>
      <td><span class="badge badge--${(e.level ?? 0) >= 60 ? 'bad' : (e.level ?? 0) >= 30 ? 'warn' : 'good'}">${e.level ?? 0}</span></td>
      <td>${fmtKc(e.expected_kc ?? 0)}</td>
      <td>${esc(e.status || 'open')}</td>
    </tr>
  `).join('') || `<tr><td colspan="4" class="empty-row">暂无法律曝光。</td></tr>`;

  const caseRows = cases.map(c => `
    <tr>
      <td>${esc(c.name || c.id)}</td>
      <td>${esc(c.claimant || '—')}</td>
      <td>${fmtKc(c.demand_kc ?? 0)}</td>
      <td>${esc(c.stage || 'filed')}</td>
      <td>
        <button class="btn btn--ghost btn--small" data-action="resolve-legal" data-id="${esc(c.id)}" data-choice="settle">和解</button>
        <button class="btn btn--ghost btn--small" data-action="resolve-legal" data-id="${esc(c.id)}" data-choice="fight">应诉</button>
      </td>
    </tr>
  `).join('') || `<tr><td colspan="5" class="empty-row">暂无在办案件。</td></tr>`;

  return `
    <section class="card">
      <header class="card__header">
        <h3>法律曝光</h3>
        <button class="btn btn--ghost btn--small" data-action="step-legal">推进法务系统</button>
      </header>
      <table class="table">
        <thead><tr><th>来源</th><th>等级</th><th>预期赔款</th><th>状态</th></tr></thead>
        <tbody>${exposureRows}</tbody>
      </table>
    </section>

    <section class="card">
      <header class="card__header"><h3>在办案件</h3></header>
      <table class="table">
        <thead><tr><th>名称</th><th>原告</th><th>诉求</th><th>阶段</th><th>操作</th></tr></thead>
        <tbody>${caseRows}</tbody>
      </table>
    </section>
  `;
}

function renderCompanySectors() {
  const s = gs(); if (!s) return '';

  const sectors = sectorList().map(sec => {
    const st = s.job_sectors?.[sec.id] || {};
    const progress = clamp(st.progress ?? 0, 0, 1);
    return `
      <li class="sector-row">
        <span class="sector-row__name">${esc(sec.name || sec.id)}</span>
        <span class="sector-row__cat">${esc(sec.category || '—')}</span>
        <span class="sector-row__bar"><span class="bar"><span class="bar__fill" style="width:${(progress * 100).toFixed(0)}%"></span></span></span>
        <span class="sector-row__pct">${fmtPct(progress, 0)}</span>
      </li>
    `;
  }).join('');

  const realized = s.realized_automation_share ?? 0;
  const dividend = s.automation_dividend_ratio ?? 0.3;

  const ms = s.milestone_state || {};
  const msList = ['agi', 'asi', 'rsi'];
  const msHtml = msList.map(k => {
    const has = !!(ms[k] || (ms.evidence && ms.evidence.includes(k)));
    return `
      <label class="check">
        <input type="checkbox" ${has ? 'checked' : ''} disabled/>
        <span>${esc(k.toUpperCase())} 证据链 ${has ? '已确认' : '未确认'}</span>
      </label>
    `;
  }).join('');

  return `
    <section class="card">
      <header class="card__header">
        <h3>20 职业自动化终验</h3>
        <span class="hint">realized ${fmtPct(realized, 1)} · dividend ${fmtPct(dividend, 0)}</span>
      </header>
      <input type="range" class="input input--range" min="0" max="1" step="0.05"
             data-action="dividend-slider" value="${esc(dividend)}"/>
      <ul class="sector-list">${sectors}</ul>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>AGI / ASI / RSI 里程碑</h3>
      </header>
      ${msHtml}
      <div class="actions-row">
        <button class="btn btn--primary" data-action="update-milestones">刷新里程碑</button>
      </div>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>AI 泡沫监测</h3>
        <span class="hint">当前泡沫压力 ${Math.round(s.bubble_pressure ?? 0)} · 阶段 ${esc(s.bubble_phase || 'normal')}</span>
      </header>
      <div class="bar bar--large"><span class="bar__fill" style="width:${clamp(s.bubble_pressure ?? 0, 0, 100)}%"></span></div>
      <div class="actions-row">
        <button class="btn btn--ghost" data-action="update-bubble">刷新泡沫状态</button>
      </div>
    </section>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14f. Codex tab                                                              */
/* -------------------------------------------------------------------------- */

function renderCodexTab() {
  const s = gs(); if (!s) return '';
  const sub = App.ui.codex.subTab || 'real';
  const selected = App.ui.codex.historyId || activeModel().history_id;

  const histories = historyList();
  const chapterHtml = chapterList().map(ch => `
    <li class="chapter-row">
      <span class="chapter-row__tag">${esc(ch.season || '—')}</span>
      <span class="chapter-row__title">${esc(ch.title || ch.name || ch.id)}</span>
      <span class="chapter-row__desc">${esc(ch.description || '')}</span>
    </li>
  `).join('');

  const endingHtml = endingList().map(en => `
    <li class="ending-row">
      <span class="ending-row__name">${esc(en.name || en.id)}</span>
      <span class="ending-row__cond">${esc(en.condition || en.description || '')}</span>
    </li>
  `).join('');

  const sourcesHtml = sourceList().map(src => `
    <li class="source-row">
      <span class="source-row__id">[${esc(src.id || 'S??')}]</span>
      <span class="source-row__title">${esc(src.title || '')}</span>
      <span class="source-row__sum">${esc((src.summary || '').slice(0, 100))}</span>
    </li>
  `).join('');

  let body = '';
  if (sub === 'real') {
    body = `
      <p class="hint">参照真实历史时间线：12 个可选的模型早期路径。</p>
      <ul class="history-list">
        ${histories.map(hh => `
          <li class="history-row ${selected === hh.id ? 'is-active' : ''}" data-action="codex-pick-history" data-id="${esc(hh.id)}">
            <span class="history-row__name">${esc(hh.name || hh.id)}</span>
            <span class="history-row__tag">${esc(hh.tagline || '')}</span>
            <span class="history-row__desc">${esc((hh.description || '').slice(0, 140))}</span>
          </li>
        `).join('')}
      </ul>
    `;
  } else if (sub === 'roleplay') {
    const hh = HISTORY_BY_ID[selected] || {};
    body = `
      <p class="hint">角色演绎：以该历史主体的口吻描写模型育成历程。</p>
      <article class="roleplay">
        <h4>${esc(hh.name || '')}</h4>
        <p class="roleplay__tag">${esc(hh.tagline || '')}</p>
        <p>${esc(hh.description || '（此历史暂无演绎文本。）')}</p>
        <p class="hint">—— via 本地演绎模板；开启 BYOK 后可生成更丰富的演绎。</p>
      </article>
    `;
  } else {
    const archives = (gs()?.archived_models || []);
    body = `
      <p class="hint">我的版本树：已封存的模型版本。</p>
      <ul class="archive-tree">
        ${archives.length ? archives.map(a => `
          <li class="archive-node">
            <span class="archive-node__name">${esc(a.display_name || a.id)}</span>
            <span class="archive-node__meta">gen ${a.generation_index ?? '?'} · ${a.turn ?? '?'} 回合</span>
          </li>
        `).join('') : '<li class="empty-row">暂无封存版本。</li>'}
      </ul>
    `;
  }

  return `
    <h2 class="tab-panel__title">历史档案与图鉴</h2>
    <p class="tab-panel__text">查看历回合关键决策、结局分支与已解锁的模型图鉴条目。</p>

    <nav class="subnav">
      <button class="subnav__item ${sub === 'real' ? 'is-active' : ''}" data-action="codex-sub" data-value="real">真实历史</button>
      <button class="subnav__item ${sub === 'roleplay' ? 'is-active' : ''}" data-action="codex-sub" data-value="roleplay">角色演绎</button>
      <button class="subnav__item ${sub === 'tree' ? 'is-active' : ''}" data-action="codex-sub" data-value="tree">我的版本树</button>
    </nav>

    ${body}

    <section class="card">
      <header class="card__header"><h3>8 赛季章节</h3></header>
      <ul class="chapter-list">${chapterHtml}</ul>
    </section>

    <section class="card">
      <header class="card__header"><h3>5 结局分支</h3></header>
      <ul class="ending-list">${endingHtml}</ul>
    </section>

    <section class="card">
      <header class="card__header"><h3>[S01]–[S29] 参考来源</h3></header>
      <ul class="source-list">${sourcesHtml}</ul>
    </section>
  `;
}

/* -------------------------------------------------------------------------- */
/* 14g. Settings tab                                                           */
/* -------------------------------------------------------------------------- */

function renderSettingsTab() {
  const s = gs(); if (!s) return '';
  const byok = App.ui.settings;

  const audit = (s.audit_log || []);
  const processed = (s.processed_action_ids || []);

  return `
    <h2 class="tab-panel__title">BYOK 接口与回放日志</h2>
    <p class="tab-panel__text">配置自带密钥（BYOK）接口用于生成事件文本，并查看本局的确定性回放日志。</p>

    <section class="card">
      <header class="card__header">
        <h3>BYOK（自带密钥 · 可选）</h3>
        <span class="hint">仅保存在 sessionStorage；不写入存档 JSON；请求仅返回 { speaker_id, text, emotion }</span>
      </header>
      <label class="check">
        <input type="checkbox" data-settings-field="byokEnabled" ${byok.byokEnabled ? 'checked' : ''}/>
        <span>启用 BYOK</span>
      </label>
      <div class="grid-3">
        <label class="field">
          <span class="field-label">OpenAI 兼容 Endpoint</span>
          <input type="url" class="input" data-settings-field="byokEndpoint"
                 value="${esc(byok.byokEndpoint || '')}" placeholder="https://api.example.com/v1/chat/completions"/>
        </label>
        <label class="field">
          <span class="field-label">模型</span>
          <input type="text" class="input" data-settings-field="byokModel"
                 value="${esc(byok.byokModel || '')}" placeholder="gpt-4o-mini"/>
        </label>
        <label class="field">
          <span class="field-label">密钥</span>
          <input type="password" class="input" data-settings-field="byokKey"
                 placeholder="仅在本次会话内使用"/>
        </label>
      </div>
      <div class="actions-row">
        <button class="btn btn--primary" data-action="save-byok">保存 BYOK 设置</button>
        <button class="btn btn--ghost" data-action="test-byok">测试连接</button>
      </div>
      <p class="hint">${esc(byok.lastError || '')}</p>
      <p class="hint">
        安全提示：本功能为可选，不会自动开启；我们不会将你的密钥写入 JSON 存档。
        返回内容会被严格清洗为 { speaker_id, text, emotion }，任何其它字段都会被丢弃。
      </p>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>确定性动作 ID</h3>
        <span class="hint">共 ${processed.length} 个</span>
      </header>
      <ul class="processed-list">
        ${processed.length ? processed.slice(-40).reverse().map(id => `<li>${esc(id)}</li>`).join('') : '<li class="empty-row">暂无已处理动作。</li>'}
      </ul>
    </section>

    <section class="card">
      <header class="card__header">
        <h3>审计日志</h3>
      </header>
      <ul class="audit-log">
        ${audit.length ? audit.slice(-60).reverse().map(e => `
          <li><span class="hint">[${esc(e.turn ?? '?')}]</span> ${esc(e.text || e.message || JSON.stringify(e))}</li>
        `).join('') : '<li class="empty-row">暂无日志。</li>'}
      </ul>
    </section>
  `;
}

/* -------------------------------------------------------------------------- */
/* 15. Event delegation                                                        */
/* -------------------------------------------------------------------------- */

document.addEventListener('click', (ev) => {
  const t = ev.target.closest('[data-action]');
  if (!t) return;
  const action = t.dataset.action;
  handleAction(action, t, ev);
});

document.addEventListener('input', (ev) => {
  const t = ev.target.closest('[data-train-field],[data-train-adv],[data-ann-field],[data-prep-field],[data-race-field],[data-settings-field]');
  if (!t) return;
  handleInput(t);
});

document.addEventListener('change', (ev) => {
  const t = ev.target.closest('select[data-train-field],select[data-prep-field],select[data-race-field],select[data-ann-field]');
  if (!t) return;
  handleInput(t);
});

function handleInput(el) {
  const name = el.dataset.trainField || el.dataset.annField || el.dataset.prepField || el.dataset.raceField || el.dataset.settingsField;
  const advKey = el.dataset.trainAdv;
  if (advKey) {
    const v = el.type === 'number' ? Number(el.value) : el.value;
    App.ui.train.advanced[advKey] = typeof v === 'number' && !Number.isNaN(v) ? v : 0;
    recomputeTrainingPreview();
    renderTabIfActive('train');
    return;
  }
  if (!name) return;

  if (el.dataset.trainField) {
    if (el.type === 'checkbox') App.ui.train[name] = el.checked;
    else App.ui.train[name] = el.value;
    recomputeTrainingPreview();
    renderTabIfActive('train');
  } else if (el.dataset.annField) {
    const v = el.type === 'range' || el.type === 'number' ? Number(el.value) : el.value;
    App.ui.data.annotationDraft[name] = v;
    renderTabIfActive('data');
  } else if (el.dataset.prepField) {
    App.ui.prep[name] = el.value;
  } else if (el.dataset.raceField) {
    if (el.type === 'checkbox') App.ui.race[name] = el.checked;
    else App.ui.race[name] = el.value;
    renderTabIfActive('race');
  } else if (el.dataset.settingsField) {
    if (el.type === 'checkbox') App.ui.settings[name] = el.checked;
    else App.ui.settings[name] = el.value;
  }
}

function renderTabIfActive(tab) {
  if (App.ui.activeTab === tab) renderActiveTab();
}

function handleAction(action, el, ev) {
  switch (action) {
    /* Top HUD ------------------------------------------------------------- */
    case 'toggle-research':   App.ui.researchView = !App.ui.researchView; savePrefs(); rerenderAll(); break;
    case 'toggle-tutorial':   toggleTutorial(); break;
    case 'open-new-game':     openNewGameModal(); break;
    case 'export-save':       exportSave(); break;
    case 'open-import':       $('#import-save-input')?.click(); break;

    /* Main tabs ---------------------------------------------------------- */
    case 'switch-tab':        switchTab(el.dataset.value); break;

    /* Train tab ---------------------------------------------------------- */
    case 'train-focus':       App.ui.train.focus = el.dataset.value; recomputeTrainingPreview(); renderTabIfActive('train'); break;
    case 'train-preset':      App.ui.train.preset = el.dataset.value; applyPreset(App.ui.train.preset); recomputeTrainingPreview(); renderTabIfActive('train'); break;
    case 'train-recipe':      App.ui.train.recipeId = el.dataset.value; recomputeTrainingPreview(); renderTabIfActive('train'); break;
    case 'toggle-train-adv':  ev.preventDefault(); App.ui.train.advancedOpen = !App.ui.train.advancedOpen; renderTabIfActive('train'); break;
    case 'preview-training':  recomputeTrainingPreview(); renderTabIfActive('train'); break;
    case 'run-training':      runTraining(); break;
    case 'stats-detail':      toast('六维能力决定赛事名次与产品估值上限；训练配方通过基金目标影响成长曲线。'); break;

    /* Data tab ----------------------------------------------------------- */
    case 'refresh-market':    doRefreshMarket(); break;
    case 'acquire-offer':     doAcquireOffer(Number(el.dataset.index)); break;
    case 'auto-delegate':     doAutoDelegate(Number(el.dataset.index)); break;
    case 'start-minigame':    doStartMiniGame(Number(el.dataset.index)); break;
    case 'minigame-cancel':   cancelMiniGame(); break;
    case 'minigame-pick':
    case 'minigame-dedupe':
    case 'minigame-inspect':
    case 'minigame-road':     miniGamePick(action, Number(el.dataset.value)); break;
    case 'start-annotation':  doStartAnnotation(); break;
    case 'advance-annotations': doAdvanceAnnotations(); break;

    /* Prep tab ----------------------------------------------------------- */
    case 'do-rest':           doRestAndPrep(); break;
    case 'rollback-cp':       doRollback(el.dataset.id); break;
    case 'save-cards':        doSaveCards(); break;
    case 'open-card-editor':  openCardEditor(Number(el.dataset.slot)); break;
    case 'open-mentor-editor':openMentorEditor(Number(el.dataset.slot)); break;
    case 'do-inherit':        doInherit(); break;
    case 'expand-compute':    doExpand('compute'); break;
    case 'expand-memory':     doExpand('memory'); break;
    case 'expand-defense':    doExpand('defense'); break;

    /* Race tab ----------------------------------------------------------- */
    case 'preview-race':      doPreviewRace(); break;
    case 'start-race':        doStartRace(); break;
    case 'race-card-pick':    break;

    /* Company tab -------------------------------------------------------- */
    case 'company-section':   App.ui.company.section = el.dataset.value; renderTabIfActive('company'); break;
    case 'deploy-product':    doDeployProduct(el.dataset.id); break;
    case 'deploy-product-new': doDeployProduct(null); break;
    case 'close-quarter':     doCloseQuarter(); break;
    case 'do-private-fin':    doPrivateFinancing(); break;
    case 'do-ipo':            doIPO(); break;
    case 'trade-security':    doTradeSecurity(el.dataset.sec, el.dataset.side); break;
    case 'research-stage':    App.ui.codex.nodeStage = el.dataset.value; renderTabIfActive('company'); break;
    case 'step-node':         doStepNode(el.dataset.id); break;
    case 'switch-arch':       doSwitchArch(el.dataset.id); break;
    case 'run-rsi':           doRunRsi(); break;
    case 'step-legal':        doStepLegal(); break;
    case 'resolve-legal':     doResolveLegal(el.dataset.id, el.dataset.choice); break;
    case 'dividend-slider':   break;
    case 'update-milestones': doUpdateMilestones(); break;
    case 'update-bubble':     doUpdateBubble(); break;

    /* Codex tab ---------------------------------------------------------- */
    case 'codex-sub':         App.ui.codex.subTab = el.dataset.value; renderTabIfActive('codex'); break;
    case 'codex-pick-history':App.ui.codex.historyId = el.dataset.id; renderTabIfActive('codex'); break;

    /* Settings tab ------------------------------------------------------- */
    case 'save-byok':         doSaveByok(); break;
    case 'test-byok':         doTestByok(); break;

    /* Character ---------------------------------------------------------- */
    case 'char-speak':        charSpeak(); break;
    case 'open-free-dialogue':openFreeDialogueModal(); break;

    /* Tutorial ----------------------------------------------------------- */
    case 'tutorial-prev':     setTutorialStep(App.ui.tutorial.step - 1); break;
    case 'tutorial-next':     setTutorialStep(App.ui.tutorial.step + 1); break;
    case 'tutorial-skip':     endTutorial(); break;

    /* Modals ------------------------------------------------------------- */
    case 'modal-close':       closeTopModal(); break;
    case 'modal-confirm':     handleModalConfirm(el); break;
    case 'modal-choice':      handleModalChoice(el); break;

    /* Turn --------------------------------------------------------------- */
    case 'next-turn':         doNextTurn(); break;
    case 'race-toggle-speed': toggleRaceSpeed(); break;
    case 'race-skip-report':  skipRaceToReport(); break;
    case 'race-skill':        triggerRaceSkill(); break;
  }
}

/* -------------------------------------------------------------------------- */
/* 16. Tabs switching                                                          */
/* -------------------------------------------------------------------------- */

function switchTab(tab) {
  App.ui.activeTab = tab;
  savePrefs();
  renderActiveTab();
  if (tab === 'train') recomputeTrainingPreview();
  if (tab === 'data' && (gs()?.data_market || []).length === 0) doRefreshMarket();
  if (tab === 'race') doPreviewRace();
}

/* -------------------------------------------------------------------------- */
/* 17. Train tab logic                                                         */
/* -------------------------------------------------------------------------- */

function applyPreset(preset) {
  const a = App.ui.train.advanced;
  if (preset === 'steady') { a.epochs = 2; a.replay_ratio = 0.2; a.kl_strength = 0.05; a.mask_ratio = 0.15; }
  else if (preset === 'balanced') { a.epochs = 3; a.replay_ratio = 0.1; a.kl_strength = 0.02; a.mask_ratio = 0.15; }
  else if (preset === 'push') { a.epochs = 6; a.replay_ratio = 0.02; a.kl_strength = 0.005; a.mask_ratio = 0.1; }
}

function recomputeTrainingPreview() {
  const s = gs(); if (!s) return;
  const tr = App.ui.train;
  if (!tr.datasetId) tr.datasetId = (s.datasets || [])[0]?.id || null;
  if (!tr.recipeId) tr.recipeId = pickRecipeId(0);

  const req = typeof createTrainingRequest === 'function'
    ? safeCall('createTrainingRequest', () => createTrainingRequest(s, {
        recipe_id: tr.recipeId,
        focus_stat: tr.focus,
        preset: tr.preset,
        dataset_id: tr.datasetId,
        mode: tr.mode,
        epochs: tr.advanced.epochs,
        replay_ratio: tr.advanced.replay_ratio,
        batch_size: tr.advanced.batch_size,
        lora_rank: tr.advanced.lora_rank,
        group_size: tr.advanced.group_size,
        reasoning_budget_tokens: tr.advanced.reasoning_budget_tokens,
        kl_strength: tr.advanced.kl_strength,
        mask_ratio: tr.advanced.mask_ratio,
        denoise_steps: tr.advanced.denoise_steps,
        accept_legal_risk: tr.advanced.accept_legal_risk,
      }))
    : {
        recipe_id: tr.recipeId,
        focus_stat: tr.focus,
        preset: tr.preset,
        dataset_id: tr.datasetId,
        mode: tr.mode,
        ...tr.advanced,
      };

  if (!req) { App.ui.train.preview = null; return; }

  const prev = typeof previewTraining === 'function'
    ? safeCall('previewTraining', () => previewTraining(s, req))
    : null;
  App.ui.train.preview = prev || null;
}

function runTraining() {
  const s = gs(); if (!s) return;
  if (s.main_action_used) { toast('本回合主行动已使用', 'warn'); return; }
  recomputeTrainingPreview();
  const prev = App.ui.train.preview;
  if (prev && Array.isArray(prev.blockers) && prev.blockers.length) {
    toast('存在阻塞项，请先解决预览中的红色提示', 'error');
    return;
  }
  const tr = App.ui.train;
  const req = typeof createTrainingRequest === 'function'
    ? safeCall('createTrainingRequest', () => createTrainingRequest(s, {
        recipe_id: tr.recipeId,
        focus_stat: tr.focus,
        preset: tr.preset,
        dataset_id: tr.datasetId,
        mode: tr.mode,
        ...tr.advanced,
      }))
    : null;
  if (!req) { toast('无法构造训练请求', 'error'); return; }

  const res = typeof applyTraining === 'function'
    ? safeCall('applyTraining', () => applyTraining(s, req))
    : null;
  if (!res) return;

  s.main_action_used = true;
  if (!Array.isArray(s.processed_action_ids)) s.processed_action_ids = [];
  s.processed_action_ids.push(`train:${s.turn}:${tr.recipeId}`);

  maybeCheckpoint(s);
  advanceContractsSafe(s);

  App.dialogue = { speaker: '角色', text: '训练完成。我能感受到参数的呼吸。' };
  App.emotion = res.success === false ? 'worried' : 'happy';
  toast(res.message || (res.success === false ? '训练失败' : '训练完成'), res.success === false ? 'error' : 'success');
  saveToStorage();
  rerenderAll();
}

function maybeCheckpoint(s) {
  const m = s.active_model;
  m.actions_since_checkpoint = (m.actions_since_checkpoint || 0) + 1;
  const interval = m.checkpoint_interval_actions || 2;
  if (m.actions_since_checkpoint >= interval) {
    m.actions_since_checkpoint = 0;
    m.checkpoints = m.checkpoints || [];
    m.checkpoints.push({
      id: `cp-t${s.turn}-${m.checkpoints.length}`,
      turn: s.turn,
      label: `第 ${s.turn} 回合训练后`,
      interval,
      snapshot: deepCloneSafe(m),
    });
    if (m.checkpoints.length > 24) m.checkpoints.splice(1, m.checkpoints.length - 24);
    s.audit_log = s.audit_log || [];
    s.audit_log.push({ turn: s.turn, text: '自动快照已创建' });
  }
}

/* -------------------------------------------------------------------------- */
/* 18. Data tab logic                                                          */
/* -------------------------------------------------------------------------- */

function doRefreshMarket() {
  const s = gs(); if (!s) return;
  const res = typeof refreshDataMarket === 'function'
    ? safeCall('refreshDataMarket', () => refreshDataMarket(s))
    : null;
  if (res && Array.isArray(res.offers)) s.data_market = res.offers;
  else if (!Array.isArray(s.data_market) || s.data_market.length === 0) {
    /* Fallback: build a synthetic market from templates */
    const templates = datasetList().slice(0, 6);
    s.data_market = templates.map((tpl, i) => ({
      id: `offer-${s.turn}-${i}`,
      template_id: tpl.id,
      price_kc: tpl.base_price_kc ?? 12,
      records_k: tpl.records_k ?? 40,
      quality: tpl.quality ?? 0.5,
      true_quality: (tpl.quality ?? 0.5) * 0.85,
      rights_status: tpl.default_rights || 'unknown',
      provenance: tpl.provenance || '未知',
    }));
  }
  saveToStorage();
  renderTabIfActive('data');
  toast('数据市场已刷新', 'success');
}

function doAcquireOffer(index) {
  const s = gs(); if (!s) return;
  const offer = s.data_market?.[index];
  if (!offer) { toast('要约不存在', 'error'); return; }
  const res = typeof acquireDatasetOffer === 'function'
    ? safeCall('acquireDatasetOffer', () => acquireDatasetOffer(s, offer))
    : null;
  if (res && res.dataset) {
    s.datasets = s.datasets || [];
    s.datasets.push(res.dataset);
    s.data_market.splice(index, 1);
  } else {
    /* Fallback manual acquire */
    if ((s.cash_kc || 0) < (offer.price_kc || 0)) { toast('资金不足', 'error'); return; }
    s.cash_kc -= (offer.price_kc || 0);
    s.datasets = s.datasets || [];
    s.datasets.push({
      id: `ds-${s.turn}-${index}`,
      template_id: offer.template_id,
      records_k: offer.records_k,
      quality: offer.quality,
      true_quality: offer.true_quality,
      rights_status: offer.rights_status,
      provenance: offer.provenance,
      uses: 0,
    });
    s.data_market.splice(index, 1);
  }
  saveToStorage();
  renderTabIfActive('data');
  toast('已采购数据集', 'success');
}

function doAutoDelegate(index) {
  doAcquireOffer(index);
  toast('自动委托：+5% 品质/成本加成', 'info');
}

function doStartMiniGame(index) {
  const s = gs(); if (!s) return;
  const offer = s.data_market?.[index];
  if (!offer) return;
  const kinds = ['course', 'dedupe', 'inspect', 'road'];
  const kind = kinds[Math.floor(Math.random() * kinds.length)];

  const params = { kind, index, remaining: MINI_GAME_SECONDS, score: 0 };
  const res = typeof runDataMiniGame === 'function'
    ? safeCall('runDataMiniGame', () => runDataMiniGame(s, { kind, offer }))
    : null;
  if (res && typeof res === 'object') Object.assign(params, res);

  App.ui.data.miniGame = params;
  startMiniGameTimer();
  renderTabIfActive('data');
}

function startMiniGameTimer() {
  if (App._mgTimer) clearInterval(App._mgTimer);
  App._mgTimer = setInterval(() => {
    const mg = App.ui.data.miniGame;
    if (!mg) { clearInterval(App._mgTimer); return; }
    mg.remaining -= 1;
    if (mg.remaining <= 0) { cancelMiniGame(true); }
    else {
      const el = document.querySelector('.minigame__timer');
      if (el) el.textContent = `倒计时 ${Math.max(0, Math.ceil(mg.remaining))}s`;
    }
  }, 1000);
}

function cancelMiniGame(timedOut) {
  if (App._mgTimer) { clearInterval(App._mgTimer); App._mgTimer = null; }
  const mg = App.ui.data.miniGame;
  if (mg && !timedOut) toast('已放弃小游戏，可改为自动委托', 'info');
  App.ui.data.miniGame = null;
  renderTabIfActive('data');
}

function miniGamePick(action, value) {
  const mg = App.ui.data.miniGame;
  if (!mg) return;
  mg.score = (mg.score || 0) + 1;
  mg.lastPick = value;
  /* Draw-through: first correct pick removes a slot, then finish. */
  const bonus = clamp(0.05 + (mg.score || 0) * 0.01, 0, 0.10);
  const offer = gs().data_market?.[mg.index];
  if (offer) offer._bonus = bonus;
  if ((mg.score || 0) >= 2) {
    finishMiniGame(mg, bonus);
  } else {
    renderTabIfActive('data');
  }
}

function finishMiniGame(mg, bonus) {
  if (App._mgTimer) { clearInterval(App._mgTimer); App._mgTimer = null; }
  const offer = gs().data_market?.[mg.index];
  if (offer) { offer.bonus = bonus; toast(`小游戏完成：+${fmtPct(bonus, 1)} 加成`, 'success'); }
  App.ui.data.miniGame = null;
  renderTabIfActive('data');
}

function doStartAnnotation() {
  const s = gs(); if (!s) return;
  const d = App.ui.data.annotationDraft;
  if (!d.teamId || !d.methodId) { toast('请先选择团队与标注方法', 'error'); return; }
  const res = typeof startAnnotationContract === 'function'
    ? safeCall('startAnnotationContract', () => startAnnotationContract(s, { ...d }))
    : null;
  if (!res) {
    s.annotation_contracts = s.annotation_contracts || [];
    s.annotation_contracts.push({
      id: `ann-${s.turn}-${s.annotation_contracts.length}`,
      team_id: d.teamId, method_id: d.methodId, size_k: d.size_k,
      quality: 0.6, progress: 0, turns: 2,
    });
  }
  saveToStorage();
  renderTabIfActive('data');
  toast('标注合约已启动', 'success');
}

function doAdvanceAnnotations() {
  const s = gs(); if (!s) return;
  const res = typeof advanceAnnotationContracts === 'function'
    ? safeCall('advanceAnnotationContracts', () => advanceAnnotationContracts(s))
    : null;
  if (res && Array.isArray(res.completed)) {
    /* Fallback: completed handled by engine */
  }
  renderTabIfActive('data');
  toast('标注合约已推进', 'info');
}

/* -------------------------------------------------------------------------- */
/* 19. Prep tab logic                                                          */
/* -------------------------------------------------------------------------- */

function doRestAndPrep() {
  const s = gs(); if (!s) return;
  if (s.main_action_used) { toast('本回合主行动已使用', 'warn'); return; }
  const res = typeof applyRestAndPrep === 'function'
    ? safeCall('applyRestAndPrep', () => applyRestAndPrep(s))
    : null;
  if (!res) {
    /* Fallback */
    const cost = 8;
    if ((s.cash_kc || 0) < cost) { toast('资金不足', 'error'); return; }
    s.cash_kc -= cost;
    s.cluster_readiness = clamp((s.cluster_readiness || 0) + 35, 0, 100);
    s.active_model.optimizer_health = clamp((s.active_model.optimizer_health || 0) + 10, 0, 100);
    if ((s.support_card_ids || []).includes('card_3am_ops')) {
      s.cluster_readiness = clamp((s.cluster_readiness || 0) + 10, 0, 100);
    }
  }
  s.main_action_used = true;
  saveToStorage();
  rerenderAll();
  App.dialogue = { speaker: '角色', text: '好多了。优化器的温度降下来了。' };
  App.emotion = 'happy';
  toast('整备完成', 'success');
}

function doRollback(cpId) {
  const s = gs(); if (!s) return;
  const res = typeof rollbackModelToCheckpoint === 'function'
    ? safeCall('rollbackModelToCheckpoint', () => rollbackModelToCheckpoint(s, cpId))
    : null;
  if (!res) { toast('回滚失败', 'error'); return; }
  saveToStorage();
  rerenderAll();
  toast('已回滚到快照（资金 / 法律 / 溯源不回滚）', 'info');
}

function doSaveCards() {
  const s = gs(); if (!s) return;
  const ids = [];
  for (let i = 0; i < 4; i++) {
    const val = App.ui.prep[`card_slot_${i}`];
    if (val) ids.push(val);
  }
  if (ids.length > 4) ids.length = 4;
  const res = typeof updateSupportCardDeck === 'function'
    ? safeCall('updateSupportCardDeck', () => updateSupportCardDeck(s, ids))
    : null;
  s.support_card_ids = ids;
  saveToStorage();
  rerenderAll();
  toast('卡组已保存', 'success');
}

function openCardEditor(slot) {
  const cards = cardList();
  const current = gs()?.support_card_ids?.[slot];
  const modal = openModal({
    title: `编辑支援卡槽位 ${slot + 1}`,
    bodyHtml: `
      <ul class="modal-list">
        ${cards.map(c => `
          <li>
            <button class="modal-choice ${current === c.id ? 'is-active' : ''}"
                    data-action="modal-choice" data-kind="card" data-slot="${slot}" data-value="${esc(c.id)}">
              <b>${esc(c.name || c.id)}</b>
              <span>${esc(c.description || '')}</span>
            </button>
          </li>
        `).join('')}
      </ul>
    `,
  });
}

function openMentorEditor(slot) {
  const hist = historyList();
  const current = gs()?.teacher_model_ids?.[slot];
  openModal({
    title: `编辑导师槽位 ${slot + 1}`,
    bodyHtml: `
      <ul class="modal-list">
        <li>
          <button class="modal-choice" data-action="modal-choice" data-kind="mentor" data-slot="${slot}" data-value="">
            <b>清空该槽位</b>
          </button>
        </li>
        ${hist.map(hh => `
          <li>
            <button class="modal-choice ${current === hh.id ? 'is-active' : ''}"
                    data-action="modal-choice" data-kind="mentor" data-slot="${slot}" data-value="${esc(hh.id)}">
              <b>${esc(hh.name || hh.id)}</b>
              <span>${esc(hh.tagline || '')}</span>
            </button>
          </li>
        `).join('')}
      </ul>
    `,
  });
}

function doInherit() {
  const s = gs(); if (!s) return;
  const from = App.ui.prep.mentor_from;
  if (!from) { toast('请先选择导师', 'error'); return; }
  const slot = Number(App.ui.prep.mentor_slot || 0);
  const res = typeof applyMentorSelection === 'function'
    ? safeCall('applyMentorSelection', () => applyMentorSelection(s, from, slot))
    : null;
  if (!res) {
    s.teacher_model_ids = s.teacher_model_ids || [];
    s.teacher_model_ids[slot] = from;
  }
  saveToStorage();
  rerenderAll();
  toast('已应用导师继承', 'success');
}

function doExpand(kind) {
  const s = gs(); if (!s) return;
  const costs = { compute: 24, memory: 18, defense: 16 };
  const cost = costs[kind] || 0;
  if ((s.cash_kc || 0) < cost) { toast('资金不足', 'error'); return; }
  s.cash_kc -= cost;
  if (kind === 'compute') s.cluster_compute_cu = (s.cluster_compute_cu || 0) + 16;
  if (kind === 'memory') s.cluster_memory_gb = (s.cluster_memory_gb || 0) + 128;
  if (kind === 'defense') s.defense_level = (s.defense_level || 1) + 1;
  saveToStorage();
  rerenderAll();
  toast(`已升级${kind === 'compute' ? '算力' : kind === 'memory' ? '内存' : '防御'}`, 'success');
}

/* -------------------------------------------------------------------------- */
/* 20. Race tab logic                                                          */
/* -------------------------------------------------------------------------- */

function doPreviewRace() {
  const s = gs(); if (!s) return;
  const uiRace = App.ui.race;
  if (!uiRace.benchmarkId) uiRace.benchmarkId = benchList()[0]?.id || null;

  const req = typeof createRaceRequest === 'function'
    ? safeCall('createRaceRequest', () => createRaceRequest(s, {
        league_tier: uiRace.league_tier,
        thinking_mode: uiRace.thinking_mode,
        denoise_steps: uiRace.denoise_steps,
        benchmark_id: uiRace.benchmarkId,
        auto_skill: uiRace.auto_skill,
      }))
    : {
        league_tier: uiRace.league_tier,
        thinking_mode: uiRace.thinking_mode,
        denoise_steps: uiRace.denoise_steps,
        benchmark_id: uiRace.benchmarkId,
        auto_skill: uiRace.auto_skill,
      };
  const prev = typeof previewRace === 'function'
    ? safeCall('previewRace', () => previewRace(s, req))
    : null;
  App.ui.race.preview = prev || null;
  renderTabIfActive('race');
}

function doStartRace() {
  const s = gs(); if (!s) return;
  if (s.main_action_used) { toast('本回合主行动已使用', 'warn'); return; }
  doPreviewRace();

  const uiRace = App.ui.race;
  const req = typeof createRaceRequest === 'function'
    ? safeCall('createRaceRequest', () => createRaceRequest(s, {
        league_tier: uiRace.league_tier,
        thinking_mode: uiRace.thinking_mode,
        denoise_steps: uiRace.denoise_steps,
        benchmark_id: uiRace.benchmarkId,
        auto_skill: uiRace.auto_skill,
      }))
    : null;
  if (!req) return;

  const sim = typeof simulateRace === 'function'
    ? safeCall('simulateRace', () => simulateRace(s, req))
    : null;
  if (!sim) return;

  /* Open replay modal */
  openRaceReplayModal(sim, req);
  s.main_action_used = true;

  if (!Array.isArray(s.processed_action_ids)) s.processed_action_ids = [];
  s.processed_action_ids.push(`race:${s.turn}:${uiRace.benchmarkId}`);

  const result = sim.result || sim;
  App.ui.race.lastResult = result;
  saveToStorage();
}

function openRaceReplayModal(sim, req) {
  const events = sim.events || sim.race_events || [];
  App.raceReplay = {
    sim, req,
    cursor: 0,
    speed: 1,
    events: Array.isArray(events) ? events : genFallbackRaceEvents(sim),
    playing: true,
  };
  const overlay = openModal({
    title: '赛事回放',
    bodyHtml: raceReplayBody(),
    footerHtml: `
      <button class="btn btn--ghost" data-action="race-toggle-speed">切换速度</button>
      <button class="btn btn--ghost" data-action="race-skill">手动触发技能</button>
      <button class="btn btn--primary" data-action="race-skip-report">跳到结算</button>
      <button class="btn btn--primary" data-action="modal-close">关闭</button>
    `,
    onClose: () => { App.raceReplay = null; },
  });
  startRaceReplayLoop();
}

function genFallbackRaceEvents(sim) {
  const benches = benchList().slice(0, 4);
  const base = sim.public_score ?? (sim.result?.public_score ?? 100);
  return benches.map((b, i) => ({
    kind: 'task',
    label: b.name || b.id,
    public: base * (0.8 + 0.05 * i),
    hidden: base * (0.6 + 0.03 * i),
  }));
}

function raceReplayBody() {
  const r = App.raceReplay;
  if (!r) return '<p class="empty-row">无回放数据。</p>';
  const evs = r.events || [];
  const cur = evs[r.cursor];
  const tasks = evs.filter(e => e.kind === 'task');
  const publicScore = cur?.public ?? avgOf(tasks.map(t => t.public));
  const hiddenScore = cur?.hidden ?? avgOf(tasks.map(t => t.hidden));

  return `
    <div class="race-replay">
      <header class="race-replay__head">
        <span class="hint">进度 ${Math.min(r.cursor + 1, evs.length)} / ${evs.length} · 速度 ×${r.speed}</span>
      </header>
      <div class="race-replay__tasks">
        ${tasks.map((t, i) => `
          <div class="race-task ${i < r.cursor ? 'is-done' : i === r.cursor ? 'is-active' : ''}">
            <span class="race-task__name">${esc(t.label || `任务 ${i + 1}`)}</span>
            <span class="race-task__score">${fmtNum(t.public, 1)}</span>
          </div>
        `).join('')}
      </div>
      <div class="race-replay__bars">
        <div class="bar-row">
          <span class="bar-label">公开分</span>
          <span class="bar bar--public"><span class="bar__fill" style="width:${clamp(publicScore / 3, 0, 100)}%"></span></span>
          <span class="bar-value">${fmtNum(publicScore, 1)}</span>
        </div>
        <div class="bar-row">
          <span class="bar-label">隐藏分</span>
          <span class="bar bar--hidden"><span class="bar__fill" style="width:${clamp(hiddenScore / 3, 0, 100)}%"></span></span>
          <span class="bar-value">${App.ui.researchView ? fmtNum(hiddenScore, 1) : '???'}</span>
        </div>
      </div>
      ${cur ? `
        <p class="race-replay__event">
          ${esc(cur.label || '—')}
          ${cur.skill ? ` · <b>技能触发</b>：${esc(cur.skill)}` : ''}
        </p>
      ` : `<p class="hint">回放完毕。</p>`}
    </div>
  `;
}

function startRaceReplayLoop() {
  if (App._raceTimer) clearInterval(App._raceTimer);
  App._raceTimer = setInterval(() => {
    const r = App.raceReplay;
    if (!r) { clearInterval(App._raceTimer); App._raceTimer = null; return; }
    if (!r.playing) return;
    r.cursor += r.speed;
    if (r.cursor >= r.events.length) { r.cursor = r.events.length - 1; r.playing = false; }
    const body = document.querySelector('.modal__body');
    if (body && r) body.innerHTML = raceReplayBody();
  }, 800);
}

function toggleRaceSpeed() {
  const r = App.raceReplay;
  if (!r) return;
  r.speed = r.speed === 1 ? 2 : r.speed === 2 ? 4 : 1;
  const body = document.querySelector('.modal__body');
  if (body) body.innerHTML = raceReplayBody();
}

function triggerRaceSkill() {
  const r = App.raceReplay;
  if (!r) return;
  const cur = r.events[r.cursor];
  if (cur) {
    cur.skill = cur.skill || '肾上腺素';
    const body = document.querySelector('.modal__body');
    if (body) body.innerHTML = raceReplayBody();
  }
}

function skipRaceToReport() {
  const r = App.raceReplay;
  if (!r) return;
  r.cursor = r.events.length - 1;
  r.playing = false;
  const body = document.querySelector('.modal__body');
  if (body) body.innerHTML = raceReplayBody() + `
    <div class="kv-row">
      <div class="kv"><span>名次</span><b>${r.sim.result?.rank ?? r.sim.rank ?? '—'}</b></div>
      <div class="kv"><span>公开分</span><b>${fmtNum(r.sim.result?.public_score ?? r.sim.public_score ?? 0, 1)}</b></div>
    </div>
  `;
}

/* -------------------------------------------------------------------------- */
/* 21. Company tab logic                                                       */
/* -------------------------------------------------------------------------- */

function doDeployProduct(productId) {
  const s = gs(); if (!s) return;
  const res = typeof deployOrUpdateProduct === 'function'
    ? safeCall('deployOrUpdateProduct', () => deployOrUpdateProduct(s, productId))
    : null;
  if (!res) {
    s.products = s.products || [];
    const idx = s.products.findIndex(p => p.id === productId);
    if (idx >= 0) s.products[idx].model_generation = (s.active_model.generation_index || 1);
    else if (s.products.length < 3) {
      s.products.push({
        id: `prod-${s.turn}-${s.products.length}`,
        name: `${s.active_model.display_name || '产品'} API`,
        model_generation: s.active_model.generation_index || 1,
        users_k: 0, monthly_rev_kc: 0,
      });
    }
  }
  saveToStorage();
  renderTabIfActive('company');
  toast('产品已部署 / 更新', 'success');
}

function doCloseQuarter() {
  const s = gs(); if (!s) return;
  const res = typeof closeQuarter === 'function'
    ? safeCall('closeQuarter', () => closeQuarter(s))
    : null;
  saveToStorage();
  rerenderAll();
  toast('季度结算完成', 'success');
}

function doPrivateFinancing() {
  const s = gs(); if (!s) return;
  const res = typeof executePrivateFinancing === 'function'
    ? safeCall('executePrivateFinancing', () => executePrivateFinancing(s, {}))
    : null;
  saveToStorage();
  rerenderAll();
  toast('私募融资完成', 'success');
}

function doIPO() {
  const s = gs(); if (!s) return;
  const res = typeof executeIPO === 'function'
    ? safeCall('executeIPO', () => executeIPO(s, {}))
    : null;
  saveToStorage();
  rerenderAll();
  toast('IPO 完成', 'success');
}

function doTradeSecurity(secId, side) {
  const s = gs(); if (!s) return;
  const sec = SECURITY_BY_ID[secId];
  if (!sec) return;
  const limit = (s.cash_kc || 0) * 0.10;
  const res = typeof tradeSecurity === 'function'
    ? safeCall('tradeSecurity', () => tradeSecurity(s, { security_id: secId, side, max_kc: limit }))
    : null;
  saveToStorage();
  renderTabIfActive('company');
  toast(`${side === 'buy' ? '买入' : '卖出'} ${sec.name || secId}`, 'success');
}

function doStepNode(nodeId) {
  const s = gs(); if (!s) return;
  if (s.main_action_used) { toast('本回合主行动已使用', 'warn'); return; }
  const res = typeof stepResearchProject === 'function'
    ? safeCall('stepResearchProject', () => stepResearchProject(s, nodeId))
    : null;
  if (!res) {
    s.research_projects = s.research_projects || {};
    const prev = s.research_projects[nodeId] || { progress: 0 };
    prev.progress = clamp(prev.progress + 0.34, 0, 1);
    s.research_projects[nodeId] = prev;
  }
  s.main_action_used = true;
  saveToStorage();
  renderTabIfActive('company');
  toast('科研节点已推进', 'success');
}

function doSwitchArch(archId) {
  const s = gs(); if (!s) return;
  const arch = ARCH_BY_ID[archId];
  if (!arch) return;
  s.active_model.architecture_id = archId;
  if (arch.total_params_b) s.active_model.sim_total_params_b = arch.total_params_b;
  if (arch.active_params_b) s.active_model.sim_active_params_b = arch.active_params_b;
  saveToStorage();
  rerenderAll();
  toast(`已切换到架构 ${arch.name || archId}`, 'success');
}

function doRunRsi() {
  const s = gs(); if (!s) return;
  if (s.main_action_used) { toast('本回合主行动已使用', 'warn'); return; }
  const res = typeof runRsiExperimentCycle === 'function'
    ? safeCall('runRsiExperimentCycle', () => runRsiExperimentCycle(s))
    : null;
  if (!res) {
    s.milestone_state = s.milestone_state || {};
    s.milestone_state.rsi_cycles = (s.milestone_state.rsi_cycles || 0) + 1;
  }
  s.main_action_used = true;
  saveToStorage();
  rerenderAll();
  toast('RSI 实验周期完成', 'success');
}

function doStepLegal() {
  const s = gs(); if (!s) return;
  const res = typeof stepLegalSystem === 'function'
    ? safeCall('stepLegalSystem', () => stepLegalSystem(s))
    : null;
  saveToStorage();
  renderTabIfActive('company');
  toast('法务系统已推进', 'info');
}

function doResolveLegal(caseId, choice) {
  const s = gs(); if (!s) return;
  const res = typeof resolveLegalAction === 'function'
    ? safeCall('resolveLegalAction', () => resolveLegalAction(s, caseId, choice))
    : null;
  saveToStorage();
  renderTabIfActive('company');
  toast('已处理案件', 'success');
}

function doUpdateMilestones() {
  const s = gs(); if (!s) return;
  const res = typeof updateSectorsAndMilestones === 'function'
    ? safeCall('updateSectorsAndMilestones', () => updateSectorsAndMilestones(s))
    : null;
  saveToStorage();
  renderTabIfActive('company');
  toast('里程碑已刷新', 'info');
}

function doUpdateBubble() {
  const s = gs(); if (!s) return;
  const res = typeof updateBubbleState === 'function'
    ? safeCall('updateBubbleState', () => updateBubbleState(s))
    : null;
  saveToStorage();
  rerenderAll();
  toast('泡沫状态已刷新', 'info');
}

/* -------------------------------------------------------------------------- */
/* 22. Settings logic                                                          */
/* -------------------------------------------------------------------------- */

function doSaveByok() {
  const s = App.ui.settings;
  const endpoint = $('#tab-content [data-settings-field="byokEndpoint"]');
  const model = $('#tab-content [data-settings-field="byokModel"]');
  const key = $('#tab-content [data-settings-field="byokKey"]');
  const enabled = $('#tab-content [data-settings-field="byokEnabled"]');
  if (endpoint) s.byokEndpoint = endpoint.value;
  if (model) s.byokModel = model.value;
  if (enabled) s.byokEnabled = enabled.checked;
  if (key && key.value) s.byokKey = key.value;
  saveByok();
  toast('BYOK 设置已保存到 sessionStorage（不会写入存档）', 'success');
}

function doTestByok() {
  const s = App.ui.settings;
  if (!s.byokEnabled) { toast('请先启用 BYOK', 'warn'); return; }
  if (!s.byokEndpoint || !s.byokModel) { toast('请填写 Endpoint 与模型', 'warn'); return; }
  s.lastError = '';
  toast('已发送测试请求（示例不实际发起网络调用）', 'info');
  /* Strictly sanitize: only { speaker_id, text, emotion } fields are accepted. */
  const sample = { speaker_id: 'pilot', text: '测试成功', emotion: 'happy' };
  const sanitized = sanitizeAiOutput(sample);
  App.dialogue = { speaker: '角色', text: sanitized.text };
  App.emotion = sanitized.emotion || 'neutral';
  renderCharacterStage();
}

function sanitizeAiOutput(raw) {
  if (!raw || typeof raw !== 'object') return { speaker_id: null, text: '', emotion: 'neutral' };
  const out = {
    speaker_id: typeof raw.speaker_id === 'string' ? raw.speaker_id.slice(0, 64) : null,
    text: typeof raw.text === 'string' ? raw.text.slice(0, 400) : '',
    emotion: typeof raw.emotion === 'string' ? raw.emotion.slice(0, 16) : 'neutral',
  };
  if (!EMOTION_MAP[out.emotion]) out.emotion = 'neutral';
  return out;
}

function openFreeDialogueModal() {
  const hist = HISTORY_BY_ID[activeModel().history_id];
  openModal({
    title: `自由对话 · ${hist?.name || '角色'}`,
    bodyHtml: `
      <p class="hint">
        离线演绎：本地模板回应。<br/>
        BYOK：调用自带密钥的 OpenAI 兼容接口，返回会被严格清洗为 { speaker_id, text, emotion }。<br/>
        <b>不会向存档写入任何密钥。</b>
      </p>
      <textarea class="input" rows="3" placeholder="说点什么…" data-dialogue-input></textarea>
    `,
    footerHtml: `
      <button class="btn btn--ghost" data-action="modal-close">关闭</button>
      <button class="btn btn--primary" data-action="modal-confirm" data-kind="dialogue">发送</button>
    `,
  });
}

/* -------------------------------------------------------------------------- */
/* 23. Tutorial                                                                */
/* -------------------------------------------------------------------------- */

function toggleTutorial() {
  if (App.ui.tutorial.active) endTutorial();
  else startTutorial();
}

function startTutorial() {
  App.ui.tutorial.active = true;
  App.ui.tutorial.step = 0;
  const banner = $('#tutorial-banner');
  if (banner) banner.hidden = false;
  renderTutorial();
}

function endTutorial() {
  App.ui.tutorial.active = false;
  const banner = $('#tutorial-banner');
  if (banner) banner.hidden = true;
  savePrefs();
}

function setTutorialStep(step) {
  const total = TUTORIAL_TOTAL;
  if (step < 0) step = 0;
  if (step >= total) { endTutorial(); return; }
  App.ui.tutorial.step = step;
  renderTutorial();
}

function renderTutorial() {
  const step = App.ui.tutorial.step || 0;
  const s = TUTORIAL_STEPS[step] || TUTORIAL_STEPS[0];
  setText('#tutorial-step-counter', `教程 ${step + 1} / ${TUTORIAL_TOTAL}`);
  setText('#tutorial-step-title', s.t);
  setText('#tutorial-step-text', s.d);
  $$('#tutorial-dots .tutorial-dot').forEach((dot, i) => {
    dot.classList.toggle('is-active', i === step);
    if (i === step) dot.setAttribute('aria-current', 'step');
    else dot.removeAttribute('aria-current');
  });
  const prev = $('#btn-tutorial-prev');
  const next = $('#btn-tutorial-next');
  if (prev) prev.disabled = step === 0;
  if (next) next.textContent = step === TUTORIAL_TOTAL - 1 ? '完成' : '下一步';
}

/* -------------------------------------------------------------------------- */
/* 24. Modals                                                                  */
/* -------------------------------------------------------------------------- */

function openModal({ title, bodyHtml, footerHtml, onClose }) {
  const root = $('#modal-root');
  if (!root) return null;
  root.hidden = false;
  const el = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title || '对话框' });
  el.innerHTML = `
    <div class="modal__backdrop" data-action="modal-close"></div>
    <div class="modal__panel" role="document">
      <header class="modal__header">
        <h2 class="modal__title">${esc(title || '')}</h2>
        <button class="btn btn--icon" data-action="modal-close" aria-label="关闭">✕</button>
      </header>
      <div class="modal__body">${bodyHtml || ''}</div>
      ${footerHtml ? `<footer class="modal__footer">${footerHtml}</footer>` : ''}
    </div>
  `;
  root.appendChild(el);
  const handle = { el, onClose };
  App.modals.push(handle);
  requestAnimationFrame(() => el.classList.add('is-visible'));
  return handle;
}

function closeTopModal() {
  const modal = App.modals.pop();
  if (!modal) {
    const root = $('#modal-root');
    if (root) root.hidden = true;
    return;
  }
  modal.el.classList.remove('is-visible');
  setTimeout(() => {
    modal.el.remove();
    if (modal.onClose) { try { modal.onClose(); } catch (e) { console.warn(e); } }
    if (App.modals.length === 0) {
      const root = $('#modal-root');
      if (root) root.hidden = true;
    }
  }, 260);
}

function handleModalConfirm(el) {
  const kind = el.dataset.kind;
  if (kind === 'dialogue') {
    const input = document.querySelector('[data-dialogue-input]');
    const text = input?.value?.trim() || '……';
    App.dialogue = { speaker: '角色', text: `（${text.slice(0, 60)}）……我记住了。` };
    App.emotion = 'neutral';
    closeTopModal();
    renderCharacterStage();
  } else if (kind === 'new-game') {
    const profileId = el.dataset.profile;
    const historyId = el.dataset.history;
    startNewGame(profileId, historyId);
    closeTopModal();
  }
}

function handleModalChoice(el) {
  const kind = el.dataset.kind;
  if (kind === 'card') {
    const slot = Number(el.dataset.slot);
    App.ui.prep[`card_slot_${slot}`] = el.dataset.value;
    closeTopModal();
    doSaveCards();
  } else if (kind === 'mentor') {
    const slot = Number(el.dataset.slot);
    const s = gs();
    if (s) {
      s.teacher_model_ids = s.teacher_model_ids || [];
      s.teacher_model_ids[slot] = el.dataset.value || null;
      saveToStorage();
      closeTopModal();
      rerenderAll();
    }
  } else if (kind === 'story-event') {
    const evId = el.dataset.eventId;
    const choiceId = el.dataset.value;
    const s = gs();
    if (s && evId) {
      const res = typeof applyStoryEventChoice === 'function'
        ? safeCall('applyStoryEventChoice', () => applyStoryEventChoice(s, evId, choiceId))
        : null;
      saveToStorage();
      closeTopModal();
      rerenderAll();
      toast('事件已结算', 'success');
    } else {
      closeTopModal();
    }
  } else if (kind === 'new-game-profile') {
    applyNewGameProfile(el.dataset.value, el.dataset.history);
  }
}

/* -------------------------------------------------------------------------- */
/* 25. New Game modal                                                          */
/* -------------------------------------------------------------------------- */

function openNewGameModal() {
  const profiles = profileList();
  const histories = historyList();

  openModal({
    title: '开始一局新游戏',
    bodyHtml: `
      <div class="newgame">
        <section>
          <h3>选择初始档（4 种）</h3>
          <div class="grid-2">
            ${profiles.map((p, i) => `
              <button class="tile" data-action="modal-choice" data-kind="new-game-profile"
                      data-value="${esc(p.id)}" data-history="${esc(histories[0]?.id || '')}">
                <span class="tile__title">${esc(p.name || p.id)}</span>
                <span class="tile__meta">现金 ${fmtKc(p.cash_kc ?? 120)} · 算力 ${fmtCu(p.compute_cu ?? 48)}</span>
                <span class="tile__desc">${esc(p.description || '')}</span>
              </button>
            `).join('')}
          </div>
        </section>
        <section>
          <h3>选择历史角色（12 种）</h3>
          <div class="grid-3">
            ${histories.map(hh => `
              <button class="tile tile--history" data-action="modal-choice" data-kind="pick-history"
                      data-value="${esc(hh.id)}">
                <span class="tile__title">${esc(hh.name || hh.id)}</span>
                <span class="tile__meta">${esc(hh.tagline || '')}</span>
              </button>
            `).join('')}
          </div>
        </section>
      </div>
    `,
    footerHtml: `<button class="btn btn--ghost" data-action="modal-close">取消</button>`,
  });
}

function applyNewGameProfile(profileId, historyId) {
  App.pendingNewGame = { profileId, historyId };
  const histories = historyList();
  const chosen = App.pendingNewGame.historyId || histories[0]?.id;
  startNewGame(profileId, chosen);
  closeTopModal();
}

function startNewGame(profileId, historyId) {
  App.state = createStateFromProfile(profileId, historyId);
  App.ui = defaultUI();
  App.emotion = 'neutral';
  App.dialogue = { speaker: '策划', text: '新的育成开始。今天，我们从零起步。' };
  saveToStorage();
  rerenderAll();
  toast('新游戏已开始', 'success');
}

/* -------------------------------------------------------------------------- */
/* 26. Story events                                                            */
/* -------------------------------------------------------------------------- */

function maybeFireStoryEvent() {
  const s = gs(); if (!s) return false;
  const events = eventList();
  if (!events.length) return false;
  const fired = s.fired_story_events || (s.fired_story_events = []);
  const candidate = events.find(ev => {
    if (!ev || !ev.id) return false;
    if (fired.includes(ev.id)) return false;
    const turn = ev.turn ?? ev.turn_min;
    if (typeof turn === 'number' && s.turn < turn) return false;
    const turnMax = ev.turn_max;
    if (typeof turnMax === 'number' && s.turn > turnMax) return false;
    return true;
  });
  if (!candidate) return false;
  fired.push(candidate.id);
  openStoryEventModal(candidate);
  return true;
}

function openStoryEventModal(ev) {
  const choices = ev.choices || [
    { id: 'accept', label: '接受' },
    { id: 'decline', label: '婉拒' },
  ];
  openModal({
    title: ev.title || '行业事件',
    bodyHtml: `
      <p>${esc(ev.text || ev.description || '')}</p>
      <ul class="modal-list">
        ${choices.map(c => `
          <li>
            <button class="modal-choice" data-action="modal-choice" data-kind="story-event"
                    data-event-id="${esc(ev.id)}" data-value="${esc(c.id)}">
              <b>${esc(c.label || c.id)}</b>
              <span>${esc(c.hint || '')}</span>
            </button>
          </li>
        `).join('')}
      </ul>
    `,
  });
}

/* -------------------------------------------------------------------------- */
/* 27. Season finale                                                           */
/* -------------------------------------------------------------------------- */

function maybeFireSeasonFinale() {
  const s = gs(); if (!s) return;
  const turn = s.turn || 1;
  if (turn % 24 !== 0) return;
  openSeasonFinaleModal();
}

function openSeasonFinaleModal() {
  const s = gs();
  const chapter = chapterList()[(s.season - 1) % chapterList().length] || {};
  openModal({
    title: `赛季结算 · 第 ${s.season} 季`,
    bodyHtml: `
      <p>${esc(chapter.title || '本章结束')}</p>
      <p>${esc(chapter.description || '')}</p>
      <div class="kv-row">
        <div class="kv"><span>资金</span><b>${fmtKc(s.cash_kc)}</b></div>
        <div class="kv"><span>就绪度</span><b>${Math.round(s.cluster_readiness)}%</b></div>
        <div class="kv"><span>泡沫</span><b>${Math.round(s.bubble_pressure)}</b></div>
      </div>
    `,
    footerHtml: `
      <button class="btn btn--primary" data-action="modal-confirm" data-kind="advance-season">推进下一赛季</button>
    `,
  });
}

/* -------------------------------------------------------------------------- */
/* 28. Turn advance                                                            */
/* -------------------------------------------------------------------------- */

function doNextTurn() {
  const s = gs(); if (!s) return;
  if (s.main_action_used === false) {
    toast('未使用主行动：将按跳过处理', 'warn');
    App.dialogue = { speaker: '策划', text: '本回合无主行动，按默认消耗推进。' };
  }

  /* Advance annotation contracts */
  advanceContractsSafe(s);
  /* Update bubble / legal */
  safeCall('updateBubbleState', () => updateBubbleState(s));
  safeCall('stepLegalSystem', () => stepLegalSystem(s));

  /* Advance turn */
  const res = typeof advanceTurn === 'function'
    ? safeCall('advanceTurn', () => advanceTurn(s))
    : null;
  if (!res) {
    s.turn = (s.turn || 1) + 1;
    s.day_in_season = ((s.turn - 1) * 15) % 15 + 1;
    if (s.turn % 24 === 0) s.season = (s.season || 1) + 1;
    s.cash_kc = (s.cash_kc || 0) - estimateTurnBurn();
    s.main_action_used = false;
  }

  App.lastTurnSnap = { turn: s.turn };

  /* Fire story event or finale */
  if (maybeFireSeasonFinale()) {
    /* Modal handled */
  } else if (!maybeFireStoryEvent()) {
    /* nothing */
  }

  if (s.turn > MAX_TURN) {
    openEndingModal();
  }

  saveToStorage();
  rerenderAll();
}

function advanceContractsSafe(s) {
  if (typeof advanceAnnotationContracts !== 'function') return;
  try { advanceAnnotationContracts(s); } catch (e) { console.warn(e); }
}

/* -------------------------------------------------------------------------- */
/* 29. Endings                                                                 */
/* -------------------------------------------------------------------------- */

function openEndingModal() {
  const s = gs();
  const endings = endingList();
  const score = sumOf(STAT_KEYS.map(k => s.active_model?.stats?.[k] || 0)) +
                (s.cash_kc || 0) * 2 - (s.bubble_pressure || 0) * 3;
  const ending = endings.find(e => score >= (e.threshold ?? 0)) || endings[endings.length - 1] || { name: '平淡收场', description: '不算成功，也不算失败。' };
  openModal({
    title: '育成结束 · 结局分支',
    bodyHtml: `
      <h3>${esc(ending.name || '结局')}</h3>
      <p>${esc(ending.description || '')}</p>
      <div class="kv-row">
        <div class="kv"><span>综合评分</span><b>${Math.round(score)}</b></div>
        <div class="kv"><span>回合</span><b>${s.turn}</b></div>
      </div>
    `,
    footerHtml: `
      <button class="btn btn--primary" data-action="modal-close">好的</button>
    `,
  });
}

/* -------------------------------------------------------------------------- */
/* 30. Turn Previews                                                           */
/* -------------------------------------------------------------------------- */

function renderTurnPreview() {
  const text = $('#turn-preview-text');
  if (!text) return;
  if (!gs()) { text.textContent = '尚未开始游戏。'; return; }
  if (gs().main_action_used) { text.textContent = '本回合主行动已使用，将继续推进到下一回合。'; return; }
  const tab = App.ui.activeTab;
  const hints = {
    train: '训练：将消耗算力、资金与优化器健康，并可能提升能力数值。',
    data:  '数据：将消耗资金与短期算力，扩展数据集与上限。',
    prep:  '整备：将提升就绪度与优化器健康，并允许保存快照。',
    race:  '赛事：将消耗报名费，提升声誉，并放大对齐缺陷。',
    company: '公司：融资 / 财报 / 研究，将改变长期估值与泡沫压力。',
    codex: '档案：只读，不影响本回合结算。',
    settings: '设置：只读，不影响本回合结算。',
  };
  text.textContent = hints[tab] || '尚未选择主行动：本回合将按默认消耗推进，无额外收益。';
}

/* -------------------------------------------------------------------------- */
/* 31. Full re-render                                                          */
/* -------------------------------------------------------------------------- */

function rerenderAll() {
  if (!gs()) return;
  renderHUD();
  renderStatsPanel();
  renderCharacterStage();
  renderModelSummary();
  renderRisksPanel();
  renderDeckPanel();
  renderActiveTab();
  renderTurnPreview();
}

/* -------------------------------------------------------------------------- */
/* 32. Boot                                                                    */
/* -------------------------------------------------------------------------- */

function boot() {
  /* Try restore */
  const loaded = loadFromStorage();
  if (loaded) {
    App.state = normalizeState(loaded.state);
    toast('已恢复上次自动存档', 'info');
  } else {
    const profiles = profileList();
    const firstProfile = profiles[0]?.id ?? 'default';
    const firstHistory = historyList()[0]?.id ?? 'h01';
    App.state = createStateFromProfile(firstProfile, firstHistory);
    toast('欢迎！从「新游戏」可自定义开局。', 'info');
  }

  /* Restore prefs */
  const prefs = loadPrefs();
  if (prefs) {
    App.ui.activeTab = prefs.activeTab || 'train';
    App.ui.researchView = !!prefs.researchView;
    App.ui.tutorial.step = prefs.tutorialStep || 0;
  }

  /* Restore BYOK from session */
  const byok = loadByok();
  if (byok) {
    App.ui.settings.byokEnabled = true;
    App.ui.settings.byokEndpoint = byok.endpoint || '';
    App.ui.settings.byokModel = byok.model || '';
  }

  /* Wire click buttons on HUD */
  const btnRV = $('#btn-research-view');
  if (btnRV) btnRV.addEventListener('click', () => handleAction('toggle-research', btnRV, {}));
  const btnTut = $('#btn-tutorial');
  if (btnTut) btnTut.addEventListener('click', () => handleAction('toggle-tutorial', btnTut, {}));
  const btnNew = $('#btn-new-game');
  if (btnNew) btnNew.addEventListener('click', () => handleAction('open-new-game', btnNew, {}));
  const btnExp = $('#btn-export-save');
  if (btnExp) btnExp.addEventListener('click', () => handleAction('export-save', btnExp, {}));
  const btnImp = $('#btn-import-save');
  const impInput = $('#import-save-input');
  if (btnImp && impInput) btnImp.addEventListener('click', () => impInput.click());
  if (impInput) impInput.addEventListener('change', () => {
    const file = impInput.files?.[0];
    if (file) importSaveFile(file);
    impInput.value = '';
  });

  /* Wire main tabs */
  $$('#main-tabs .tab').forEach(t => {
    t.addEventListener('click', () => switchTab(t.dataset.tab));
    t.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') {
        ev.preventDefault();
        switchTab(t.dataset.tab);
      }
    });
  });

  /* Wire next turn */
  const btnNext = $('#btn-next-turn');
  if (btnNext) btnNext.addEventListener('click', () => handleAction('next-turn', btnNext, {}));

  /* Wire tutorial buttons */
  const tp = $('#btn-tutorial-prev'); if (tp) tp.addEventListener('click', () => setTutorialStep(App.ui.tutorial.step - 1));
  const tn = $('#btn-tutorial-next'); if (tn) tn.addEventListener('click', () => setTutorialStep(App.ui.tutorial.step + 1));
  const ts = $('#btn-tutorial-skip'); if (ts) ts.addEventListener('click', endTutorial);

  /* First render */
  recomputeTrainingPreview();
  rerenderAll();

  /* Autosave */
  setInterval(saveToStorage, 20000);

  /* Kick off tutorial if requested (first run) */
  if (!loaded && !prefs?.tutorialStep) {
    /* Leave closed; user can click 教程 */
  }

  /* Initial character greeting */
  App.dialogue = { speaker: '策划', text: '早上好。今天我们从一个很小的版本开始。' };
  renderCharacterStage();
}

/* Boot immediately (module script is deferred by default). */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}
