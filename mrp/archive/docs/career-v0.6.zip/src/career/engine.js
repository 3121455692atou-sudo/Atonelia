// 育成模式引擎：纯数据状态 + 种子随机数。界面只调用这里的函数，存档就是 state 本身。
import {
  CAREER_VERSION, TOTAL_WEEKS, STAT_CAP, STATS, STAT_INFO, STAT_GRADES, CHAPTERS, CAMP_WEEKS, CAMP_MULT,
  MARKET_WEEKS, UNLOCK_WEEKS, TRAININGS, TRAINING_LEVEL_STEP, TRAINING_LEVEL_MULT, MOODS, AILMENTS,
  CAREER_MODELS, MODEL_BY_ID, characterById, SUPPORT_POOL, SUPPORT_LINES, FRIENDSHIP_BOND, FRIENDSHIP_MULT,
  RACES, RACE_BY_ID, RACE_TIERS, RACE_ENERGY, RACE_FIELD, SKILLS, SKILL_BY_ID, MARKET_ITEMS, MARKET_ITEM_BY_ID,
  SERVICE_ROUTES, STORY_EVENTS, BUSINESS_EVENTS, LAWSUIT_EVENTS, RANDOM_EVENTS, RANDOM_EVENT_CHANCE,
  SUPPORT_FRIEND_EVENT, PERSONAL_EVENTS, RANKS, ENDINGS, SKILL_BONUS_CAP, FOCUS_START, FOCUS_GROWTH,
} from './data.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const SPECIALTY = Object.fromEntries(Object.entries(SUPPORT_POOL).flatMap(([type, ids]) => ids.map(id => [id, type])));
const BUSINESS_BY_ID = Object.fromEntries(BUSINESS_EVENTS.map(e => [e.id, e]));
const RANDOM_BY_ID = Object.fromEntries(RANDOM_EVENTS.map(e => [e.id, e]));
const PERSONAL_BY_ID = Object.fromEntries(PERSONAL_EVENTS.map(e => [e.id, e]));

export function rand(s) {
  let t = (s.rng = (s.rng + 0x6D2B79F5) >>> 0);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}
const pick = (s, list) => list[Math.floor(rand(s) * list.length)];
function shuffle(s, list) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand(s) * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

export function statGrade(v) {
  let g = 'G';
  for (const [min, label] of STAT_GRADES) if (v >= min) g = label;
  return g;
}
export function chapterOf(week) { return CHAPTERS.find(c => week >= c.from && week <= c.to) || CHAPTERS.at(-1); }
export function isCamp(s) { return CAMP_WEEKS.includes(s.week); }
export function modelOf(s) { return MODEL_BY_ID[s.characterId]; }
export function goalRaceAt(week) { return RACES.find(r => r.goal && r.week === week) || null; }
export function nextGoal(s) {
  const r = RACES.filter(x => x.goal && x.week >= s.week).sort((a, b) => a.week - b.week)[0];
  return r ? { race: r, weeksLeft: r.week - s.week } : null;
}
export function raceThisWeek(s) {
  const goal = goalRaceAt(s.week);
  if (goal) return goal;
  if (!s.unlocked.races || isCamp(s)) return null;
  return RACES.find(r => !r.goal && r.week === s.week) || null;
}
export function marketOpen(s) { return s.unlocked.market && MARKET_WEEKS.includes(s.week); }
export function trainingLevel(s, type) { return Math.min(TRAINING_LEVEL_MULT.length - 1, Math.floor((s.trainUses[type] || 0) / TRAINING_LEVEL_STEP)); }

export function createCareer(characterId, seed = Date.now()) {
  const model = MODEL_BY_ID[characterId];
  if (!model) throw new Error('只能育成模型角色');
  const s = {
    v: CAREER_VERSION, seed: seed >>> 0, rng: seed >>> 0, characterId, week: 1, status: 'playing',
    stats: {}, energy: 100, mood: 0, inspiration: 0, users: 0, reputation: 60, risk: 0, growth: 0,
    ailment: null, boost: 0, trainUses: {}, supports: {}, bonds: {}, board: {}, skills: [],
    unlocked: { skills: false, races: false, market: false, service: false }, service: null, flags: {},
    done: [], queue: [], races: [], retries: 1, pendingRace: null, raceStreak: 0,
    marketStock: [], marketBought: [], log: [], result: null,
  };
  for (const k of STATS) {
    s.stats[k] = 85 + (model.focus.includes(k) ? FOCUS_START[model.specialist ? 'specialist' : 'normal'] : 0) + Math.round(rand(s) * 20);
    s.trainUses[k] = 0;
    s.supports[k] = pick(s, SUPPORT_POOL[k]);
    s.bonds[s.supports[k]] = 10;
  }
  startWeek(s);
  return s;
}

function log(s, text) { s.log.push({ week: s.week, text }); if (s.log.length > 80) s.log.shift(); }

function startWeek(s) {
  s.board = Object.fromEntries(STATS.map(k => [k, []]));
  s.marketBought = [];
  for (const npc of Object.values(s.supports)) {
    if (rand(s) < 0.18) continue;
    const type = rand(s) < 0.62 ? SPECIALTY[npc] : pick(s, STATS);
    s.board[type].push(npc);
  }
  const w = s.week;
  const story = id => { if (!s.done.includes(id)) s.queue.push({ kind: 'story', id }); };
  if (w === 1) story('intro');
  if (w === UNLOCK_WEEKS.skills) story('unlock_skills');
  if (w === UNLOCK_WEEKS.races) story('unlock_races');
  if (w === UNLOCK_WEEKS.market) story('unlock_market');
  if (w === UNLOCK_WEEKS.service) story('service_launch');
  if (w === CAMP_WEEKS[0]) story('camp_start');
  if (w === 17) story('chapter3');
  for (const e of PERSONAL_EVENTS) {
    if (e.characterId === s.characterId && e.week === w && !s.done.includes(e.id)) s.queue.push({ kind: 'personal', id: e.id });
  }
  if (s.service) {
    for (const e of BUSINESS_EVENTS) {
      if (s.done.includes(e.id) || s.queue.some(q => q.id === e.id)) continue;
      const due = e.week ? e.week === w : w >= e.fromWeek && w <= (e.toWeek || TOTAL_WEEKS - 2);
      if (due && (!e.when || e.when(s))) { s.queue.push({ kind: 'business', id: e.id }); break; }
    }
    if (w >= 14 && w <= TOTAL_WEEKS - 2 && s.risk >= 50 && !s.done.includes('lawsuit') && rand(s) < 0.5) {
      s.queue.push({ kind: 'lawsuit', id: 'lawsuit', variant: s.flags.secret_routing ? 'routing_exposed' : 'abuse_case' });
    }
  }
  if (MARKET_WEEKS.includes(w)) {
    const rest = shuffle(s, MARKET_ITEMS.filter(i => i.id !== 'energy_drink')).slice(0, 4);
    s.marketStock = ['energy_drink', ...rest.map(i => i.id)];
  } else s.marketStock = [];
}

function endWeek(s, kind) {
  if (kind !== 'race') s.raceStreak = 0;
  if (s.service) {
    const route = SERVICE_ROUTES[s.service];
    const fit = clamp(route.stats.reduce((a, k) => a + s.stats[k], 0) / route.stats.length / 320, 0.5, 2.6);
    const gained = Math.round(route.users * fit * (1 + s.growth) * (0.5 + s.reputation / 120));
    s.users += gained;
    s.inspiration += route.inspiration;
    s.risk = clamp(s.risk + route.risk + Math.max(0, (320 - s.stats.safety) / 60), 0, 100);
  }
  if (s.week < TOTAL_WEEKS && rand(s) < RANDOM_EVENT_CHANCE) {
    const pool = RANDOM_EVENTS.filter(e => !s.done.includes(e.id) && (!e.needs || s[e.needs]));
    if (pool.length) {
      const e = pick(s, pool);
      const q = { kind: 'random', id: e.id };
      if (e.speaker === 'support:any') q.npc = pick(s, Object.values(s.supports));
      s.queue.push(q);
    }
  }
  s.week += 1;
  if (s.week > TOTAL_WEEKS) return finish(s, 'complete');
  startWeek(s);
}

// ---------- 效果 ----------
function addStat(s, k, v, changes) {
  const before = s.stats[k];
  s.stats[k] = clamp(Math.round(before + v), 1, STAT_CAP);
  if (s.stats[k] !== before) changes.push({ key: k, label: STAT_INFO[k].label, delta: s.stats[k] - before });
}
function addBond(s, npc, v, changes) {
  if (!npc || s.bonds[npc] === undefined) return;
  const before = s.bonds[npc];
  s.bonds[npc] = clamp(before + v, 0, 100);
  if (before < FRIENDSHIP_BOND && s.bonds[npc] >= FRIENDSHIP_BOND) {
    s.queue.push({ kind: 'friend', id: `friend_${npc}`, npc });
    changes.push({ key: 'friend', label: `与${characterById(npc).name}成为好友`, delta: 0 });
  }
}
function applyEffects(s, eff = {}, ctx = {}) {
  const changes = [];
  let outcome = null;
  for (const [k, v] of Object.entries(eff.stats || {})) addStat(s, k, v, changes);
  if (eff.energy) { const b = s.energy; s.energy = clamp(s.energy + eff.energy, 0, 100); if (s.energy !== b) changes.push({ key: 'energy', label: '体力', delta: s.energy - b }); }
  if (eff.mood) { const b = s.mood; s.mood = clamp(s.mood + eff.mood, -2, 2); if (s.mood !== b) changes.push({ key: 'mood', label: '心情', delta: s.mood - b }); }
  if (eff.inspiration) { const b = s.inspiration; s.inspiration = Math.max(0, s.inspiration + eff.inspiration); changes.push({ key: 'inspiration', label: '灵感', delta: s.inspiration - b }); }
  if (eff.users) { s.users = Math.max(0, s.users + eff.users); changes.push({ key: 'users', label: '用户', delta: eff.users }); }
  if (eff.usersPct) { const d = Math.round(s.users * eff.usersPct); s.users += d; changes.push({ key: 'users', label: '用户', delta: d }); }
  if (eff.reputation) { const b = s.reputation; s.reputation = clamp(s.reputation + eff.reputation, 0, 100); changes.push({ key: 'reputation', label: '口碑', delta: s.reputation - b }); }
  if (eff.risk) { s.risk = clamp(s.risk + eff.risk, 0, 100); changes.push({ key: 'risk', label: '风险', delta: eff.risk }); }
  if (eff.riskSet !== undefined) s.risk = eff.riskSet;
  if (eff.growth) { s.growth += eff.growth; changes.push({ key: 'growth', label: '用户增长', delta: Math.round(eff.growth * 100), pct: true }); }
  if (eff.flag) s.flags[eff.flag] = true;
  if (eff.service) { s.service = eff.service; s.unlocked.service = true; s.users += 800; changes.push({ key: 'service', label: `${SERVICE_ROUTES[eff.service].label} 上线`, delta: 0 }); }
  if (eff.cure && s.ailment) { changes.push({ key: 'cure', label: `${AILMENTS[s.ailment].label}治好了`, delta: 0 }); s.ailment = null; }
  if (eff.boost) { s.boost += eff.boost; changes.push({ key: 'boost', label: '下次训练', delta: Math.round(eff.boost * 100), pct: true }); }
  if (eff.bondSupport) addBond(s, s.supports[eff.bondSupport.type], eff.bondSupport.value, changes);
  if (eff.bondSpeaker) addBond(s, ctx.npc, eff.bondSpeaker, changes);
  if (eff.supportStat && ctx.npc) addStat(s, SPECIALTY[ctx.npc], eff.supportStat, changes);
  if (eff.ailmentChance && rand(s) < eff.ailmentChance.p) {
    s.ailment = eff.ailmentChance.id;
    changes.push({ key: 'ailment', label: `出现「${AILMENTS[s.ailment].label}」`, delta: 0 });
  }
  if (eff.gamble) {
    const win = rand(s) < eff.gamble.p;
    outcome = win ? 'win' : 'lose';
    const sub = applyEffects(s, win ? eff.gamble.win : eff.gamble.lose, ctx);
    changes.push(...sub.changes);
  }
  return { changes, outcome };
}

export function formatEffects(eff = {}) {
  const parts = [];
  for (const [k, v] of Object.entries(eff.stats || {})) parts.push(`${STAT_INFO[k].label} ${v > 0 ? '+' : ''}${v}`);
  if (eff.energy) parts.push(`体力 ${eff.energy > 0 ? '+' : ''}${eff.energy}`);
  if (eff.mood) parts.push(`心情 ${eff.mood > 0 ? '+' : ''}${eff.mood}`);
  if (eff.inspiration) parts.push(`灵感 ${eff.inspiration > 0 ? '+' : ''}${eff.inspiration}`);
  if (eff.users) parts.push(`用户 +${eff.users}`);
  return parts.join(' · ');
}

// ---------- 事件 ----------
function fill(text, s, npc) {
  const m = modelOf(s);
  return String(text || '').replaceAll('{name}', m.name).replaceAll('{quote}', m.quote || '').replaceAll('{npc}', npc ? characterById(npc).name : '');
}
function speakerOf(s, speaker, npc) {
  let id = speaker;
  if (speaker === 'self') id = s.characterId;
  else if (speaker === 'support:any') id = npc;
  else if (String(speaker).startsWith('support:')) id = s.supports[speaker.split(':')[1]];
  const c = characterById(id) || characterById(s.characterId);
  return { id: c.id, name: c.name, label: c.label, isSelf: c.id === s.characterId };
}
function eventDef(q) {
  if (q.kind === 'story') return STORY_EVENTS[q.id];
  if (q.kind === 'business') return BUSINESS_BY_ID[q.id];
  if (q.kind === 'random') return RANDOM_BY_ID[q.id];
  if (q.kind === 'friend') return { ...SUPPORT_FRIEND_EVENT, speaker: 'support:any' };
  if (q.kind === 'lawsuit') return { ...LAWSUIT_EVENTS[q.variant], choices: LAWSUIT_EVENTS.choices };
  if (q.kind === 'personal') {
    const e = PERSONAL_BY_ID[q.id];
    return { tag: '个人剧情', speaker: 'self', title: e.title, text: e.scene, line: e.line, fact: e.fact,
      choices: e.choices.map(c => ({ label: c.label, hint: formatEffects(c.effects), cost: c.cost, effects: c.effects, result: c.result })) };
  }
  return null;
}

export function currentEvent(s) {
  const q = s.queue[0];
  if (!q) return null;
  const d = eventDef(q);
  const npc = q.npc || null;
  return {
    kind: q.kind, tag: d.tag || (q.kind === 'random' ? '随机事件' : '事件'),
    title: fill(d.title, s, npc), text: fill(d.text, s, npc), line: fill(d.line, s, npc),
    speaker: speakerOf(s, d.speaker, npc), fact: d.fact || null,
    choices: d.choices.map(c => ({ label: c.label, hint: c.hint || '', disabled: (c.cost || 0) > s.inspiration, cost: c.cost || 0 })),
  };
}

export function resolveEvent(s, index) {
  const q = s.queue[0];
  if (!q) throw new Error('没有待处理的事件');
  const d = eventDef(q);
  const c = d.choices[index];
  if (!c) throw new Error('无效的选项');
  if ((c.cost || 0) > s.inspiration) throw new Error('灵感不足');
  s.queue.shift();
  if (q.kind !== 'friend') s.done.push(q.kind === 'lawsuit' ? 'lawsuit' : q.id);
  if (d.unlock) s.unlocked[d.unlock] = true;
  const { changes, outcome } = applyEffects(s, c.effects, { npc: q.npc });
  let result = c.result || '';
  if (outcome === 'win') result = result || '赌对了！一切顺利。';
  if (outcome === 'lose') result = result || '事情没有往好的方向发展……';
  log(s, `${fill(d.title, s, q.npc)}：${c.label}`);
  return { title: fill(d.title, s, q.npc), choice: c.label, result: fill(result, s, q.npc), changes, outcome };
}

// ---------- 行动 ----------
export function availableActions(s) {
  const goalWeek = !!goalRaceAt(s.week);
  const race = raceThisWeek(s);
  return {
    train: !goalWeek, rest: !goalWeek, outing: !goalWeek,
    race: race ? race.id : null, goalWeek,
    skills: s.unlocked.skills, market: marketOpen(s), debug: !!s.ailment && !goalWeek,
  };
}
function assertCanAct(s) {
  if (s.status !== 'playing') throw new Error('育成已经结束');
  if (s.queue.length) throw new Error('请先处理事件');
  if (s.pendingRace) throw new Error('请先决定是否再挑战');
}

export function failRate(s, type) {
  let f = Math.max(0, (52 - s.energy) * 1.9);
  if (type === 'safety') f *= 0.45;
  return Math.round(clamp(f, 0, 95));
}

export function trainingPreview(s, type) {
  const t = TRAININGS[type];
  const model = modelOf(s);
  const level = trainingLevel(s, type);
  const supporters = s.board[type] || [];
  const friends = supporters.filter(n => s.bonds[n] >= FRIENDSHIP_BOND && SPECIALTY[n] === type);
  let mult = TRAINING_LEVEL_MULT[level] * MOODS[s.mood].mult * (isCamp(s) ? CAMP_MULT : 1)
    * (s.ailment ? AILMENTS[s.ailment].train : 1) * (1 + s.boost) * Math.pow(FRIENDSHIP_MULT, friends.length);
  const gains = {};
  for (const [k, base] of Object.entries(t.gains)) {
    let v = base + (k === type ? supporters.length * 7 : supporters.length * 3);
    v *= mult;
    if (model.focus.includes(k)) v *= FOCUS_GROWTH[model.specialist ? 'specialist' : 'normal'];
    gains[k] = Math.round(v);
  }
  return {
    type, label: t.label, place: t.place, level, gains, energy: t.energy, fail: failRate(s, type),
    supporters, friends, inspiration: (t.inspiration || 0) + 4 + supporters.length * 2,
  };
}

export function doTraining(s, type) {
  assertCanAct(s);
  if (!TRAININGS[type]) throw new Error('未知的训练');
  if (goalRaceAt(s.week)) throw new Error('本周要参加目标评测');
  const p = trainingPreview(s, type);
  const changes = [];
  const failed = rand(s) * 100 < p.fail;
  let levelUp = false;
  if (failed) {
    addStat(s, type, -10, changes);
    const b = s.energy; s.energy = clamp(s.energy + Math.round(p.energy / 2), 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - b });
    if (s.mood > -2) { s.mood -= 1; changes.push({ key: 'mood', label: '心情', delta: -1 }); }
    if (!s.ailment && rand(s) < 0.35) { s.ailment = 'overfit'; changes.push({ key: 'ailment', label: '出现「过拟合」', delta: 0 }); }
    log(s, `${p.label}训练失败`);
  } else {
    for (const [k, v] of Object.entries(p.gains)) addStat(s, k, v, changes);
    const b = s.energy; s.energy = clamp(s.energy + p.energy, 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - b });
    s.inspiration += p.inspiration; changes.push({ key: 'inspiration', label: '灵感', delta: p.inspiration });
    const before = trainingLevel(s, type);
    s.trainUses[type] += 1;
    levelUp = trainingLevel(s, type) > before;
    s.boost = 0;
    for (const npc of p.supporters) addBond(s, npc, 8, changes);
    log(s, `${p.label}训练成功`);
  }
  endWeek(s, 'train');
  return { kind: 'train', type, success: !failed, changes, levelUp, supporters: p.supporters, friends: p.friends };
}

export function doRest(s) {
  assertCanAct(s);
  if (goalRaceAt(s.week)) throw new Error('本周要参加目标评测');
  const amount = pick(s, [40, 50, 50, 60, 70]);
  const changes = [];
  const b = s.energy; s.energy = clamp(s.energy + amount, 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - b });
  if (s.ailment && rand(s) < 0.3) { changes.push({ key: 'cure', label: `${AILMENTS[s.ailment].label}好转了`, delta: 0 }); s.ailment = null; }
  log(s, '休息');
  endWeek(s, 'rest');
  return { kind: 'rest', changes };
}

export function doOuting(s) {
  assertCanAct(s);
  if (goalRaceAt(s.week)) throw new Error('本周要参加目标评测');
  const changes = [];
  const moodUp = rand(s) < 0.3 ? 2 : 1;
  const bm = s.mood; s.mood = clamp(s.mood + moodUp, -2, 2); if (s.mood !== bm) changes.push({ key: 'mood', label: '心情', delta: s.mood - bm });
  const be = s.energy; s.energy = clamp(s.energy + (isCamp(s) ? 15 : 10), 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - be });
  log(s, isCamp(s) ? '海边散步' : '外出');
  endWeek(s, 'outing');
  return { kind: 'outing', changes, camp: isCamp(s) };
}

export function doDebug(s) {
  assertCanAct(s);
  if (!s.ailment) throw new Error('现在没有异常状态');
  const changes = [{ key: 'cure', label: `${AILMENTS[s.ailment].label}治好了`, delta: 0 }];
  s.ailment = null;
  const b = s.energy; s.energy = clamp(s.energy + 15, 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - b });
  log(s, '调试修复');
  endWeek(s, 'debug');
  return { kind: 'debug', changes };
}

export function learnSkill(s, id) {
  const sk = SKILL_BY_ID[id];
  if (!sk) throw new Error('未知技能');
  if (!s.unlocked.skills) throw new Error('技能尚未解锁');
  if (s.skills.includes(id)) throw new Error('已经学会了');
  if (sk.fromWeek && s.week < sk.fromWeek) throw new Error(`第 ${sk.fromWeek} 周后才能学习`);
  if (s.inspiration < sk.cost) throw new Error('灵感不足');
  s.inspiration -= sk.cost;
  s.skills.push(id);
  log(s, `学会技能「${sk.name}」`);
  return sk;
}

export function buyItem(s, id) {
  const item = MARKET_ITEM_BY_ID[id];
  if (!item || !marketOpen(s) || !s.marketStock.includes(id)) throw new Error('集市没有这件商品');
  if (s.marketBought.includes(id)) throw new Error('本周已经买过了');
  if (s.inspiration < item.cost) throw new Error('灵感不足');
  s.inspiration -= item.cost;
  s.marketBought.push(id);
  log(s, `购买「${item.name}」`);
  return applyEffects(s, item.effects).changes;
}

// ---------- 比赛 ----------
function mainStatOf(race) {
  const entries = Object.entries(race.weights).sort((a, b) => b[1] - a[1]);
  return entries[0][1] - (entries[1]?.[1] || 0) < 0.05 ? 'all' : entries[0][0];
}
export function skillBonus(s, race) {
  const main = mainStatOf(race);
  let bonus = 0;
  const fired = [];
  for (const id of s.skills) {
    const sk = SKILL_BY_ID[id];
    if (!sk.bonus) continue;
    let add = 0;
    for (const [k, v] of Object.entries(sk.bonus)) {
      if (k === 'all') add += v;
      else if (k === 'goal') { if (race.goal) add += v; }
      else if (k === main) add += v;
      else if ((race.weights[k] || 0) >= 0.2) add += v / 2;
    }
    if (add > 0) { bonus += add; fired.push(sk.name); }
  }
  return { bonus: Math.min(SKILL_BONUS_CAP, bonus), fired };
}
export function rivalLevel(week) { return 116 + week * 13; }
function raceScore(stats, weights) { return Object.entries(weights).reduce((a, [k, w]) => a + w * stats[k], 0); }

export function racePreview(s, raceId) {
  const race = RACE_BY_ID[raceId];
  const { bonus, fired } = skillBonus(s, race);
  return { race, power: Math.round(raceScore(s.stats, race.weights)), rival: Math.round(rivalLevel(race.week)), bonus, skills: fired, streakWarning: s.raceStreak >= 2 };
}

function simulateRace(s, race) {
  const rivals = shuffle(s, CAREER_MODELS.filter(m => m.id !== s.characterId));
  const headliners = ['gpt', 'claude', 'gemini', 'deepseek'];
  if (race.id === 'gala') rivals.sort((a, b) => headliners.includes(b.id) - headliners.includes(a.id));
  const strengths = shuffle(s, [1.06, 1.01, 0.97, 0.93, 0.89, 0.85, 0.81, 0.77]).map(x => (x + (race.goal ? 0.02 : 0)) * (race.diff || 1));
  if (race.id === 'gala') strengths.sort((a, b) => b - a);
  const base = rivalLevel(race.week);
  const field = rivals.slice(0, RACE_FIELD - 1).map((m, i) => {
    const stats = Object.fromEntries(STATS.map(k => [k, base * strengths[i] * (m.focus.includes(k) ? 1.18 : 0.94)]));
    return { id: m.id, name: m.name, isPlayer: false, score: raceScore(stats, race.weights) * (0.94 + rand(s) * 0.12) };
  });
  const { bonus, fired } = skillBonus(s, race);
  const calm = s.skills.includes('calm');
  const steady = s.skills.includes('self_consistency');
  const moodMult = calm ? Math.max(1, MOODS[s.mood].race) : MOODS[s.mood].race;
  const ail = s.ailment ? AILMENTS[s.ailment].race : 1;
  const roll = steady ? 0.99 + rand(s) * 0.07 : 0.94 + rand(s) * 0.12;
  const me = { id: s.characterId, name: modelOf(s).name, isPlayer: true, score: raceScore(s.stats, race.weights) * moodMult * (1 + bonus) * ail * roll };
  const all = [...field, me].sort((a, b) => b.score - a.score).map((r, i) => ({ ...r, score: Math.round(r.score), rank: i + 1 }));
  return { field: all, rank: all.find(r => r.isPlayer).rank, skills: fired };
}

export function doRace(s, raceId) {
  assertCanAct(s);
  const race = raceThisWeek(s);
  if (!race || race.id !== raceId) throw new Error('本周没有这场比赛');
  return runRace(s, race);
}

export function retryRace(s) {
  if (!s.pendingRace || s.retries <= 0) throw new Error('没有可以再挑战的比赛');
  const race = RACE_BY_ID[s.pendingRace];
  s.retries -= 1;
  s.pendingRace = null;
  return runRace(s, race, true);
}

export function giveUpRace(s) {
  if (!s.pendingRace) throw new Error('没有待决定的比赛');
  const race = RACE_BY_ID[s.pendingRace];
  s.pendingRace = null;
  s.races.push({ id: race.id, name: race.name, week: s.week, rank: s.lastRaceRank, tier: race.tier, goal: true, met: false });
  finish(s, 'goal_failed');
  return s.result;
}

function runRace(s, race, isRetry = false) {
  const sim = simulateRace(s, race);
  const goalMet = !race.goal || race.soft || sim.rank <= race.goal;
  if (!goalMet) {
    s.lastRaceRank = sim.rank;
    if (s.retries > 0) {
      s.pendingRace = race.id;
      return { kind: 'race', race, ...sim, goalMet, canRetry: true, changes: [], isRetry };
    }
    s.races.push({ id: race.id, name: race.name, week: s.week, rank: sim.rank, tier: race.tier, goal: true, met: false });
    finish(s, 'goal_failed');
    return { kind: 'race', race, ...sim, goalMet, canRetry: false, ended: true, changes: [], isRetry };
  }
  const changes = [];
  const tier = RACE_TIERS[race.tier];
  const idx = sim.rank - 1;
  const insp = tier.reward[idx] ?? Math.round(tier.reward.at(-1) / 2);
  const users = tier.users[idx] ?? Math.round(tier.users.at(-1) / 2);
  s.inspiration += insp; changes.push({ key: 'inspiration', label: '灵感', delta: insp });
  s.users += users; changes.push({ key: 'users', label: '用户', delta: users });
  const mult = sim.rank === 1 ? 1.6 : sim.rank <= 3 ? 1.2 : 0.8;
  for (const [k, w] of Object.entries(race.weights)) if (w >= 0.15) addStat(s, k, Math.round(w * 45 * mult), changes);
  const b = s.energy; s.energy = clamp(s.energy + RACE_ENERGY, 0, 100); changes.push({ key: 'energy', label: '体力', delta: s.energy - b });
  if (sim.rank === 1 && s.mood < 2) { s.mood += 1; changes.push({ key: 'mood', label: '心情', delta: 1 }); }
  s.raceStreak += 1;
  if (s.raceStreak >= 3 && s.mood > -2) { s.mood -= 1; changes.push({ key: 'mood', label: '连续比赛太累了 · 心情', delta: -1 }); }
  s.races.push({ id: race.id, name: race.name, week: s.week, rank: sim.rank, tier: race.tier, goal: !!race.goal, met: true });
  log(s, `${race.name} 第 ${sim.rank} 名`);
  endWeek(s, 'race');
  return { kind: 'race', race, ...sim, goalMet, canRetry: false, changes, isRetry };
}

// ---------- 结算 ----------
export function computeRating(s) {
  const statSum = STATS.reduce((a, k) => a + s.stats[k], 0);
  const racePts = s.races.reduce((a, r) => {
    const base = { G1: 120, G2: 80, G3: 50 }[r.tier] || 0;
    return a + (r.rank === 1 ? base : r.rank === 2 ? base * 0.6 : r.rank === 3 ? base * 0.35 : 0);
  }, 0);
  const goals = s.races.filter(r => r.goal && r.met).length * 120;
  const skills = s.skills.length * 30;
  const users = Math.min(400, Math.round(s.users / 250));
  const rep = s.service ? Math.round((s.reputation - 50) * 2) : 0;
  return { total: Math.round(statSum + racePts + goals + skills + users + rep), statSum, racePts: Math.round(racePts), goals, skills, users, rep };
}
export function rankOf(total) {
  let r = 'G';
  for (const [min, label] of RANKS) if (total >= min) r = label;
  return r;
}
function endingLine(reason, rank, galaRank) {
  if (reason === 'goal_failed') return ENDINGS.failed;
  if (galaRank === 1) return ['S', 'SS'].includes(rank) ? ENDINGS.champion_top : ENDINGS.champion;
  if (galaRank && galaRank <= 3) return ENDINGS.podium;
  return ENDINGS[rank] || ENDINGS.C;
}
function finish(s, reason) {
  s.status = 'ended';
  s.queue = [];
  const rating = computeRating(s);
  const rank = rankOf(rating.total);
  const gala = s.races.find(r => r.id === 'gala');
  s.result = {
    reason, rank, rating, week: Math.min(s.week, TOTAL_WEEKS),
    galaRank: gala ? gala.rank : null,
    ending: endingLine(reason, rank, gala ? gala.rank : null),
  };
  return s.result;
}

export function hallOfFameEntry(s) {
  const m = modelOf(s);
  return {
    at: new Date().toISOString(), characterId: s.characterId, name: m.name, rank: s.result.rank, total: s.result.rating.total,
    stats: { ...s.stats }, wins: s.races.filter(r => r.rank === 1).length, galaRank: s.result.galaRank, reason: s.result.reason,
  };
}

export function validateCareer(s) {
  if (!s || s.v !== CAREER_VERSION) return false;
  if (!MODEL_BY_ID[s.characterId]) return false;
  if (!Number.isInteger(s.week) || s.week < 1 || s.week > TOTAL_WEEKS + 1) return false;
  if (!STATS.every(k => Number.isFinite(s.stats?.[k]))) return false;
  if (!Array.isArray(s.queue) || !s.queue.every(q => eventDef(q))) return false;
  return true;
}

// 主界面「接下来」：未解锁的功能只显示为悬念。
export function upcoming(s, limit = 2) {
  const items = [];
  for (let w = s.week + 1; w <= TOTAL_WEEKS && items.length < limit; w++) {
    const goal = goalRaceAt(w);
    if (goal) { items.push({ week: w, label: goal.name, kind: 'goal' }); continue; }
    if (Object.entries(UNLOCK_WEEKS).some(([k, uw]) => uw === w && !s.unlocked[k])) { items.push({ week: w, label: '会有新的事情发生', kind: 'mystery' }); continue; }
    if (w === CAMP_WEEKS[0]) { items.push({ week: w, label: '夏季集训营开始', kind: 'camp' }); continue; }
    if (s.unlocked.market && MARKET_WEEKS.includes(w)) { items.push({ week: w, label: '数据集市开市', kind: 'market' }); continue; }
    const race = s.unlocked.races && !CAMP_WEEKS.includes(w) && RACES.find(r => !r.goal && r.week === w);
    if (race) items.push({ week: w, label: `${race.tier} ${race.name}`, kind: 'race' });
  }
  return items;
}

export function supportLine(npc) { return SUPPORT_LINES[npc] || '一起加油吧！'; }
export function specialtyOf(npc) { return SPECIALTY[npc]; }
