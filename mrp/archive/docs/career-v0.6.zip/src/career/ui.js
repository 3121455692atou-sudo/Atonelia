// 育成模式界面：标题 → 选人 → 每周行动 → 事件 / 比赛 → 结算。
import * as E from './engine.js';
import * as D from './data.js';

const SAVE_KEY = 'mrp.career.v1';
const HOF_KEY = 'mrp.career.hof.v1';
const app = document.getElementById('app');
const overlayRoot = document.getElementById('overlay-root');
const toastRoot = document.getElementById('toast-root');

let S = null;
const ui = { screen: 'title', mode: 'home', trainSel: null, selectId: null, lineIndex: 0, busy: false, emotion: 'neutral' };

// ---------- 工具 ----------
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const wait = ms => new Promise(r => setTimeout(r, ms));
function store(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* 隐私模式下忽略 */ } }
function load(key) { try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; } catch { return null; } }
function save() { if (S) store(SAVE_KEY, S); }
function clearSave() { try { localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ } }
function fmtUsers(n) { return n >= 10000 ? `${(n / 10000).toFixed(n >= 100000 ? 0 : 1)} 万` : String(n); }
function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  toastRoot.append(el);
  setTimeout(() => el.classList.add('out'), 2200);
  setTimeout(() => el.remove(), 2600);
}

const ICONS = {
  train: '<path d="M6 5v14M18 5v14M3 9v6M21 9v6M6 12h12"/>',
  rest: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5Z"/>',
  outing: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  race: '<path d="M5 21V4m0 0h12l-2.5 4L17 12H5"/>',
  skills: '<path d="m12 2 2.6 6.9L22 12l-7.4 3.1L12 22l-2.6-6.9L2 12l7.4-3.1L12 2Z"/>',
  market: '<path d="M5 8h14l-1.2 13H6.2L5 8Zm4 0V6.5a3 3 0 0 1 6 0V8"/>',
  debug: '<path d="M14.7 6.3a4 4 0 0 0 5 5L11 20a2.1 2.1 0 0 1-3-3l8.7-8.7a4 4 0 0 0-2-2Z"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  back: '<path d="M15 18l-6-6 6-6"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm13 10v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>',
  trophy: '<path d="M7 4h10v5a5 5 0 0 1-10 0V4Zm0 2H3v2a4 4 0 0 0 4 4m10-6h4v2a4 4 0 0 1-4 4M12 14v4m-4 3h8"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
};
const icon = (name, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]}</svg>`;

// ---------- 美术 ----------
const thumb = (src, variant) => src.replace('/characters/', '/thumbs/').replace(/\.png$/, `-${variant}.webp`);
function charArt(id, variant = 'card', emotion = 'neutral') {
  const c = D.characterById(id);
  if (!c) return '';
  const sprites = c.sprites || {};
  return thumb(sprites[emotion] || sprites.neutral || c.src, variant);
}
// 背景写进 CSS 变量时，相对地址会按样式表目录解析，所以先转成绝对地址。
const abs = path => new URL(path, document.baseURI).href;
const BG = {
  home: abs('./assets/thumbs/bg-sunlit-atelier.webp'), camp: abs('./assets/thumbs/bg-career-camp.webp'),
  outing: abs('./assets/thumbs/bg-career-outing.webp'), arena: abs('./assets/thumbs/bg-career-arena.webp'), gala: abs('./assets/thumbs/bg-career-gala.webp'),
};
function stageBg() {
  if (!S) return BG.home;
  if (E.isCamp(S)) return BG.camp;
  if (ui.emotion === 'outing') return BG.outing;
  return BG.home;
}
const face = (id, cls = '') => `<img class="face ${cls}" src="${charArt(id, 'face')}" alt="" loading="lazy" />`;

// ---------- 台词 ----------
function homeLine() {
  const m = E.modelOf(S);
  const goal = E.nextGoal(S);
  const lines = [];
  if (E.goalRaceAt(S.week)) lines.push(`就是今天——${E.goalRaceAt(S.week).name}。我准备好了！`);
  if (S.ailment) lines.push(`好像有点「${D.AILMENTS[S.ailment].label}」了……能帮我调试一下吗？`);
  if (S.energy < 35) lines.push('有点累了……这周能让我休息一下吗？');
  if (S.mood <= -1) lines.push('心里闷闷的，想出去走走。');
  if (E.isCamp(S)) lines.push('海风好舒服！集训营的训练效率特别高哦。');
  if (goal && goal.weeksLeft > 0 && goal.weeksLeft <= 2) lines.push(`${goal.race.name}还有 ${goal.weeksLeft} 周，再加把劲！`);
  if (E.raceThisWeek(S) && !E.goalRaceAt(S.week)) lines.push(`这周有「${E.raceThisWeek(S).name}」，要报名试试吗？`);
  if (E.marketOpen(S)) lines.push('数据集市开市啦，去看看有什么好东西？');
  lines.push(m.quote, '今天想练哪一项？我都可以！', '一起进步一点点吧。', '下一版的我们，一定会更好。');
  return lines[ui.lineIndex % lines.length];
}
function portraitEmotion() {
  const e = ui.emotion === 'outing' ? 'happy' : ui.emotion;
  const c = D.characterById(S.characterId);
  return c.sprites && c.sprites[e] ? e : 'neutral';
}

// ---------- 渲染 ----------
function render() {
  if (ui.screen === 'title') return renderTitle();
  if (ui.screen === 'select') return renderSelect();
  if (ui.screen === 'result') return renderResult();
  return renderHome();
}

function renderTitle() {
  const saved = load(SAVE_KEY);
  const canContinue = saved && E.validateCareer(saved) && saved.status === 'playing';
  const hof = load(HOF_KEY) || [];
  const lineup = ['claude', 'qwen', 'deepseek', 'gemini', 'gpt'];
  app.className = 'app app--title';
  app.innerHTML = `
  <section class="title-screen" style="--bg:url('${BG.home}')">
    <div class="title-lineup" aria-hidden="true">${lineup.map((id, i) => `<img src="${charArt(id, 'stage')}" alt="" style="--i:${i}" />`).join('')}</div>
    <div class="title-card">
      <span class="eyebrow">NEXT ITERATION</span>
      <h1>模型育成计划</h1>
      <p>和你的模型伙伴一起度过 24 周。<br />训练、比赛，把这一版送到用户手里。</p>
      <div class="title-actions">
        ${canContinue ? `<button class="btn btn--primary btn--xl" data-act="continue">继续育成 <small>${esc(D.MODEL_BY_ID[saved.characterId]?.name)} · 第 ${saved.week} 周</small></button>` : ''}
        <button class="btn ${canContinue ? 'btn--ghost' : 'btn--primary'} btn--xl" data-act="new">开始新的育成</button>
        ${hof.length ? `<button class="btn btn--ghost" data-act="hof">${icon('trophy')} 名人堂 · ${hof.length}</button>` : ''}
      </div>
    </div>
    <footer class="title-foot"><span>角色美术 · ZipZipPipe 等原作者（见图鉴出处）</span><a href="./legacy.html">旧版经营模式</a></footer>
  </section>`;
}

function renderSelect() {
  const sel = D.MODEL_BY_ID[ui.selectId] || null;
  app.className = 'app app--select';
  app.innerHTML = `
  <section class="select-screen">
    <header class="select-head">
      <button class="icon-btn" data-act="to-title" aria-label="返回标题">${icon('back')}</button>
      <div><span class="eyebrow">CHOOSE YOUR MODEL</span><h2>选择要育成的模型</h2></div>
    </header>
    <div class="select-body">
      <div class="select-grid" role="list">
        ${D.CAREER_MODELS.map(m => `
          <button class="pick-card ${m.id === ui.selectId ? 'is-on' : ''}" data-act="pick" data-id="${m.id}" role="listitem">
            <img src="${charArt(m.id, 'card')}" alt="" loading="lazy" />
            <span class="pick-name">${esc(m.name)}</span>
            <span class="pick-label">${esc(m.label)}</span>
            <span class="pick-focus">${m.focus.map(k => `<i style="--c:${D.STAT_INFO[k].color}">${D.STAT_INFO[k].label}${m.specialist ? '专精' : ''}</i>`).join('')}</span>
          </button>`).join('')}
      </div>
      ${sel ? selectDetail(sel) : `<aside class="select-detail select-detail--empty"><p>点一位模型，看看她的特长。</p></aside>`}
    </div>
  </section>`;
}
function selectDetail(m) {
  const events = D.PERSONAL_EVENTS.filter(e => e.characterId === m.id).length;
  return `
  <aside class="select-detail" aria-label="${esc(m.name)}">
    <button class="icon-btn select-detail__close" data-act="unpick" aria-label="关闭">${icon('close')}</button>
    <div class="select-detail__art" style="--bg:url('${BG.home}')"><img src="${charArt(m.id, 'stage')}" alt="${esc(m.name)}" /></div>
    <div class="select-detail__info">
      <span class="eyebrow">${esc(m.label)}</span>
      <h3>${esc(m.name)}</h3>
      <p class="quote">「${esc(m.quote)}」</p>
      <ul class="facts">
        <li><b>${m.specialist ? '专精' : '擅长'}</b>${m.focus.map(k => `<span class="chip" style="--c:${D.STAT_INFO[k].color}">${D.STAT_INFO[k].full}</span>`).join('')}<small>${m.specialist ? '只专精一项：成长 +18%，初始大幅领先' : '两项成长 +10%，初始更高'}</small></li>
        <li><b>个人剧情</b>${events} 段真实历史改编，会在育成途中出现</li>
      </ul>
      <button class="btn btn--primary btn--xl" data-act="start" data-id="${m.id}">就决定是她了！</button>
      <a class="credit" href="${esc(m.source_url)}" target="_blank" rel="noopener">美术 · ${esc(m.credit || '原作者')} ↗</a>
    </div>
  </aside>`;
}

function topBar() {
  const ch = E.chapterOf(S.week);
  const goal = E.nextGoal(S);
  const goalHtml = goal ? `
    <div class="goal-card ${goal.weeksLeft === 0 ? 'is-now' : ''}">
      <span class="goal-tag">目标</span>
      <div><strong>${esc(goal.race.name)}${goal.race.soft ? ' · 争夺第一' : ` · 前 ${goal.race.goal} 名`}</strong>
      <small>${goal.weeksLeft === 0 ? '就在本周！' : `第 ${goal.race.week} 周 · 还有 ${goal.weeksLeft} 周`}</small></div>
    </div>` : '';
  return `
  <header class="topbar">
    <div class="week-block"><span class="week-num">第 <b>${S.week}</b> 周</span><span class="week-total">/ ${D.TOTAL_WEEKS} · ${esc(ch.short)}</span></div>
    ${goalHtml}
    <div class="res-block">
      <span class="res" title="灵感：学习技能、逛集市">${icon('skills')}<b>${S.inspiration}</b><small>灵感</small></span>
      ${S.service ? `<span class="res" title="用户数">${icon('users')}<b>${fmtUsers(S.users)}</b><small>用户</small></span>` : ''}
      <button class="icon-btn" data-act="menu" aria-label="菜单">${icon('menu')}</button>
    </div>
  </header>
  ${timeline()}`;
}
function timeline() {
  const marks = [];
  for (let w = 1; w <= D.TOTAL_WEEKS; w++) {
    const goal = E.goalRaceAt(w);
    const cls = [w < S.week ? 'past' : '', w === S.week ? 'now' : '', goal ? 'goal' : '', D.CAMP_WEEKS.includes(w) ? 'camp' : '',
      S.unlocked.market && D.MARKET_WEEKS.includes(w) ? 'market' : ''].join(' ');
    const title = goal ? goal.name : D.CAMP_WEEKS.includes(w) ? '集训营' : S.unlocked.market && D.MARKET_WEEKS.includes(w) ? '数据集市' : `第 ${w} 周`;
    marks.push(`<i class="${cls}" title="第 ${w} 周 · ${esc(title)}"></i>`);
  }
  return `<div class="timeline" aria-label="育成进度 第 ${S.week} 周">${marks.join('')}</div>`;
}

function statsPanel() {
  const mood = D.MOODS[S.mood];
  const energyCls = S.energy >= 60 ? 'hi' : S.energy >= 35 ? 'mid' : 'lo';
  return `
  <div class="vitals">
    <div class="energy ${energyCls}">
      <span class="vlabel">${icon('bolt')}体力</span>
      <div class="bar"><i style="width:${S.energy}%"></i></div>
      <b>${S.energy}<small>/100</small></b>
    </div>
    <div class="mood mood--${S.mood}"><span class="vlabel">心情</span><b>${mood.label}</b></div>
  </div>
  <div class="stats" role="list">
    ${D.STATS.map(k => {
      const v = S.stats[k];
      const info = D.STAT_INFO[k];
      return `<div class="stat" role="listitem" data-stat="${k}" style="--c:${info.color}">
        <span class="stat-label">${info.label}</span>
        <span class="stat-grade">${E.statGrade(v)}</span>
        <b class="stat-val">${v}</b>
        <div class="stat-bar"><i style="width:${Math.min(100, v / 10)}%"></i></div>
      </div>`;
    }).join('')}
  </div>`;
}

function stage() {
  const m = E.modelOf(S);
  const chips = [];
  if (S.ailment) chips.push(`<span class="chip chip--warn">${esc(D.AILMENTS[S.ailment].label)} · ${esc(D.AILMENTS[S.ailment].desc)}</span>`);
  if (E.isCamp(S)) chips.push('<span class="chip chip--camp">集训营 · 训练 ×1.35</span>');
  if (S.boost) chips.push(`<span class="chip chip--boost">下次训练 +${Math.round(S.boost * 100)}%</span>`);
  if (S.service) chips.push(`<span class="chip chip--svc">${esc(D.SERVICE_ROUTES[S.service].label)} · 口碑 ${S.reputation}</span>`);
  return `
  <section class="stage" style="--bg:url('${stageBg()}')" aria-label="${esc(m.name)}">
    <div class="stage-chips">${chips.join('')}</div>
    <button class="stage-figure" data-act="talk" aria-label="和${esc(m.name)}说话">
      <img src="${charArt(S.characterId, 'stage', portraitEmotion())}" alt="${esc(m.name)}" />
    </button>
    <div class="nameplate"><b>${esc(m.name)}</b><span>${esc(m.label)}</span></div>
    <div class="bubble" data-act="talk"><p>${esc(ui.mode === 'train' ? trainLine() : homeLine())}</p></div>
    <div class="stage-fx" id="stage-fx"></div>
  </section>`;
}

function trainLine() {
  const p = E.trainingPreview(S, ui.trainSel);
  if (p.supporters.length) {
    const npc = p.supporters[0];
    return `${D.characterById(npc).name}：${E.supportLine(npc)}`;
  }
  if (p.fail >= 30) return '体力不太够了……这样练很可能会失败哦。';
  return { creative: '今天练创作吗？我有好多想写的！', coding: '来写代码吧，测试我都准备好了。', math: '推导一步一步来，我不会跳步的。',
    knowledge: '去图书馆吧，今天想读点新东西。', safety: '红队演练！我会守好边界的。' }[ui.trainSel];
}

function actionArea() {
  if (ui.mode === 'train') return trainArea();
  const a = E.availableActions(S);
  const race = a.race ? D.RACE_BY_ID[a.race] : null;
  const seen = S.uiSeen || {};
  const isNew = k => S.unlocked[k] && !seen[k];
  const learnable = D.SKILLS.filter(s => !S.skills.includes(s.id) && s.cost <= S.inspiration && (!s.fromWeek || S.week >= s.fromWeek)).length;
  if (a.goalWeek) {
    return `<div class="actions">
      <button class="act act--goal" data-act="race" data-id="${race.id}">${icon('trophy')}<span><b>出发！${esc(race.name)}</b><small>${race.soft ? '年度终点 · 争夺第一' : `目标：前 ${race.goal} 名`}</small></span></button>
      <div class="act-row act-row--mini">
        ${a.skills ? `<button class="mini ${isNew('skills') ? 'is-new' : ''}" data-act="skills">${icon('skills')}技能${learnable ? `<em>${learnable}</em>` : ''}</button>` : ''}
        ${a.market ? `<button class="mini ${isNew('market') ? 'is-new' : ''}" data-act="market">${icon('market')}集市<em>开市</em></button>` : ''}
      </div></div>`;
  }
  return `<div class="actions">
    <button class="act act--train" data-act="open-train">${icon('train')}<span><b>训练</b><small>选择一项能力来练习</small></span></button>
    <div class="act-row">
      <button class="act act--rest" data-act="rest">${icon('rest')}<span><b>休息</b><small>体力 约 +50</small></span></button>
      <button class="act act--outing" data-act="outing">${icon('outing')}<span><b>${E.isCamp(S) ? '海边散步' : '外出'}</b><small>心情 +1</small></span></button>
      ${race ? `<button class="act act--race ${isNew('races') ? 'is-new' : ''}" data-act="race" data-id="${race.id}">${icon('race')}<span><b>比赛</b><small>${race.tier} · ${esc(race.name)}</small></span></button>` : ''}
      ${a.debug ? `<button class="act act--debug" data-act="debug">${icon('debug')}<span><b>调试</b><small>治好${esc(D.AILMENTS[S.ailment].label)}</small></span></button>` : ''}
    </div>
    ${a.skills || a.market ? `<div class="act-row act-row--mini">
      ${a.skills ? `<button class="mini ${isNew('skills') ? 'is-new' : ''}" data-act="skills">${icon('skills')}技能${learnable ? `<em>${learnable}</em>` : ''}</button>` : ''}
      ${a.market ? `<button class="mini ${isNew('market') ? 'is-new' : ''}" data-act="market">${icon('market')}数据集市<em>开市</em></button>` : ''}
    </div>` : ''}
  </div>`;
}

function trainArea() {
  const sel = ui.trainSel;
  const p = E.trainingPreview(S, sel);
  return `<div class="train">
    <div class="train-head">
      <button class="icon-btn" data-act="close-train" aria-label="返回">${icon('back')}</button>
      <b>选择训练</b><small>点同一格两次可以直接开始</small>
    </div>
    <div class="train-tiles" role="radiogroup" aria-label="训练项目">
      ${D.STATS.map(k => {
        const t = E.trainingPreview(S, k);
        const info = D.STAT_INFO[k];
        return `<button class="tile ${k === sel ? 'is-on' : ''}" role="radio" aria-checked="${k === sel}" data-act="pick-train" data-id="${k}" style="--c:${info.color}">
          <span class="tile-lv">Lv${t.level + 1}</span>
          <b>${info.label}</b>
          <span class="tile-sup">${t.supporters.map(n => face(n, t.friends.includes(n) ? 'is-friend' : '')).join('')}</span>
          ${t.fail ? `<span class="tile-fail ${t.fail >= 30 ? 'hi' : ''}">失败 ${t.fail}%</span>` : '<span class="tile-ok">稳定</span>'}
        </button>`;
      }).join('')}
    </div>
    <div class="train-detail" style="--c:${D.STAT_INFO[sel].color}">
      <div class="train-place"><b>${esc(p.place)}</b><span>Lv${p.level + 1} · 已练 ${S.trainUses[sel]} 次${p.level < 4 ? ` · 再练 ${D.TRAINING_LEVEL_STEP - (S.trainUses[sel] % D.TRAINING_LEVEL_STEP)} 次升级` : ' · 已满级'}</span></div>
      <div class="gains">
        ${Object.entries(p.gains).map(([k, v]) => `<span class="gain" style="--c:${D.STAT_INFO[k].color}">${D.STAT_INFO[k].label}<b>+${v}</b></span>`).join('')}
        <span class="gain gain--energy">体力<b>${p.energy}</b></span>
        <span class="gain gain--insp">灵感<b>+${p.inspiration}</b></span>
      </div>
      ${p.supporters.length ? `<p class="sup-note">${p.supporters.map(n => `${esc(D.characterById(n).name)}${p.friends.includes(n) ? '（友情训练！）' : ''}`).join('、')} 一起训练 · 羁绊 +8</p>` : ''}
      <button class="btn btn--primary btn--xl btn--train" data-act="do-train" data-id="${sel}">开始训练${p.fail ? `<small>失败率 ${p.fail}%</small>` : ''}</button>
    </div>
  </div>`;
}

function todayStrip() {
  const present = D.STATS.flatMap(k => (S.board[k] || []).map(npc => ({ npc, k })));
  const next = E.upcoming(S);
  return `<div class="today">
    ${E.goalRaceAt(S.week) ? '' : `<div class="today-row"><span class="today-label">今天的伙伴</span>
      <div class="today-sup">${present.length ? present.map(({ npc, k }) => `<span class="sup" title="${esc(D.characterById(npc).name)} 在${D.STAT_INFO[k].label}训练">${face(npc, S.bonds[npc] >= D.FRIENDSHIP_BOND ? 'is-friend' : '')}<small style="--c:${D.STAT_INFO[k].color}">${D.STAT_INFO[k].label}</small></span>`).join('') : '<span class="muted">大家今天都不在训练场</span>'}</div>
    </div>`}
    ${next.length ? `<div class="today-row"><span class="today-label">接下来</span><div class="today-next">${next.map(n => `<span class="nx nx--${n.kind}"><b>第 ${n.week} 周</b>${esc(n.label)}</span>`).join('')}</div></div>` : ''}
  </div>`;
}

function renderHome() {
  app.className = `app app--home ${ui.mode === 'train' ? 'is-training' : ''}`;
  app.innerHTML = `
  ${topBar()}
  <main class="home">
    ${stage()}
    <section class="panel">
      ${statsPanel()}
      ${ui.mode === 'home' ? todayStrip() : ''}
      ${actionArea()}
    </section>
  </main>`;
}

// ---------- 行动反馈 ----------
function changeChips(changes) {
  return changes.map(c => {
    if (c.key in D.STAT_INFO) return `<span class="delta" style="--c:${D.STAT_INFO[c.key].color}">${c.label} <b>${c.delta > 0 ? '+' : ''}${c.delta}</b></span>`;
    if (c.delta === 0) return `<span class="delta delta--note">${esc(c.label)}</span>`;
    const v = c.key === 'users' ? fmtUsers(Math.abs(c.delta)) : Math.abs(c.delta);
    return `<span class="delta delta--${c.key} ${c.delta < 0 ? 'neg' : ''}">${esc(c.label)} <b>${c.delta > 0 ? '+' : '-'}${v}${c.pct ? '%' : ''}</b></span>`;
  }).join('');
}
function floatStatChanges(changes) {
  for (const c of changes) {
    if (!(c.key in D.STAT_INFO)) continue;
    const el = app.querySelector(`.stat[data-stat="${c.key}"]`);
    if (!el) continue;
    const f = document.createElement('span');
    f.className = `float ${c.delta < 0 ? 'neg' : ''}`;
    f.textContent = `${c.delta > 0 ? '+' : ''}${c.delta}`;
    el.append(f);
    el.classList.add('pulse');
  }
}
function showFeedback(title, changes, tone = 'good') {
  return new Promise(resolve => {
    const fx = document.getElementById('stage-fx');
    if (!fx) return resolve();
    fx.innerHTML = `<div class="fb fb--${tone}" role="status"><b>${esc(title)}</b><div class="deltas">${changeChips(changes)}</div><small>点击继续</small></div>`;
    floatStatChanges(changes);
    let done = false;
    const finish = () => { if (done) return; done = true; fx.innerHTML = ''; resolve(); };
    fx.firstElementChild.addEventListener('click', finish);
    setTimeout(finish, 2600);
  });
}

// ---------- 弹窗 ----------
function openOverlay(html, cls = '') {
  overlayRoot.innerHTML = `<div class="overlay ${cls}"><div class="sheet" role="dialog" aria-modal="true">${html}</div></div>`;
  const sheet = overlayRoot.querySelector('.sheet');
  sheet.querySelector('button:not([disabled])')?.focus({ preventScroll: true });
  return overlayRoot.firstElementChild;
}
function closeOverlay() { overlayRoot.innerHTML = ''; }
function waitClick(root, selector) {
  return new Promise(resolve => {
    root.addEventListener('click', function handler(ev) {
      const b = ev.target.closest(selector);
      if (!b || b.disabled) return;
      root.removeEventListener('click', handler);
      resolve(b);
    });
  });
}

function eventHtml(ev) {
  const sp = ev.speaker;
  return `
  <div class="ev ev--${ev.kind}">
    <div class="ev-head"><span class="ev-tag">${esc(ev.tag)}</span><h3>${esc(ev.title)}</h3></div>
    <div class="ev-body">
      <div class="ev-portrait"><img src="${charArt(sp.id, 'card')}" alt="${esc(sp.name)}" /></div>
      <div class="ev-text">
        <p>${esc(ev.text)}</p>
        ${ev.line ? `<div class="ev-line">${face(sp.id, 'ev-line-face')}<b>${esc(sp.name)}</b><p>「${esc(ev.line)}」</p></div>` : ''}
        ${ev.fact ? `<details class="ev-fact"><summary>史实 · ${esc(ev.fact.date)} · ${esc(ev.fact.title)}</summary><p>${esc(ev.fact.text)}</p>${ev.fact.note ? `<p class="muted">${esc(ev.fact.note)}</p>` : ''}${ev.fact.sources.length ? `<p class="srcs">${ev.fact.sources.map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)} ↗</a>`).join('')}</p>` : ''}<p class="muted">角色场景与选择为同人演绎。</p></details>` : ''}
      </div>
    </div>
    <div class="ev-choices">
      ${ev.choices.map((c, i) => `<button class="choice" data-choice="${i}" ${c.disabled ? 'disabled' : ''}><b>${esc(c.label)}</b>${c.hint ? `<small>${esc(c.hint)}${c.disabled ? ' · 灵感不足' : ''}</small>` : ''}</button>`).join('')}
    </div>
  </div>`;
}
function eventResultHtml(ev, res) {
  const unlocked = { unlock_skills: '技能', unlock_races: '比赛', unlock_market: '数据集市', service_launch: '模型服务' };
  return `
  <div class="ev ev--result">
    <div class="ev-head"><span class="ev-tag">${esc(ev.tag)}</span><h3>${esc(res.title)}</h3></div>
    <p class="ev-pick">你选择了：<b>${esc(res.choice)}</b>${res.outcome === 'win' ? ' · <em class="ok">成功！</em>' : res.outcome === 'lose' ? ' · <em class="ng">失败……</em>' : ''}</p>
    ${res.result ? `<p class="ev-result">${esc(res.result)}</p>` : ''}
    <div class="deltas">${changeChips(res.changes)}</div>
    <button class="btn btn--primary btn--xl" data-next>继续</button>
  </div>`;
}

async function runQueue() {
  while (S && S.status === 'playing' && S.queue.length) {
    const ev = E.currentEvent(S);
    const root = openOverlay(eventHtml(ev), `overlay--event overlay--${ev.kind}`);
    const btn = await waitClick(root, '[data-choice]');
    const res = E.resolveEvent(S, Number(btn.dataset.choice));
    save();
    if (ev.kind !== 'random' && /解锁/.test(ev.choices[Number(btn.dataset.choice)].hint)) ui.lineIndex = 0;
    render();
    floatStatChanges(res.changes);
    root.querySelector('.sheet').innerHTML = eventResultHtml(ev, res);
    root.querySelector('[data-next]').focus({ preventScroll: true });
    await waitClick(root, '[data-next]');
  }
  closeOverlay();
}

// ---------- 主流程 ----------
async function act(fn, kind) {
  if (ui.busy) return;
  ui.busy = true;
  try {
    const res = fn();
    ui.mode = 'home';
    ui.emotion = kind === 'outing' ? 'outing' : kind === 'train' ? (res.success ? 'happy' : 'worried') : 'neutral';
    ui.lineIndex = 0;
    save();
    render();
    if (kind === 'train') await showFeedback(res.success ? `${D.TRAININGS[res.type].label}训练成功！${res.levelUp ? ` 升到 Lv${E.trainingLevel(S, res.type) + 1}` : ''}` : '训练失败……', res.changes, res.success ? 'good' : 'bad');
    if (kind === 'rest') await showFeedback('好好休息了一下', res.changes);
    if (kind === 'outing') await showFeedback(res.camp ? '在海边散了散步' : '一起外出散心', res.changes);
    if (kind === 'debug') await showFeedback('调试完成', res.changes);
    await runQueue();
    ui.emotion = 'neutral';
    if (S.status === 'ended') return finishCareer();
    render();
  } catch (err) {
    toast(err.message || String(err));
  } finally {
    ui.busy = false;
  }
}

function startCareer(id) {
  S = E.createCareer(id, (Date.now() ^ (Math.random() * 1e9)) >>> 0);
  S.uiSeen = {};
  ui.screen = 'home'; ui.mode = 'home'; ui.emotion = 'neutral'; ui.lineIndex = 0;
  save();
  render();
  runQueue().then(render);
}

function finishCareer() {
  const hof = load(HOF_KEY) || [];
  if (!S.hofSaved) {
    hof.unshift(E.hallOfFameEntry(S));
    store(HOF_KEY, hof.slice(0, 50));
    S.hofSaved = true;
  }
  save();
  ui.screen = 'result';
  render();
}

// ---------- 比赛 ----------
function racePreviewHtml(p) {
  const race = p.race;
  const ratio = p.power / (p.rival * (race.diff || 1));
  const verdict = ratio >= 1.18 ? ['有望夺冠', 'great'] : ratio >= 1.02 ? ['有望进前三', 'good'] : ratio >= 0.9 ? ['势均力敌', 'mid'] : ['会是一场苦战', 'hard'];
  return `
  <div class="race-pre" style="--bg:url('${race.id === 'gala' ? BG.gala : BG.arena}')">
    <div class="race-pre__card">
      <span class="ev-tag">${race.tier}${race.goal ? ' · 目标评测' : ' · 公开赛'}</span>
      <h3>${esc(race.name)}</h3>
      ${race.desc ? `<p>${esc(race.desc)}</p>` : ''}
      <div class="weights">${Object.entries(race.weights).map(([k, w]) => `<span style="--c:${D.STAT_INFO[k].color};--w:${w}">${D.STAT_INFO[k].label} ${Math.round(w * 100)}%</span>`).join('')}</div>
      <div class="race-eval eval--${verdict[1]}"><span>实力评估</span><b>${verdict[0]}</b></div>
      ${p.skills.length ? `<p class="race-skills">会发动的技能：${p.skills.map(n => `<i>${esc(n)}</i>`).join('')}</p>` : '<p class="race-skills muted">还没有能在这场比赛发动的技能。</p>'}
      ${p.streakWarning ? '<p class="warn">已经连续比赛两周了，再比赛心情可能会下降。</p>' : ''}
      ${!race.goal ? '<p class="muted">参赛会占用本周行动，体力 -15。名次越高，灵感和用户越多。</p>' : ''}
      <div class="race-pre__actions">
        ${race.goal ? '' : '<button class="btn btn--ghost" data-race="cancel">先不报名</button>'}
        <button class="btn btn--primary btn--xl" data-race="go">${race.goal ? '出发！' : '报名参赛'}</button>
      </div>
    </div>
  </div>`;
}

function raceRunHtml(res) {
  const runners = [...res.field].sort((a, b) => (b.isPlayer - a.isPlayer) || a.id.localeCompare(b.id));
  return `
  <div class="race-run" style="--bg:url('${res.race.id === 'gala' ? BG.gala : BG.arena}')">
    <div class="race-run__head"><span class="ev-tag">${res.race.tier}</span><b>${esc(res.race.name)}</b><button class="btn btn--ghost btn--sm" data-race="skip">跳过</button></div>
    <p class="commentary" id="commentary">各就各位……</p>
    <div class="lanes">
      ${runners.map(r => `<div class="lane ${r.isPlayer ? 'is-me' : ''}" data-runner="${r.id}"><span class="lane-rank"></span><div class="track"><span class="runner">${face(r.id)}</span></div><span class="lane-name">${esc(r.name)}</span></div>`).join('')}
    </div>
  </div>`;
}

function playRace(root, res) {
  return new Promise(resolve => {
    const field = res.field;
    const max = field[0].score;
    const min = field.at(-1).score;
    const spread = Math.max(1, max - min);
    let seed = res.field.reduce((a, r) => a + r.score, 0);
    const rnd = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
    const plan = field.map(r => ({
      r, end: r.rank === 1 ? 1 : 0.62 + 0.36 * (r.score - min) / spread - (r.rank === 2 ? 0.01 : 0),
      wob: (rnd() - 0.5) * 0.18, phase: rnd() * Math.PI * 2,
      el: root.querySelector(`[data-runner="${r.id}"] .runner`), lane: root.querySelector(`[data-runner="${r.id}"]`),
    }));
    const me = field.find(r => r.isPlayer);
    const comm = root.querySelector('#commentary');
    const lines = [
      [0.02, '起跑！所有模型同时开始作答！'],
      [0.3, () => `前段：${leader(0.3)} 暂时领先！`],
      ...res.skills.map((n, i) => [0.42 + i * (0.3 / Math.max(1, res.skills.length)), `${me.name} 发动了「${n}」！`, true]),
      [0.82, '最后冲刺！'],
    ];
    function posAt(p, t) {
      const ease = 1 - Math.pow(1 - t, 2.2);
      return Math.max(0, p.end * ease + p.wob * Math.sin(t * Math.PI) * (1 - t) * 1.6 + 0.02 * Math.sin(t * 9 + p.phase) * (1 - t));
    }
    function leader(t) { return plan.reduce((a, p) => (posAt(p, t) > posAt(a, t) ? p : a)).r.name; }
    const duration = 5200;
    const t0 = performance.now();
    let li = 0;
    let stopped = false;
    function frame(now) {
      if (stopped) return;
      const t = Math.min(1, (now - t0) / duration);
      for (const p of plan) p.el.style.setProperty('--x', posAt(p, t).toFixed(4));
      while (li < lines.length && t >= lines[li][0]) {
        const [, text, skill] = lines[li++];
        comm.textContent = typeof text === 'function' ? text() : text;
        comm.classList.toggle('is-skill', !!skill);
        if (skill) root.querySelector('.lane.is-me')?.classList.add('flash');
        setTimeout(() => root.querySelector('.lane.is-me')?.classList.remove('flash'), 700);
      }
      if (t < 1) requestAnimationFrame(frame); else end();
    }
    function end() {
      if (stopped) return;
      stopped = true;
      for (const p of plan) {
        p.el.style.setProperty('--x', p.end.toFixed(4));
        p.lane.querySelector('.lane-rank').textContent = p.r.rank;
        p.lane.classList.add(`rank-${p.r.rank}`);
      }
      comm.textContent = `冲线！第一名是 ${field[0].name}！`;
      setTimeout(resolve, 900);
    }
    root.querySelector('[data-race="skip"]').addEventListener('click', end, { once: true });
    // 后台标签页不会触发动画帧，到时间后直接冲线。
    setTimeout(end, duration + 1200);
    requestAnimationFrame(frame);
  });
}

function raceResultHtml(res) {
  const rank = res.rank;
  const race = res.race;
  const goalText = race.goal ? (res.goalMet ? (race.soft ? (rank === 1 ? '年度第一！' : '年度大赏落幕') : '目标达成！') : `目标是前 ${race.goal} 名……没能达成`) : '';
  return `
  <div class="race-res ${rank === 1 ? 'is-win' : ''}" style="--bg:url('${race.id === 'gala' ? BG.gala : BG.arena}')">
    <div class="race-res__card">
      <div class="race-res__hero">
        <img src="${charArt(S.characterId, 'card', rank <= 3 ? 'happy' : 'worried')}" alt="" />
        <div><span class="ev-tag">${esc(race.name)}</span><strong class="place">第 <b>${rank}</b> 名</strong>${goalText ? `<span class="goal-msg ${res.goalMet ? 'ok' : 'ng'}">${goalText}</span>` : ''}</div>
      </div>
      <ol class="podium">${res.field.map(r => `<li class="${r.isPlayer ? 'is-me' : ''}"><span>${r.rank}</span>${face(r.id)}<b>${esc(r.name)}</b><small>${r.score}</small></li>`).join('')}</ol>
      ${res.changes.length ? `<div class="deltas">${changeChips(res.changes)}</div>` : ''}
      <div class="race-pre__actions">
        ${res.canRetry ? `<button class="btn btn--ghost" data-race="giveup">接受结果（育成结束）</button><button class="btn btn--primary btn--xl" data-race="retry">使用再挑战券（剩 ${S.retries} 张）</button>`
          : `<button class="btn btn--primary btn--xl" data-race="done">${res.ended || S.status === 'ended' ? '查看育成结果' : '继续'}</button>`}
      </div>
    </div>
  </div>`;
}

async function openRace(raceId) {
  if (ui.busy) return;
  ui.busy = true;
  try {
    const p = E.racePreview(S, raceId);
    let root = openOverlay(racePreviewHtml(p), 'overlay--race');
    const go = await waitClick(root, '[data-race]');
    if (go.dataset.race === 'cancel') { closeOverlay(); return; }
    let res = E.doRace(S, raceId);
    save();
    for (;;) {
      root = openOverlay(raceRunHtml(res), 'overlay--race');
      await playRace(root, res);
      root = openOverlay(raceResultHtml(res), 'overlay--race');
      const b = await waitClick(root, '[data-race]');
      if (b.dataset.race === 'retry') { res = E.retryRace(S); save(); continue; }
      if (b.dataset.race === 'giveup') { E.giveUpRace(S); save(); }
      break;
    }
    closeOverlay();
    ui.mode = 'home'; ui.lineIndex = 0;
    if (S.status === 'ended') return finishCareer();
    render();
    await runQueue();
    if (S.status === 'ended') return finishCareer();
    render();
  } catch (err) {
    toast(err.message || String(err));
  } finally {
    ui.busy = false;
  }
}

// ---------- 技能 / 集市 / 菜单 ----------
function markSeen(key) { S.uiSeen = { ...(S.uiSeen || {}), [key]: true }; save(); }
function skillsHtml() {
  return `
  <div class="shop">
    <div class="shop-head"><div><span class="ev-tag">技能</span><h3>学习技能</h3><p>技能会在比赛中自动发动，同一场比赛的加成最多 +15%。</p></div>
      <span class="res big">${icon('skills')}<b>${S.inspiration}</b><small>灵感</small></span><button class="icon-btn" data-close aria-label="关闭">${icon('close')}</button></div>
    <ul class="shop-list">
      ${D.SKILLS.map(sk => {
        const owned = S.skills.includes(sk.id);
        const locked = sk.fromWeek && S.week < sk.fromWeek;
        const poor = sk.cost > S.inspiration;
        return `<li class="${owned ? 'is-owned' : ''}"><div><b>${esc(sk.name)}</b><small>${esc(sk.desc)}</small></div>
          ${owned ? `<span class="owned">${icon('check')}已学会</span>` : `<button class="btn btn--buy" data-skill="${sk.id}" ${locked || poor ? 'disabled' : ''}>${locked ? `第 ${sk.fromWeek} 周` : `${icon('skills')}${sk.cost}`}</button>`}</li>`;
      }).join('')}
    </ul>
  </div>`;
}
function marketHtml() {
  return `
  <div class="shop">
    <div class="shop-head"><div><span class="ev-tag">数据集市</span><h3>昇腾的补给车</h3><p>逛集市不占用本周行动。每件商品本周限购一次。</p></div>
      <span class="res big">${icon('skills')}<b>${S.inspiration}</b><small>灵感</small></span><button class="icon-btn" data-close aria-label="关闭">${icon('close')}</button></div>
    <div class="market-npc">${face('ascend')}<p>「${esc(D.SUPPORT_LINES.ascend)}」</p></div>
    <ul class="shop-list">
      ${S.marketStock.map(id => {
        const it = D.MARKET_ITEM_BY_ID[id];
        const bought = S.marketBought.includes(id);
        return `<li class="${bought ? 'is-owned' : ''}"><div><b>${esc(it.name)}</b><small>${esc(it.desc)}</small></div>
          ${bought ? `<span class="owned">${icon('check')}已购买</span>` : `<button class="btn btn--buy" data-item="${id}" ${it.cost > S.inspiration ? 'disabled' : ''}>${icon('skills')}${it.cost}</button>`}</li>`;
      }).join('')}
    </ul>
  </div>`;
}
function openSkills() {
  markSeen('skills');
  const root = openOverlay(skillsHtml(), 'overlay--shop');
  root.addEventListener('click', ev => {
    if (ev.target.closest('[data-close]') || ev.target === root) { closeOverlay(); render(); return; }
    const b = ev.target.closest('[data-skill]');
    if (!b || b.disabled) return;
    try { const sk = E.learnSkill(S, b.dataset.skill); save(); toast(`学会了「${sk.name}」！`); root.querySelector('.sheet').innerHTML = skillsHtml(); render(); } catch (err) { toast(err.message); }
  });
}
function openMarket() {
  markSeen('market');
  const root = openOverlay(marketHtml(), 'overlay--shop');
  root.addEventListener('click', ev => {
    if (ev.target.closest('[data-close]') || ev.target === root) { closeOverlay(); render(); return; }
    const b = ev.target.closest('[data-item]');
    if (!b || b.disabled) return;
    try {
      const changes = E.buyItem(S, b.dataset.item);
      save();
      toast(`购买了「${D.MARKET_ITEM_BY_ID[b.dataset.item].name}」`);
      root.querySelector('.sheet').innerHTML = marketHtml();
      render();
      floatStatChanges(changes);
    } catch (err) { toast(err.message); }
  });
}
function openMenu() {
  const m = E.modelOf(S);
  const root = openOverlay(`
  <div class="menu">
    <div class="shop-head"><div><span class="ev-tag">菜单</span><h3>${esc(m.name)} 的育成</h3><p>进度会自动保存在这个浏览器里。</p></div><button class="icon-btn" data-close aria-label="关闭">${icon('close')}</button></div>
    <div class="menu-grid">
      <div class="menu-box"><b>伙伴羁绊</b>${Object.entries(S.supports).map(([type, npc]) => `<div class="bond">${face(npc, S.bonds[npc] >= D.FRIENDSHIP_BOND ? 'is-friend' : '')}<span>${esc(D.characterById(npc).name)}<small>${D.STAT_INFO[type].label}训练</small></span><div class="bar"><i style="width:${S.bonds[npc]}%"></i></div></div>`).join('')}<p class="muted">羁绊到 80 后，和她在擅长的训练里一起练会触发友情训练（+30%）。</p></div>
      <div class="menu-box"><b>育成记录</b><ol class="log">${S.log.slice(-12).reverse().map(l => `<li><span>第 ${l.week} 周</span>${esc(l.text)}</li>`).join('') || '<li>还没有记录。</li>'}</ol></div>
    </div>
    <div class="menu-actions">
      <button class="btn btn--ghost" data-menu="title">回到标题</button>
      <button class="btn btn--ghost" data-menu="hof">名人堂</button>
      <button class="btn btn--danger" data-menu="abandon">放弃本次育成</button>
    </div>
    <p class="muted">再挑战券：${S.retries} 张 · 已学技能 ${S.skills.length} 个</p>
  </div>`, 'overlay--shop');
  root.addEventListener('click', ev => {
    if (ev.target.closest('[data-close]') || ev.target === root) return closeOverlay();
    const b = ev.target.closest('[data-menu]');
    if (!b) return;
    if (b.dataset.menu === 'title') { closeOverlay(); ui.screen = 'title'; render(); }
    if (b.dataset.menu === 'hof') openHof();
    if (b.dataset.menu === 'abandon') {
      if (b.dataset.confirm) { clearSave(); S = null; closeOverlay(); ui.screen = 'title'; render(); toast('已放弃本次育成'); }
      else { b.dataset.confirm = '1'; b.textContent = '再点一次确认放弃'; }
    }
  });
}
function openHof() {
  const hof = load(HOF_KEY) || [];
  const root = openOverlay(`
  <div class="menu">
    <div class="shop-head"><div><span class="ev-tag">名人堂</span><h3>历代育成</h3><p>最近 50 次育成的结果。</p></div><button class="icon-btn" data-close aria-label="关闭">${icon('close')}</button></div>
    <ul class="hof">${hof.map(h => `<li>${face(h.characterId)}<div><b>${esc(h.name)}</b><small>${new Date(h.at).toLocaleDateString('zh-CN')} · ${h.reason === 'complete' ? `大赏第 ${h.galaRank} 名` : '中途结束'} · 冠军 ${h.wins} 次</small></div><span class="rank rank--${h.rank}">${h.rank}</span><em>${h.total}</em></li>`).join('') || '<li class="muted">还没有完成的育成。</li>'}</ul>
  </div>`, 'overlay--shop');
  root.addEventListener('click', ev => { if (ev.target.closest('[data-close]') || ev.target === root) closeOverlay(); });
}

// ---------- 结算 ----------
function renderResult() {
  const r = S.result;
  const m = E.modelOf(S);
  const rt = r.rating;
  app.className = 'app app--result';
  app.innerHTML = `
  <section class="result-screen" style="--bg:url('${BG.gala}')">
    <div class="result-card">
      <div class="result-hero">
        <img src="${charArt(S.characterId, 'stage', r.reason === 'complete' ? 'happy' : 'worried')}" alt="${esc(m.name)}" />
        <div class="result-rank"><span class="eyebrow">${r.reason === 'complete' ? 'CAREER COMPLETE' : 'CAREER OVER'}</span><span class="rank rank--${r.rank} rank--big">${r.rank}</span><b>评价分 ${rt.total}</b>
          <small>${r.reason === 'complete' ? `年度模型大赏 第 ${r.galaRank} 名` : `第 ${r.week} 周 · 目标评测未达成`}</small></div>
      </div>
      <blockquote>「${esc(r.ending)}」<cite>—— ${esc(m.name)}</cite></blockquote>
      <div class="result-stats">${D.STATS.map(k => `<div class="stat" style="--c:${D.STAT_INFO[k].color}"><span class="stat-label">${D.STAT_INFO[k].label}</span><span class="stat-grade">${E.statGrade(S.stats[k])}</span><b class="stat-val">${S.stats[k]}</b></div>`).join('')}</div>
      <ul class="breakdown">
        <li><span>能力合计</span><b>${rt.statSum}</b></li><li><span>比赛名次</span><b>${rt.racePts}</b></li><li><span>目标达成</span><b>${rt.goals}</b></li>
        <li><span>技能 ×${S.skills.length}</span><b>${rt.skills}</b></li><li><span>用户 ${fmtUsers(S.users)}</span><b>${rt.users}</b></li>${S.service ? `<li><span>口碑 ${S.reputation}</span><b>${rt.rep}</b></li>` : ''}
      </ul>
      <div class="race-log">${S.races.map(x => `<span class="${x.rank === 1 ? 'win' : ''}">${esc(x.name)} · 第 ${x.rank} 名</span>`).join('')}</div>
      <div class="race-pre__actions">
        <button class="btn btn--ghost" data-act="hof">名人堂</button>
        <button class="btn btn--primary btn--xl" data-act="new">再育成一次</button>
      </div>
    </div>
  </section>`;
}

// ---------- 事件绑定 ----------
app.addEventListener('click', ev => {
  const el = ev.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const a = el.dataset.act;
  const id = el.dataset.id;
  switch (a) {
    case 'continue': {
      const saved = load(SAVE_KEY);
      if (!saved || !E.validateCareer(saved)) { toast('存档无法读取，请开始新的育成'); return; }
      S = saved; ui.screen = 'home'; ui.mode = 'home'; render(); runQueue().then(() => { if (S.status === 'ended') finishCareer(); else render(); });
      break;
    }
    case 'new': ui.screen = 'select'; ui.selectId = null; render(); window.scrollTo(0, 0); break;
    case 'hof': openHof(); break;
    case 'to-title': ui.screen = 'title'; render(); break;
    case 'pick': ui.selectId = id; render(); app.querySelector('.select-detail')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); break;
    case 'unpick': ui.selectId = null; render(); break;
    case 'start': startCareer(id); break;
    case 'talk': ui.lineIndex += 1; app.querySelector('.bubble p').textContent = ui.mode === 'train' ? trainLine() : homeLine(); break;
    case 'open-train': ui.mode = 'train'; ui.trainSel = ui.trainSel || bestTraining(); render(); break;
    case 'close-train': ui.mode = 'home'; render(); break;
    case 'pick-train':
      if (ui.trainSel === id && !ui.busy) act(() => E.doTraining(S, id), 'train');
      else { ui.trainSel = id; render(); }
      break;
    case 'do-train': act(() => E.doTraining(S, id), 'train'); break;
    case 'rest': act(() => E.doRest(S), 'rest'); break;
    case 'outing': act(() => E.doOuting(S), 'outing'); break;
    case 'debug': act(() => E.doDebug(S), 'debug'); break;
    case 'race': markSeen('races'); openRace(id); break;
    case 'skills': openSkills(); break;
    case 'market': openMarket(); break;
    case 'menu': openMenu(); break;
    default: break;
  }
});
document.addEventListener('keydown', ev => {
  if (ev.key === 'Escape' && overlayRoot.querySelector('.overlay--shop')) { closeOverlay(); render(); }
});

function bestTraining() {
  let best = 'creative';
  let score = -1;
  for (const k of D.STATS) {
    const p = E.trainingPreview(S, k);
    const v = p.supporters.length * 10 + (E.modelOf(S).focus.includes(k) ? 5 : 0);
    if (v > score) { score = v; best = k; }
  }
  return best;
}

// 启动：有进行中的存档就直接回到育成。
(function boot() {
  const saved = load(SAVE_KEY);
  if (saved && E.validateCareer(saved) && saved.status === 'playing') {
    S = saved;
    ui.screen = 'home';
    render();
    runQueue().then(() => { if (S.status === 'ended') finishCareer(); else render(); });
    return;
  }
  render();
})();
