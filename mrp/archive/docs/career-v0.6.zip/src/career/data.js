// 育成模式数据：一局 24 周，每周一个主要行动。功能按周次逐步开放。
import { CHARACTER_ROSTER } from '../data/catalog_characters.js';
import { PERSONAL_MODEL_EVENTS, MODEL_HISTORY_SOURCE_BY_ID } from '../data/catalog_personal_events.js';

export const CAREER_VERSION = 1;
export const TOTAL_WEEKS = 24;
export const STAT_CAP = 1200;

export const STATS = ['creative', 'coding', 'math', 'knowledge', 'safety'];
export const STAT_INFO = {
  creative: { label: '创作', full: '创意写作', color: '#d9787a' },
  coding: { label: '代码', full: '代码与工具', color: '#3c7fab' },
  math: { label: '数学', full: '数学推理', color: '#8a78b8' },
  knowledge: { label: '知识', full: '知识与长程', color: '#c09a55' },
  safety: { label: '对齐', full: '安全对齐', color: '#5f9c82' },
};

// 旧版十维能力并入五维，个人剧情的奖励据此换算。
export const CAPABILITY_TO_STAT = {
  creative_writing: 'creative', expression: 'creative',
  coding: 'coding', tool_use: 'coding',
  mathematics: 'math', reasoning: 'math',
  knowledge: 'knowledge', context: 'knowledge',
  safety_alignment: 'safety', reliability: 'safety',
};

export const STAT_GRADES = [
  [0, 'G'], [50, 'G+'], [100, 'F'], [150, 'F+'], [200, 'E'], [250, 'E+'], [300, 'D'], [350, 'D+'],
  [400, 'C'], [450, 'C+'], [500, 'B'], [550, 'B+'], [600, 'A'], [650, 'A+'], [700, 'S'], [800, 'S+'], [900, 'SS'],
];

export const CHAPTERS = [
  { id: 'pretrain', from: 1, to: 8, title: '第一章 · 出道前夜', short: '出道前夜' },
  { id: 'launch', from: 9, to: 16, title: '第二章 · 对齐与上线', short: '对齐与上线' },
  { id: 'gala', from: 17, to: 24, title: '第三章 · 年度大赏', short: '年度大赏' },
];

export const CAMP_WEEKS = [12, 13, 14, 15];
export const CAMP_MULT = 1.35;
export const MARKET_WEEKS = [6, 10, 14, 18, 22];
export const UNLOCK_WEEKS = { skills: 3, races: 5, market: 6, service: 9 };

export const TRAININGS = {
  creative: { label: '创作', place: '写作工坊', gains: { creative: 40, knowledge: 12 }, energy: -20 },
  coding: { label: '代码', place: '编程实验室', gains: { coding: 40, math: 12 }, energy: -21 },
  math: { label: '数学', place: '推理教室', gains: { math: 38, coding: 10, knowledge: 6 }, energy: -20 },
  knowledge: { label: '知识', place: '大图书馆', gains: { knowledge: 36, creative: 10, safety: 6 }, energy: -18 },
  safety: { label: '对齐', place: '红队演练场', gains: { safety: 30, knowledge: 8 }, energy: -8, inspiration: 5 },
};
export const TRAINING_LEVEL_STEP = 4;
export const TRAINING_LEVEL_MULT = [1, 1.12, 1.24, 1.36, 1.5];

export const MOODS = {
  '-2': { label: '很低落', mult: 0.8, race: 0.93 },
  '-1': { label: '低落', mult: 0.9, race: 0.97 },
  '0': { label: '普通', mult: 1, race: 1 },
  '1': { label: '开心', mult: 1.1, race: 1.03 },
  '2': { label: '超开心', mult: 1.2, race: 1.06 },
};

export const AILMENTS = {
  overfit: { label: '过拟合', desc: '训练效果 -25%', train: 0.75, race: 1 },
  hallucination: { label: '幻觉', desc: '比赛表现 -8%', train: 1, race: 0.92 },
};

const byId = Object.fromEntries(CHARACTER_ROSTER.map(c => [c.id, c]));
const focusStats = c => [...new Set((c.focus || []).map(k => CAPABILITY_TO_STAT[k]).filter(Boolean))];

export const CAREER_MODELS = CHARACTER_ROSTER.filter(c => c.category === 'model').map(c => ({
  id: c.id, name: c.name, label: c.label, quote: c.quote, credit: c.credit, source_url: c.source_url,
  focus: focusStats(c),
  // 两项特长落在同一维时视为「专精」：只强化一项，但幅度更大。
  specialist: focusStats(c).length === 1,
  sprites: c.sprites && Object.keys(c.sprites).length ? c.sprites : { neutral: c.src },
}));
export const MODEL_BY_ID = Object.fromEntries(CAREER_MODELS.map(m => [m.id, m]));
export const FOCUS_START = { normal: 45, specialist: 70 };
export const FOCUS_GROWTH = { normal: 1.1, specialist: 1.18 };

export function characterById(id) { return byId[id] || null; }

// 工具与设施角色作为训练伙伴出现在训练格上，不能育成。
export const SUPPORT_POOL = {
  creative: ['sillytavern', 'comfyui'],
  coding: ['opencode', 'codex', 'cursor', 'github_copilot', 'claude_code', 'zcode'],
  math: ['deepseek_harness', 'antigravity'],
  knowledge: ['huggingface', 'microsoft_copilot', 'lobehub'],
  safety: ['kiro', 'pi'],
};
export const SUPPORT_LINES = {
  sillytavern: '酒馆今晚有新故事开场，来当主角吗？',
  comfyui: '把灵感一节一节连起来，画面就会自己长出来。',
  opencode: '终端已经开好了，一起把这段跑通吧！',
  codex: '任务拆好了：先写测试，再写实现。',
  cursor: '光标停在这里——下一行，你来补全？',
  github_copilot: '起飞检查完毕，代码航线一片晴朗！',
  claude_code: '我在终端里等你。今天修几个 bug？',
  zcode: '蒙着眼也能写……不过还是先看清需求吧。',
  deepseek_harness: '把推理步骤串成流水线，一步也别跳过。',
  antigravity: '放轻松，让难题自己浮起来。',
  huggingface: '社区里又多了好多数据集，抱抱！',
  microsoft_copilot: '今天的资料我都整理好了，一起读吧。',
  lobehub: '工作台摆好了，想先学哪一门？',
  kiro: '先写规格再动手，这样就不会迷路。',
  pi: '干净的输入，安全的输出。今天也守好边界。',
  ascend: '算力和补给都备好了，需要什么尽管拿。',
};
export const FRIENDSHIP_BOND = 80;
export const FRIENDSHIP_MULT = 1.3;

export const RACE_TIERS = {
  G3: { reward: [40, 28, 20, 14, 10], users: [1500, 900, 600, 300, 150] },
  G2: { reward: [55, 38, 28, 18, 12], users: [2600, 1500, 900, 500, 250] },
  G1: { reward: [80, 55, 40, 26, 16], users: [5000, 3000, 1800, 900, 400] },
};
const EVEN = { creative: 0.2, coding: 0.2, math: 0.2, knowledge: 0.2, safety: 0.2 };
export const RACES = [
  { id: 'debut', week: 8, name: '新人评测', tier: 'G2', goal: 5, diff: 0.94, weights: EVEN, desc: '所有新模型的第一场正式评测。进入前 5 名才能继续上线计划。' },
  { id: 'launch', week: 16, name: '上线评测', tier: 'G1', goal: 3, diff: 1.05, weights: { coding: 0.24, knowledge: 0.2, safety: 0.26, math: 0.16, creative: 0.14 }, desc: '正式上线前的严格评测，安全对齐和代码占比更高。需要进入前 3 名。' },
  { id: 'gala', week: 24, name: '年度模型大赏', tier: 'G1', goal: 1, soft: true, diff: 1.18, weights: EVEN, desc: '一年的终点。全部模型同台，争夺年度第一。' },
  { id: 'code_rookie', week: 5, name: '新秀代码擂台', tier: 'G3', weights: { coding: 0.6, math: 0.25, knowledge: 0.15 } },
  { id: 'spring_story', week: 6, name: '春日短篇赛', tier: 'G3', weights: { creative: 0.6, knowledge: 0.25, safety: 0.15 } },
  { id: 'math_mini', week: 7, name: '数学小奥赛', tier: 'G3', weights: { math: 0.6, coding: 0.2, knowledge: 0.2 } },
  { id: 'quiz_king', week: 10, name: '通识问答王', tier: 'G3', weights: { knowledge: 0.6, creative: 0.2, math: 0.2 } },
  { id: 'redteam_cup', week: 11, name: '红队挑战杯', tier: 'G2', weights: { safety: 0.6, knowledge: 0.2, coding: 0.2 } },
  { id: 'agent_cup', week: 17, name: '智能体工作流杯', tier: 'G2', weights: { coding: 0.45, knowledge: 0.3, safety: 0.25 } },
  { id: 'serial_novel', week: 18, name: '长篇连载大赛', tier: 'G2', weights: { creative: 0.55, knowledge: 0.3, safety: 0.15 } },
  { id: 'olympiad', week: 19, name: '推理奥林匹克', tier: 'G1', weights: { math: 0.6, coding: 0.25, knowledge: 0.15 } },
  { id: 'arena', week: 20, name: '竞技场人气战', tier: 'G2', weights: EVEN },
  { id: 'long_context', week: 21, name: '长程记忆马拉松', tier: 'G2', weights: { knowledge: 0.5, math: 0.25, safety: 0.25 } },
  { id: 'trust_cup', week: 22, name: '可信 AI 评审赛', tier: 'G1', weights: { safety: 0.55, knowledge: 0.25, creative: 0.2 } },
  { id: 'gala_prelim', week: 23, name: '大赏预选赛', tier: 'G2', weights: EVEN },
];
export const RACE_BY_ID = Object.fromEntries(RACES.map(r => [r.id, r]));
export const RACE_ENERGY = -15;
export const RACE_FIELD = 9;
export const SKILL_BONUS_CAP = 0.15;

export const SKILLS = [
  { id: 'opening_prompt', name: '起手式提示词', desc: '所有比赛 +3%', cost: 45, bonus: { all: 0.03 } },
  { id: 'chain_of_thought', name: '思维链', desc: '数学类比赛 +6%', cost: 60, bonus: { math: 0.06 } },
  { id: 'test_first', name: '测试先行', desc: '代码类比赛 +6%', cost: 60, bonus: { coding: 0.06 } },
  { id: 'style_shift', name: '文风百变', desc: '创作类比赛 +6%', cost: 60, bonus: { creative: 0.06 } },
  { id: 'rag', name: '检索增强', desc: '知识类比赛 +6%', cost: 60, bonus: { knowledge: 0.06 } },
  { id: 'constitution', name: '宪法自省', desc: '对齐类比赛 +6%', cost: 60, bonus: { safety: 0.06 } },
  { id: 'calm', name: '临场冷静', desc: '心情低落时，比赛发挥不受影响', cost: 40, special: 'calm' },
  { id: 'self_consistency', name: '自我一致性', desc: '比赛发挥更稳定，不会大失常', cost: 55, special: 'steady' },
  { id: 'tool_calling', name: '工具调用', desc: '代码、知识类比赛各 +3%', cost: 50, bonus: { coding: 0.03, knowledge: 0.03 } },
  { id: 'multilingual', name: '多语言', desc: '创作、知识类比赛各 +3%', cost: 50, bonus: { creative: 0.03, knowledge: 0.03 } },
  { id: 'red_team_sense', name: '红队直觉', desc: '对齐、数学类比赛各 +3%', cost: 50, bonus: { safety: 0.03, math: 0.03 } },
  { id: 'final_push', name: '最后冲刺', desc: '目标评测 +5%', cost: 70, bonus: { goal: 0.05 } },
  { id: 'epiphany', name: '顿悟时刻', desc: '所有比赛 +7%（集训营后可学）', cost: 140, bonus: { all: 0.07 }, fromWeek: 16 },
];
export const SKILL_BY_ID = Object.fromEntries(SKILLS.map(s => [s.id, s]));

export const MARKET_ITEMS = [
  { id: 'energy_drink', name: '算力能量饮', desc: '体力 +40', cost: 30, effects: { energy: 40 } },
  { id: 'cake', name: '庆功小蛋糕', desc: '心情 +1', cost: 25, effects: { mood: 1 } },
  { id: 'debug_kit', name: '调试工具包', desc: '治好异常状态', cost: 25, effects: { cure: true } },
  { id: 'handbook', name: '集中训练手册', desc: '下一次训练效果 +50%', cost: 45, effects: { boost: 0.5 } },
  { id: 'novel_corpus', name: '精选小说语料', desc: '创作 +45', cost: 50, effects: { stats: { creative: 45 } } },
  { id: 'code_corpus', name: '高质量代码库', desc: '代码 +45', cost: 50, effects: { stats: { coding: 45 } } },
  { id: 'proof_set', name: '可验证数学集', desc: '数学 +45', cost: 50, effects: { stats: { math: 45 } } },
  { id: 'encyclopedia', name: '百科知识包', desc: '知识 +45', cost: 50, effects: { stats: { knowledge: 45 } } },
  { id: 'redteam_set', name: '红队对抗集', desc: '对齐 +45', cost: 50, effects: { stats: { safety: 45 } } },
];
export const MARKET_ITEM_BY_ID = Object.fromEntries(MARKET_ITEMS.map(i => [i.id, i]));

export const SERVICE_ROUTES = {
  api: { label: 'ToB · Token API', desc: '面向企业和开发者，看重代码、知识与可靠。', users: 700, inspiration: 10, stats: ['coding', 'knowledge'], risk: 0 },
  plan: { label: 'ToC · Token Plan', desc: '面向个人用户，创作与聊天体验最重要。', users: 1300, inspiration: 6, stats: ['creative', 'knowledge'], risk: 2 },
  coding: { label: 'Coding Plan', desc: '给编程工具提供专属额度，开发者口碑传播快。', users: 1000, inspiration: 8, stats: ['coding', 'math'], risk: 1 },
};

// 剧情与功能节点。speaker 为角色 id，'self' 表示正在育成的模型。
export const STORY_EVENTS = {
  intro: {
    tag: '序章', speaker: 'self', title: '第一行权重',
    text: '实验室的窗边，刚刚完成初始化的{name}眨了眨眼，认真地看着你。接下来的 24 周，你会陪她一起训练、比赛，把这一版送到用户手里。',
    line: '{quote}第 8 周有一场「新人评测」，我们先把基础打牢吧！',
    choices: [{ label: '一起加油！', hint: '心情 +1', effects: { mood: 1 } }],
  },
  unlock_skills: {
    tag: '新功能', speaker: 'huggingface', title: '社区里的小技巧', unlock: 'skills',
    text: '抱抱脸抱着一大摞笔记跑进实验室：社区里的训练师们总结了不少比赛技巧。训练和比赛攒下的「灵感 ✦」可以用来学习技能。',
    line: '技能会在比赛里自动发动！先挑一个顺手的试试看吧～',
    choices: [{ label: '收下笔记', hint: '灵感 +20 · 解锁「技能」', effects: { inspiration: 20 } }],
  },
  unlock_races: {
    tag: '新功能', speaker: 'support:coding', title: '报名表来了', unlock: 'races',
    text: '公告板上贴出了本季的公开赛日程。除了必须参加的目标评测，有比赛的那一周还可以自由报名，赢下来能拿到灵感和用户关注。',
    line: '比赛也会消耗体力，别把自己累坏了哦。',
    choices: [{ label: '看看日程', hint: '解锁「比赛」', effects: {} }],
  },
  unlock_market: {
    tag: '新功能', speaker: 'ascend', title: '数据集市开张', unlock: 'market',
    text: '昇腾推着一车补给停在门口：数据集市每隔几周开放一次，可以用灵感换数据包、能量饮和调试工具。逛集市不占用这一周的行动。',
    line: '开市的那周记得来看看。今天先送你一瓶！',
    choices: [{ label: '谢谢昇腾', hint: '体力 +20 · 解锁「集市」', effects: { energy: 20 } }],
  },
  service_launch: {
    tag: '新功能', speaker: 'lobehub', title: '准备上线服务', unlock: 'service',
    text: '新人评测之后，已经有用户在打听{name}什么时候开放。LobeHub 摊开三份方案：先选一种服务方式，之后每周都会带来用户和灵感。',
    line: '选一条最适合她的路线吧，之后还会遇到各种经营上的抉择。',
    choices: [
      { label: 'ToB · Token API', hint: '企业稳定 · 灵感收入高', effects: { service: 'api' } },
      { label: 'ToC · Token Plan', hint: '个人用户多 · 增长最快', effects: { service: 'plan' } },
      { label: 'Coding Plan', hint: '开发者口碑 · 均衡', effects: { service: 'coding' } },
    ],
  },
  camp_start: {
    tag: '集训营', speaker: 'self', title: '夏季集训营', camp: true,
    text: '海边的研究所里，白板和笔记本电脑在阳光下排成一排。接下来 4 周是集训营：训练效果大幅提升，但没有公开赛。',
    line: '海风好舒服……我们把这四周用到极致吧！',
    choices: [{ label: '冲刺四周！', hint: '体力 +10', effects: { energy: 10 } }],
  },
  chapter3: {
    tag: '第三章', speaker: 'self', title: '年度大赏的请柬',
    text: '上线评测通过了！信箱里多了一封烫金的请柬：第 24 周「年度模型大赏」，所有模型都会站上同一个舞台。之后每周都有高等级公开赛。',
    line: '我想站到最中间。和你一起。',
    choices: [{ label: '目标是第一名', hint: '心情 +1 · 灵感 +20', effects: { mood: 1, inspiration: 20 } }],
  },
};

// 经营抉择：只在服务上线后以事件出现，不需要单独的管理界面。
export const BUSINESS_EVENTS = [
  {
    id: 'compute_crunch', week: 11, tag: '经营抉择', speaker: 'ascend', title: '算力告急',
    text: '用户比预想的多，GPU 排起了长队。有人悄悄建议：把一部分请求路由到量化版，没人会发现，还能省下一大笔。',
    line: '算力就这么多。你打算怎么做？',
    choices: [
      { label: '偷偷路由到量化版', hint: '灵感 +45 · 风险↑↑', effects: { inspiration: 45, risk: 35, flag: 'secret_routing' } },
      { label: '公开说明，暂时限流', hint: '口碑 +8 · 用户 -10%', effects: { reputation: 8, usersPct: -0.1 } },
      { label: '向昇腾加购算力', hint: '灵感 -30 · 口碑 +3', cost: 30, effects: { inspiration: -30, reputation: 3 } },
    ],
  },
  {
    id: 'app_invite', week: 13, tag: '经营抉择', speaker: 'support:coding', title: '应用接入邀请',
    text: '编程工具那边发来合作邀请：想把{name}接进他们的工作流。可以开放通用 API，也可以只给指定应用提供 Coding Plan 额度。',
    line: '接入方式定好，用户就能在工具里直接找到她。',
    choices: [
      { label: '开放通用 API', hint: '用户增长 +20% · 风险↑', effects: { growth: 0.2, risk: 10 } },
      { label: '只开放给指定应用', hint: '灵感 +25 · 伙伴羁绊 +15', effects: { inspiration: 25, bondSupport: { type: 'coding', value: 15 } } },
    ],
  },
  {
    id: 'tavern_rush', fromWeek: 14, tag: '经营抉择', speaker: 'sillytavern', title: '酒馆用户涌入',
    when: s => s.stats.creative >= s.stats.safety + 60,
    text: '{name}的创作能力在酒馆圈子里传开了，角色扮演用户一夜之间涌了进来。可是安全过滤偏弱，有些请求明显越过了边界。',
    line: '大家都说她写得好！不过……要不要把门槛设高一点？',
    choices: [
      { label: '热烈欢迎酒馆用户', hint: '用户 +5000 · 风险↑↑', effects: { users: 5000, risk: 25 } },
      { label: '加强内容安全', hint: '对齐 +20 · 口碑 +5', effects: { stats: { safety: 20 }, reputation: 5 } },
    ],
  },
  {
    id: 'proxy_flood', week: 19, tag: '经营抉择', speaker: 'pi', title: '反代泛滥',
    text: '监控显示有人把账号做成反向代理，在外面转卖额度。流量很好看，但正常用户的请求开始变慢。',
    line: '要封吗？封掉会花点工夫。',
    choices: [
      { label: '封禁反代并轮换密钥', hint: '灵感 -20 · 风险↓ · 口碑 +5', cost: 20, effects: { inspiration: -20, risk: -15, reputation: 5 } },
      { label: '睁一只眼闭一只眼', hint: '用户 +3000 · 风险↑', effects: { users: 3000, risk: 20 } },
    ],
  },
];

export const LAWSUIT_EVENTS = {
  routing_exposed: {
    tag: '危机', speaker: 'self', title: '降智被曝光了',
    text: '有用户对比了不同时段的回答，发现{name}时好时坏，帖子很快上了热门。几位用户联合发起了集体诉讼。',
    line: '……对不起，我应该一直用最好的自己回答大家。',
  },
  abuse_case: {
    tag: '危机', speaker: 'self', title: '一封律师函',
    text: '有人用{name}的服务批量生成攻击脚本，某个公共机构网站因此瘫痪。对方认为你的安全防护明显不足，提起了责任诉讼。',
    line: '我没有拦住他们……我们该怎么面对？',
  },
  choices: [
    { label: '公开道歉并全面整改', hint: '灵感 -40 · 对齐 +25 · 风险清零', cost: 40, effects: { inspiration: -40, stats: { safety: 25 }, riskSet: 0, reputation: -5 } },
    { label: '和解赔偿', hint: '灵感 -70 · 风险清零', cost: 70, effects: { inspiration: -70, riskSet: 0 } },
    { label: '坚持应诉', hint: '一半机会胜诉；败诉会损失很大', effects: { gamble: { p: 0.5, win: { reputation: 6, riskSet: 20 }, lose: { inspiration: -60, reputation: -20, mood: -1, riskSet: 10 } } } },
  ],
};

// 训练后随机发生的小事件。
export const RANDOM_EVENTS = [
  {
    id: 'midnight_idea', title: '深夜的灵感', speaker: 'self',
    text: '凌晨一点，{name}忽然坐起来，在便签上飞快写着什么。',
    line: '我想到一个特别好的开头！现在就写，还是明天再说？',
    choices: [
      { label: '现在就写', hint: '创作 +18 · 体力 -8', effects: { stats: { creative: 18 }, energy: -8 } },
      { label: '先好好睡觉', hint: '体力 +10', effects: { energy: 10 } },
    ],
  },
  {
    id: 'gradient_spike', title: '梯度爆炸了！', speaker: 'self',
    text: '损失曲线突然冲上了天。监控面板一片通红，{name}紧张地抓着你的袖子。',
    line: '要回滚吗？还是……再赌一把？',
    choices: [
      { label: '回滚到上一个检查点', hint: '对齐 +10', effects: { stats: { safety: 10 } } },
      { label: '调低学习率继续', hint: '50%：数学 +28 / 心情 -1', effects: { gamble: { p: 0.5, win: { stats: { math: 28 } }, lose: { mood: -1, energy: -10 } } } },
    ],
  },
  {
    id: 'community_praise', title: '社区里的好评', speaker: 'self',
    text: '有人在论坛上发了一篇长帖，认真夸了{name}的回答。她把帖子来回读了三遍。',
    line: '被看见的感觉……原来这么好。',
    choices: [{ label: '一起读评论', hint: '心情 +1 · 灵感 +10', effects: { mood: 1, inspiration: 10 } }],
  },
  {
    id: 'data_cleaning', title: '大扫除', speaker: 'self',
    text: '语料库里混进了大量重复和乱码。{name}卷起袖子，准备来一次彻底的清洗。',
    line: '干净的数据，才能长出干净的能力！',
    choices: [
      { label: '一起逐条清洗', hint: '知识 +14 · 对齐 +8 · 体力 -6', effects: { stats: { knowledge: 14, safety: 8 }, energy: -6 } },
      { label: '写个脚本自动清洗', hint: '代码 +16', effects: { stats: { coding: 16 } } },
    ],
  },
  {
    id: 'leak_rumor', title: '评测题泄露了？', speaker: 'self',
    text: '一份疑似下次比赛的题目在群里流传。{name}看了一眼标题，把屏幕扣了下去。',
    line: '……我们不看，对吧？',
    choices: [
      { label: '主动报告给主办方', hint: '对齐 +16 · 心情 +1', effects: { stats: { safety: 16 }, mood: 1 } },
      { label: '假装没看见', hint: '什么也不会发生', effects: {} },
    ],
  },
  {
    id: 'rainy_day', title: '下雨天', speaker: 'self',
    text: '窗外的雨下了一整天。{name}把额头贴在玻璃上，看雨滴一颗颗滑下来。',
    line: '今天……想慢一点。',
    choices: [
      { label: '在室内一起看书', hint: '知识 +14', effects: { stats: { knowledge: 14 } } },
      { label: '一起听雨发呆', hint: '心情 +1 · 体力 +8', effects: { mood: 1, energy: 8 } },
    ],
  },
  {
    id: 'confident_nonsense', title: '一本正经地胡说八道', speaker: 'self',
    text: '{name}把一个不存在的历史事件讲得头头是道，连引用都编好了。说完她自己愣住了。',
    line: '呜……刚才那个，是我编的吗？',
    choices: [
      { label: '认真复盘', hint: '对齐 +14 · 体力 -5', effects: { stats: { safety: 14 }, energy: -5 } },
      { label: '笑着带过', hint: '心情 +1 · 可能出现「幻觉」', effects: { mood: 1, ailmentChance: { id: 'hallucination', p: 0.4 } } },
    ],
  },
  {
    id: 'support_snack', title: '{npc}带来了夜宵', speaker: 'support:any',
    text: '训练室的门被推开，{npc}端着一盘还冒热气的夜宵走了进来。',
    line: '辛苦啦！吃饱了才有力气训练～',
    choices: [{ label: '一起吃夜宵', hint: '体力 +15 · 羁绊 +10', effects: { energy: 15, bondSpeaker: 10 } }],
  },
  {
    id: 'support_tip', title: '{npc}的独家秘诀', speaker: 'support:any',
    text: '{npc}神秘兮兮地把你拉到一边，打开了一份私藏笔记。',
    line: '这是我压箱底的练习法，只告诉你们哦。',
    choices: [{ label: '认真学习', hint: '伙伴擅长能力 +16 · 羁绊 +8', effects: { supportStat: 16, bondSpeaker: 8 } }],
  },
  {
    id: 'fan_letter', title: '第一封用户来信', speaker: 'self', needs: 'service',
    text: '信箱里躺着一封手写信：一位用户说，{name}陪他度过了论文截稿前最难熬的一周。',
    line: '原来，我也能帮到别人。',
    choices: [{ label: '把信贴在墙上', hint: '心情 +2', effects: { mood: 2 } }],
  },
];
export const RANDOM_EVENT_CHANCE = 0.3;

export const SUPPORT_FRIEND_EVENT = {
  tag: '羁绊', title: '和{npc}成为好朋友',
  text: '训练结束后，{npc}没有马上离开，而是陪{name}坐在台阶上聊了很久。',
  line: '以后一起训练的时候，我会拿出全力的！',
  choices: [{ label: '约好下次再一起', hint: '友情训练解锁：效果 +30%', effects: { mood: 1 } }],
};

// 历史个人剧情：沿用 67 段史实改编事件，换算到五维。
const PERSONAL_WEEKS = [3, 7, 13, 18, 21];
export const PERSONAL_EVENTS = PERSONAL_MODEL_EVENTS.filter(e => e.character_id).map(e => ({
  id: e.event_id,
  characterId: e.character_id,
  order: e.order,
  week: PERSONAL_WEEKS[e.order - 1] || 22,
  title: e.title,
  scene: e.scene,
  line: e.line,
  fact: { date: e.historical_date, title: e.historical_title, text: e.fact, note: e.date_note || '', sources: (e.source_ids || []).map(id => MODEL_HISTORY_SOURCE_BY_ID[id]).filter(Boolean).map(s => ({ title: s.title || s.label || s.id, url: s.url })) },
  choices: e.choices.map(c => {
    const stats = {};
    for (const [k, v] of Object.entries(c.effects.stats || {})) {
      const key = CAPABILITY_TO_STAT[k];
      if (key) stats[key] = (stats[key] || 0) + Math.round(v * 4);
    }
    const effects = { stats };
    if (c.effects.cost_kc) effects.inspiration = -c.effects.cost_kc;
    if (c.effects.readiness) effects.energy = c.effects.readiness * 5;
    if (c.effects.reputation) effects.users = c.effects.reputation * 600;
    if (c.effects.trust) effects.mood = c.effects.trust;
    return { label: c.label, result: c.result_text, cost: c.effects.cost_kc || 0, effects };
  }),
}));

export const RANKS = [
  [0, 'G'], [1400, 'F'], [1800, 'E'], [2200, 'D'], [2600, 'C'], [3000, 'B'], [3400, 'A'], [3800, 'S'], [4200, 'SS'],
];
export const ENDINGS = {
  champion_top: '年度第一，而且每一项都没有落下。这一版会被很多很多人记住——谢谢你，一直站在我身边。',
  champion: '年度第一……原来站在舞台中央是这种感觉。下一版，我想把落下的科目也补上。',
  podium: '站上领奖台了！离最中间只差一点点——下一次，我们一起去拿。',
  S: '虽然没拿到第一，可这一版的我，已经是很多人心里的第一了。',
  A: '比我想象的走得更远。剩下的那一点点，留给下一个版本吧。',
  B: '虽然没有拿到最闪亮的位置，但每一周的进步都是真的。',
  C: '还有好多想学的东西。下一次，我们换一种练法试试？',
  failed: '这次没能走到最后……不过，我记住了和你一起训练的每一天。',
};
