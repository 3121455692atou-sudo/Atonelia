import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import * as D from '../src/career/data.js';
import * as E from '../src/career/engine.js';

const clone = v => JSON.parse(JSON.stringify(v));
const firstFree = ev => ev.choices.findIndex(c => !c.disabled);
function clearQueue(s, pick = firstFree) {
  while (s.status === 'playing' && s.queue.length) E.resolveEvent(s, pick(E.currentEvent(s)));
}
function advanceTo(s, week) {
  clearQueue(s);
  while (s.status === 'playing' && s.week < week) {
    if (E.goalRaceAt(s.week)) {
      E.doRace(s, E.goalRaceAt(s.week).id);
      if (s.pendingRace) E.retryRace(s);
      if (s.pendingRace) E.giveUpRace(s);
    } else if (s.energy < 50) E.doRest(s);
    else E.doTraining(s, 'safety');
    clearQueue(s);
  }
}
// 与模拟校准时相同的「会用技能」玩法。
function smartRun(id, seed) {
  const s = E.createCareer(id, seed);
  let guard = 0;
  while (s.status === 'playing' && guard++ < 300) {
    clearQueue(s);
    if (s.status !== 'playing') break;
    if (s.pendingRace) { if (s.retries > 0) E.retryRace(s); else E.giveUpRace(s); continue; }
    if (s.unlocked.skills) for (const sk of D.SKILLS) if (!s.skills.includes(sk.id) && s.inspiration >= sk.cost + 15 && (!sk.fromWeek || s.week >= sk.fromWeek)) E.learnSkill(s, sk.id);
    if (E.marketOpen(s) && s.energy < 55 && s.inspiration >= 30) E.buyItem(s, 'energy_drink');
    const a = E.availableActions(s);
    if (a.goalWeek) { E.doRace(s, a.race); continue; }
    if (a.debug) { E.doDebug(s); continue; }
    if (s.energy < 45) { E.doRest(s); continue; }
    if (s.mood <= -1) { E.doOuting(s); continue; }
    let best = 'creative', bestV = -1;
    for (const k of D.STATS) {
      const p = E.trainingPreview(s, k);
      const v = Object.values(p.gains).reduce((x, y) => x + y, 0) + p.supporters.length * 6 - p.fail * 2;
      if (v > bestV) { bestV = v; best = k; }
    }
    E.doTraining(s, best);
  }
  return s;
}

describe('育成模式：开局与角色', () => {
  it('25 位模型都能开局，NPC 不能育成', () => {
    assert.equal(D.CAREER_MODELS.length, 25);
    for (const m of D.CAREER_MODELS) {
      const s = E.createCareer(m.id, 7);
      assert.equal(s.week, 1);
      assert.equal(E.validateCareer(s), true, m.id);
      for (const k of m.focus) assert.ok(s.stats[k] >= 130, `${m.id} 的特长 ${k} 初始应更高`);
    }
    for (const npc of ['opencode', 'codex', 'sillytavern', 'ascend', 'huggingface']) assert.throws(() => E.createCareer(npc, 1));
  });
  it('第一周只有训练、休息、外出三个主要行动', () => {
    const s = E.createCareer('qwen', 3);
    clearQueue(s);
    const a = E.availableActions(s);
    assert.deepEqual([a.train, a.rest, a.outing, a.race, a.skills, a.market, a.debug], [true, true, true, null, false, false, false]);
  });
  it('每位训练伙伴都是工具或设施 NPC', () => {
    const s = E.createCareer('claude', 11);
    for (const npc of Object.values(s.supports)) assert.notEqual(D.characterById(npc).category, 'model');
  });
});

describe('育成模式：功能按节点出现', () => {
  it('技能、比赛、集市、服务依次在第 3、5、6、9 周解锁', () => {
    const s = E.createCareer('gemini', 21);
    advanceTo(s, 2);
    assert.deepEqual(s.unlocked, { skills: false, races: false, market: false, service: false });
    advanceTo(s, 3);
    assert.equal(s.unlocked.skills, true);
    assert.equal(s.unlocked.races, false);
    advanceTo(s, 5);
    assert.equal(s.unlocked.races, true);
    assert.equal(E.availableActions(s).race, 'code_rookie');
    advanceTo(s, 6);
    assert.equal(s.unlocked.market, true);
    assert.equal(E.marketOpen(s), true);
    advanceTo(s, 7);
    assert.equal(E.marketOpen(s), false);
    advanceTo(s, 9);
    assert.ok(s.service, '上线服务事件会让玩家选择一种服务');
  });
  it('目标周只能参加目标评测', () => {
    const s = E.createCareer('qwen', 5);
    advanceTo(s, 8);
    const a = E.availableActions(s);
    assert.equal(a.goalWeek, true);
    assert.equal(a.race, 'debut');
    assert.throws(() => E.doTraining(s, 'coding'));
    assert.throws(() => E.doRest(s));
  });
  it('集训营期间训练效果更高且没有公开赛', () => {
    const s = E.createCareer('qwen', 9);
    advanceTo(s, 11);
    const before = E.trainingPreview(s, 'coding');
    advanceTo(s, 12);
    clearQueue(s);
    assert.equal(E.isCamp(s), true);
    assert.equal(E.raceThisWeek(s), null);
    s.board.coding = [];
    const camp = E.trainingPreview(s, 'coding');
    assert.ok(camp.gains.coding > before.gains.coding * 1.2 || before.supporters.length > 0);
  });
});

describe('育成模式：训练、体力与事件', () => {
  it('训练成功会提升能力、消耗体力，四次后升级', () => {
    const s = E.createCareer('deepseek', 4);
    clearQueue(s);
    s.energy = 100;
    const before = s.stats.math;
    const res = E.doTraining(s, 'math');
    assert.equal(res.success, true);
    assert.ok(s.stats.math > before);
    assert.ok(s.energy < 100);
    s.trainUses.math = 3;
    s.queue = [];
    s.energy = 100;
    assert.equal(E.doTraining(s, 'math').levelUp, true);
    assert.equal(E.trainingLevel(s, 'math'), 1);
  });
  it('体力越低失败率越高，对齐训练更安全', () => {
    const s = E.createCareer('qwen', 2);
    s.energy = 90;
    assert.equal(E.failRate(s, 'coding'), 0);
    s.energy = 20;
    assert.ok(E.failRate(s, 'coding') > 50);
    assert.ok(E.failRate(s, 'safety') < E.failRate(s, 'coding'));
  });
  it('个人剧情换算为五维，且每段都有不花灵感的选项', () => {
    assert.equal(D.PERSONAL_EVENTS.length, 64);
    for (const e of D.PERSONAL_EVENTS) {
      assert.ok(D.MODEL_BY_ID[e.characterId], e.id);
      assert.ok(e.choices.some(c => !c.cost), `${e.id} 缺少免费选项`);
      for (const c of e.choices) for (const k of Object.keys(c.effects.stats)) assert.ok(D.STATS.includes(k));
    }
  });
  it('事件选择只结算一次，费用不足时不能选', () => {
    const s = E.createCareer('qwen', 8);
    advanceTo(s, 3);
    s.queue.unshift({ kind: 'personal', id: 'personal_qwen_languages' });
    s.inspiration = 0;
    const ev = E.currentEvent(s);
    const paid = ev.choices.findIndex(c => c.cost > 0);
    assert.equal(ev.choices[paid].disabled, true);
    assert.throws(() => E.resolveEvent(s, paid));
    E.resolveEvent(s, firstFree(ev));
    assert.ok(s.done.includes('personal_qwen_languages'));
  });
  it('经营事件只在服务上线后出现', () => {
    const s = E.createCareer('grok', 31);
    advanceTo(s, 8);
    assert.equal(s.done.some(id => D.BUSINESS_EVENTS.some(e => e.id === id)), false);
    advanceTo(s, 12);
    assert.ok(s.done.includes('compute_crunch'));
  });
  it('隐瞒降智会推高风险，风险高时可能引发诉讼', () => {
    const s = E.createCareer('grok', 41);
    advanceTo(s, 10);
    s.energy = 100;
    E.doTraining(s, 'safety');
    while (s.queue.length && s.queue[0].id !== 'compute_crunch') E.resolveEvent(s, firstFree(E.currentEvent(s)));
    assert.equal(s.queue[0]?.id, 'compute_crunch');
    E.resolveEvent(s, 0);
    assert.equal(s.flags.secret_routing, true);
    assert.ok(s.risk >= 35);
    s.risk = 100;
    let sued = false;
    for (let i = 0; i < 12 && s.status === 'playing' && s.week < 22; i++) {
      advanceTo(s, s.week + 1);
      if (s.done.includes('lawsuit')) { sued = true; break; }
      s.risk = 100;
    }
    assert.equal(sued, true);
  });
});

describe('育成模式：比赛与结算', () => {
  it('目标评测失败时先给再挑战券，放弃则育成结束', () => {
    const s = E.createCareer('qwen', 12);
    advanceTo(s, 8);
    for (const k of D.STATS) s.stats[k] = 20;
    const res = E.doRace(s, 'debut');
    assert.equal(res.goalMet, false);
    assert.equal(res.canRetry, true);
    assert.equal(s.pendingRace, 'debut');
    const again = E.retryRace(s);
    assert.equal(again.canRetry, false);
    assert.equal(s.status, 'ended');
    assert.equal(s.result.reason, 'goal_failed');
  });
  it('技能加成有上限', () => {
    const s = E.createCareer('qwen', 1);
    s.skills = D.SKILLS.map(sk => sk.id);
    assert.ok(E.skillBonus(s, D.RACE_BY_ID.gala).bonus <= D.SKILL_BONUS_CAP);
  });
  it('集市只在开市周营业，每件商品每周限购一次', () => {
    const s = E.createCareer('qwen', 6);
    advanceTo(s, 6);
    clearQueue(s);
    s.inspiration = 200;
    E.buyItem(s, 'energy_drink');
    assert.throws(() => E.buyItem(s, 'energy_drink'));
    advanceTo(s, 7);
    assert.throws(() => E.buyItem(s, 'energy_drink'));
  });
  it('存档可序列化，同样的种子和操作得到同样的结果', () => {
    const a = E.createCareer('kimi', 99);
    advanceTo(a, 10);
    const b = clone(a);
    assert.equal(E.validateCareer(b), true);
    advanceTo(a, 20);
    advanceTo(b, 20);
    assert.deepEqual(a.stats, b.stats);
    assert.equal(a.users, b.users);
  });
  it('25 位模型都能完整走完 24 周', () => {
    for (const [i, m] of D.CAREER_MODELS.entries()) {
      const s = smartRun(m.id, 500 + i);
      assert.equal(s.status, 'ended', m.id);
      assert.ok(D.RANKS.some(([, r]) => r === s.result.rank));
      assert.equal(E.hallOfFameEntry(s).characterId, m.id);
    }
  });
  it('认真玩时目标评测大多能通过，大赏有输有赢', () => {
    let debut = 0, launch = 0, wins = 0;
    const N = 120;
    for (let i = 0; i < N; i++) {
      const s = smartRun(D.CAREER_MODELS[i % D.CAREER_MODELS.length].id, 9000 + i);
      if (s.races.some(r => r.id === 'debut' && r.met)) debut++;
      if (s.races.some(r => r.id === 'launch' && r.met)) launch++;
      if (s.result.galaRank === 1) wins++;
    }
    assert.ok(debut / N >= 0.95, `新人评测通过率 ${debut / N}`);
    assert.ok(launch / N >= 0.85, `上线评测通过率 ${launch / N}`);
    assert.ok(wins / N > 0.3 && wins / N < 0.85, `大赏夺冠率 ${wins / N}`);
  });
});
